<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE eagle SYSTEM "eagle.dtd">
<eagle version="7.7.0">
<drawing>
<settings>
<setting alwaysvectorfont="no"/>
<setting verticaltext="up"/>
</settings>
<grid distance="50" unitdist="mil" unit="mil" style="dots" multiple="1" display="yes" altdistance="10" altunitdist="mil" altunit="mil"/>
<layers>
<layer number="1" name="Top" color="4" fill="1" visible="no" active="no"/>
<layer number="2" name="Route2" color="4" fill="3" visible="no" active="no"/>
<layer number="3" name="Route3" color="4" fill="3" visible="no" active="no"/>
<layer number="4" name="Route4" color="1" fill="4" visible="no" active="no"/>
<layer number="5" name="Route5" color="4" fill="4" visible="no" active="no"/>
<layer number="6" name="Route6" color="1" fill="8" visible="no" active="no"/>
<layer number="7" name="Route7" color="4" fill="8" visible="no" active="no"/>
<layer number="8" name="Route8" color="1" fill="2" visible="no" active="no"/>
<layer number="9" name="Route9" color="4" fill="2" visible="no" active="no"/>
<layer number="10" name="Route10" color="1" fill="7" visible="no" active="no"/>
<layer number="11" name="Route11" color="4" fill="7" visible="no" active="no"/>
<layer number="12" name="Route12" color="1" fill="5" visible="no" active="no"/>
<layer number="13" name="Route13" color="4" fill="5" visible="no" active="no"/>
<layer number="14" name="Route14" color="1" fill="6" visible="no" active="no"/>
<layer number="15" name="Route15" color="1" fill="6" visible="no" active="no"/>
<layer number="16" name="Bottom" color="1" fill="1" visible="no" active="no"/>
<layer number="17" name="Pads" color="2" fill="1" visible="no" active="no"/>
<layer number="18" name="Vias" color="3" fill="1" visible="no" active="no"/>
<layer number="19" name="Unrouted" color="5" fill="1" visible="no" active="no"/>
<layer number="20" name="Dimension" color="10" fill="1" visible="no" active="no"/>
<layer number="21" name="tPlace" color="7" fill="1" visible="no" active="no"/>
<layer number="22" name="bPlace" color="8" fill="1" visible="no" active="no"/>
<layer number="23" name="tOrigins" color="14" fill="1" visible="no" active="no"/>
<layer number="24" name="bOrigins" color="6" fill="1" visible="no" active="no"/>
<layer number="25" name="tNames" color="7" fill="1" visible="no" active="no"/>
<layer number="26" name="bNames" color="8" fill="1" visible="no" active="no"/>
<layer number="27" name="tValues" color="7" fill="1" visible="no" active="no"/>
<layer number="28" name="bValues" color="8" fill="1" visible="no" active="no"/>
<layer number="29" name="tStop" color="15" fill="3" visible="no" active="no"/>
<layer number="30" name="bStop" color="15" fill="6" visible="no" active="no"/>
<layer number="31" name="tCream" color="13" fill="4" visible="no" active="no"/>
<layer number="32" name="bCream" color="5" fill="5" visible="no" active="no"/>
<layer number="33" name="tFinish" color="6" fill="3" visible="no" active="no"/>
<layer number="34" name="bFinish" color="6" fill="6" visible="no" active="no"/>
<layer number="35" name="tGlue" color="7" fill="4" visible="no" active="no"/>
<layer number="36" name="bGlue" color="7" fill="5" visible="no" active="no"/>
<layer number="37" name="tTest" color="7" fill="1" visible="no" active="no"/>
<layer number="38" name="bTest" color="7" fill="1" visible="no" active="no"/>
<layer number="39" name="tKeepout" color="4" fill="11" visible="no" active="no"/>
<layer number="40" name="bKeepout" color="1" fill="11" visible="no" active="no"/>
<layer number="41" name="tRestrict" color="4" fill="7" visible="no" active="no"/>
<layer number="42" name="bRestrict" color="1" fill="7" visible="no" active="no"/>
<layer number="43" name="vRestrict" color="5" fill="7" visible="no" active="no"/>
<layer number="44" name="Drills" color="7" fill="1" visible="no" active="no"/>
<layer number="45" name="Holes" color="7" fill="1" visible="no" active="no"/>
<layer number="46" name="FrameCSM" color="3" fill="1" visible="no" active="no"/>
<layer number="47" name="Koty" color="7" fill="1" visible="no" active="no"/>
<layer number="48" name="Freza" color="7" fill="1" visible="no" active="no"/>
<layer number="49" name="Reference" color="7" fill="1" visible="no" active="no"/>
<layer number="50" name="dxf" color="7" fill="1" visible="no" active="no"/>
<layer number="51" name="tPotisk" color="14" fill="1" visible="no" active="no"/>
<layer number="52" name="bPotisk" color="6" fill="1" visible="no" active="no"/>
<layer number="53" name="tPadExt" color="7" fill="1" visible="no" active="no"/>
<layer number="54" name="bPadExt" color="1" fill="1" visible="no" active="no"/>
<layer number="56" name="wert" color="7" fill="1" visible="no" active="no"/>
<layer number="88" name="SimResults" color="9" fill="1" visible="no" active="no"/>
<layer number="89" name="SimProbes" color="9" fill="1" visible="no" active="no"/>
<layer number="90" name="Modules" color="5" fill="1" visible="yes" active="yes"/>
<layer number="91" name="Nets" color="2" fill="1" visible="yes" active="yes"/>
<layer number="92" name="Busses" color="1" fill="1" visible="yes" active="yes"/>
<layer number="93" name="Pins" color="3" fill="1" visible="no" active="yes"/>
<layer number="94" name="Symbols" color="4" fill="1" visible="yes" active="yes"/>
<layer number="95" name="Names" color="7" fill="1" visible="yes" active="yes"/>
<layer number="96" name="Values" color="7" fill="1" visible="yes" active="yes"/>
<layer number="97" name="Info" color="7" fill="1" visible="yes" active="yes"/>
<layer number="99" name="SpiceOrder" color="5" fill="1" visible="no" active="no"/>
<layer number="200" name="200bmp" color="1" fill="10" visible="no" active="no"/>
<layer number="250" name="Descript" color="3" fill="1" visible="no" active="no"/>
<layer number="251" name="SMDround" color="12" fill="11" visible="no" active="no"/>
</layers>
<schematic xreflabel="%F%N/S%S" xrefpart="/%S.%C%R">
<libraries>
<library name="CONNEC">
<packages>
<package name="25-V2R40T">
<wire x1="-1.27" y1="3.81" x2="49.53" y2="3.81" width="0.254" layer="21"/>
<wire x1="49.53" y1="3.81" x2="49.53" y2="-1.27" width="0.254" layer="21"/>
<wire x1="49.53" y1="-1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="3.81" width="0.254" layer="21"/>
<wire x1="-1.27" y1="3.81" x2="49.53" y2="3.81" width="0.2032" layer="51"/>
<wire x1="49.53" y1="3.81" x2="49.53" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="49.53" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="3.81" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="0.508" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="-0.508" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="0" x2="-2.794" y2="0" width="0.2032" layer="51"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="0.508" width="0.254" layer="21"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-1.651" y1="0" x2="-2.794" y2="0" width="0.254" layer="21"/>
<pad name="17" x="20.32" y="0" drill="1" diameter="1.4986"/>
<pad name="18" x="20.32" y="2.54" drill="1" diameter="1.4986"/>
<pad name="19" x="22.86" y="0" drill="1" diameter="1.4986"/>
<pad name="20" x="22.86" y="2.54" drill="1" diameter="1.4986"/>
<pad name="1" x="0" y="0" drill="1" diameter="1.4986"/>
<pad name="2" x="0" y="2.54" drill="1" diameter="1.4986"/>
<pad name="3" x="2.54" y="0" drill="1" diameter="1.4986"/>
<pad name="4" x="2.54" y="2.54" drill="1" diameter="1.4986"/>
<pad name="5" x="5.08" y="0" drill="1" diameter="1.4986"/>
<pad name="6" x="5.08" y="2.54" drill="1" diameter="1.4986"/>
<pad name="8" x="7.62" y="2.54" drill="1" diameter="1.4986"/>
<pad name="7" x="7.62" y="0" drill="1" diameter="1.4986"/>
<pad name="9" x="10.16" y="0" drill="1" diameter="1.4986"/>
<pad name="10" x="10.16" y="2.54" drill="1" diameter="1.4986"/>
<pad name="12" x="12.7" y="2.54" drill="1" diameter="1.4986"/>
<pad name="11" x="12.7" y="0" drill="1" diameter="1.4986"/>
<pad name="13" x="15.24" y="0" drill="1" diameter="1.4986"/>
<pad name="14" x="15.24" y="2.54" drill="1" diameter="1.4986"/>
<pad name="15" x="17.78" y="0" drill="1" diameter="1.4986"/>
<pad name="16" x="17.78" y="2.54" drill="1" diameter="1.4986"/>
<text x="3.81" y="4.445" size="1.27" layer="25">&gt;NAME</text>
<text x="13.97" y="4.445" size="1.016" layer="27">&gt;VALUE</text>
<text x="8.89" y="4.445" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="21" x="25.4" y="0" drill="1" diameter="1.4986"/>
<pad name="22" x="25.4" y="2.54" drill="1" diameter="1.4986"/>
<pad name="23" x="27.94" y="0" drill="1" diameter="1.4986"/>
<pad name="24" x="27.94" y="2.54" drill="1" diameter="1.4986"/>
<pad name="25" x="30.48" y="0" drill="1" diameter="1.4986"/>
<pad name="26" x="30.48" y="2.54" drill="1" diameter="1.4986"/>
<pad name="27" x="33.02" y="0" drill="1" diameter="1.4986"/>
<pad name="28" x="33.02" y="2.54" drill="1" diameter="1.4986"/>
<pad name="29" x="35.56" y="0" drill="1" diameter="1.4986"/>
<pad name="30" x="35.56" y="2.54" drill="1" diameter="1.4986"/>
<pad name="31" x="38.1" y="0" drill="1" diameter="1.4986"/>
<pad name="32" x="38.1" y="2.54" drill="1" diameter="1.4986"/>
<pad name="33" x="40.64" y="0" drill="1" diameter="1.4986"/>
<pad name="34" x="40.64" y="2.54" drill="1" diameter="1.4986"/>
<pad name="35" x="43.18" y="0" drill="1" diameter="1.4986"/>
<pad name="36" x="43.18" y="2.54" drill="1" diameter="1.4986"/>
<pad name="37" x="45.72" y="0" drill="1" diameter="1.4986"/>
<pad name="38" x="45.72" y="2.54" drill="1" diameter="1.4986"/>
<pad name="39" x="48.26" y="0" drill="1" diameter="1.4986"/>
<pad name="40" x="48.26" y="2.54" drill="1" diameter="1.4986"/>
</package>
<package name="USB-B1">
<description>MOLEX 67068-9000</description>
<wire x1="6" y1="-10.28" x2="-6" y2="-10.28" width="0.254" layer="21"/>
<wire x1="-6" y1="-10.28" x2="-6" y2="6.72" width="0.254" layer="21"/>
<wire x1="-6" y1="6.72" x2="6" y2="6.72" width="0.254" layer="21"/>
<wire x1="6" y1="6.72" x2="6" y2="-10.28" width="0.254" layer="21"/>
<pad name="1" x="1.25" y="4.71" drill="0.9" diameter="1.6" rot="R180"/>
<pad name="S2" x="6.02" y="0" drill="2.3" diameter="3.5" rot="R180"/>
<pad name="S1" x="-6.02" y="0" drill="2.3" diameter="3.5" rot="R180"/>
<text x="-2.54" y="-3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="6.985" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-6" y1="6.72" x2="6" y2="6.72" width="0.2032" layer="51"/>
<wire x1="6" y1="6.72" x2="6" y2="2" width="0.2032" layer="51"/>
<wire x1="6" y1="-2" x2="6" y2="-10.28" width="0.2032" layer="51"/>
<wire x1="-6" y1="-2" x2="-6" y2="-10.28" width="0.2032" layer="51"/>
<wire x1="-6" y1="6.72" x2="-6" y2="2" width="0.2032" layer="51"/>
<pad name="2" x="-1.25" y="4.71" drill="0.9" diameter="1.6" rot="R180"/>
<pad name="3" x="-1.25" y="2.71" drill="0.9" diameter="1.6" rot="R180"/>
<pad name="4" x="1.25" y="2.71" drill="0.9" diameter="1.6" rot="R180"/>
</package>
<package name="AMP174804">
<description>Amphenol 174804-1</description>
<wire x1="-12.65" y1="8.55" x2="-12.65" y2="7.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="6.45" x2="-12.65" y2="4.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="3.45" x2="-12.65" y2="2.25" width="0.254" layer="21"/>
<wire x1="-11.65" y1="0.55" x2="-8.87" y2="0.55" width="0.254" layer="21"/>
<wire x1="-8.87" y1="0.55" x2="-6.37" y2="0.55" width="0.254" layer="21"/>
<wire x1="-6.37" y1="0.55" x2="-3.79" y2="0.55" width="0.254" layer="21"/>
<wire x1="-3.79" y1="0.55" x2="-1.29" y2="0.55" width="0.254" layer="21"/>
<wire x1="-1.29" y1="0.55" x2="1.29" y2="0.55" width="0.254" layer="21"/>
<wire x1="1.29" y1="0.55" x2="3.79" y2="0.55" width="0.254" layer="21"/>
<wire x1="3.79" y1="0.55" x2="6.37" y2="0.55" width="0.254" layer="21"/>
<wire x1="6.37" y1="0.55" x2="8.87" y2="0.55" width="0.254" layer="21"/>
<wire x1="8.87" y1="0.55" x2="11.65" y2="0.55" width="0.254" layer="21"/>
<wire x1="12.65" y1="2.25" x2="12.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="12.65" y1="4.458" x2="12.65" y2="6.45" width="0.254" layer="21"/>
<wire x1="12.65" y1="7.45" x2="12.65" y2="8.55" width="0.254" layer="21"/>
<wire x1="11.45" y1="10.75" x2="-11.45" y2="10.75" width="0.254" layer="21"/>
<wire x1="-12.65" y1="10.75" x2="-12.65" y2="7.3" width="0.2032" layer="51"/>
<wire x1="-12.65" y1="3.6" x2="-12.65" y2="0.55" width="0.2032" layer="51"/>
<wire x1="-12.65" y1="0.55" x2="-9.03" y2="0.55" width="0.2032" layer="51"/>
<wire x1="-6.2" y1="0.55" x2="-3.95" y2="0.55" width="0.2032" layer="51"/>
<wire x1="-1.12" y1="0.55" x2="1.12" y2="0.55" width="0.2032" layer="51"/>
<wire x1="12.65" y1="0.55" x2="12.65" y2="3.6" width="0.2032" layer="51"/>
<wire x1="12.65" y1="7.3" x2="12.65" y2="10.75" width="0.2032" layer="51"/>
<pad name="1" x="-7.62" y="0" drill="1.5" diameter="2.54"/>
<pad name="2" x="-2.54" y="0" drill="1.5" diameter="2.54"/>
<pad name="3" x="2.54" y="0" drill="1.5" diameter="2.54"/>
<pad name="4" x="7.62" y="0" drill="1.5" diameter="2.54"/>
<text x="-2.54" y="8.255" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="5.715" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="S2" x="11.85" y="5.45" drill="2.3" diameter="3.5"/>
<pad name="S1" x="-11.85" y="5.45" drill="2.3" diameter="3.5"/>
<wire x1="6.2" y1="0.55" x2="3.95" y2="0.55" width="0.2032" layer="51"/>
<wire x1="9.03" y1="0.55" x2="12.65" y2="0.55" width="0.2032" layer="51"/>
<wire x1="-8.87" y1="0.55" x2="-8.87" y2="-0.75" width="0.254" layer="21"/>
<wire x1="-8.87" y1="-0.75" x2="-6.37" y2="-0.75" width="0.254" layer="21"/>
<wire x1="-6.37" y1="-0.75" x2="-6.37" y2="0.55" width="0.254" layer="21"/>
<wire x1="-3.79" y1="-0.75" x2="-1.29" y2="-0.75" width="0.254" layer="21"/>
<wire x1="-3.79" y1="0.55" x2="-3.79" y2="-0.75" width="0.254" layer="21"/>
<wire x1="-1.29" y1="-0.75" x2="-1.29" y2="0.55" width="0.254" layer="21"/>
<wire x1="1.29" y1="-0.75" x2="3.79" y2="-0.75" width="0.254" layer="21"/>
<wire x1="3.79" y1="-0.75" x2="3.79" y2="0.55" width="0.254" layer="21"/>
<wire x1="1.29" y1="0.55" x2="1.29" y2="-0.75" width="0.254" layer="21"/>
<wire x1="6.37" y1="-0.75" x2="8.87" y2="-0.75" width="0.254" layer="21"/>
<wire x1="8.87" y1="-0.75" x2="8.87" y2="0.55" width="0.254" layer="21"/>
<wire x1="6.37" y1="0.55" x2="6.37" y2="-0.75" width="0.254" layer="21"/>
<wire x1="-12.65" y1="6.45" x2="-12.15" y2="6.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="6.45" x2="12.15" y2="6.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="6.45" x2="12.65" y2="6.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="4.45" x2="-12.15" y2="4.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="4.45" x2="12.15" y2="4.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="4.45" x2="12.65" y2="4.458" width="0.254" layer="21"/>
<wire x1="-12.65" y1="7.45" x2="-12.15" y2="7.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="7.45" x2="12.15" y2="7.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="7.45" x2="12.65" y2="7.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="3.45" x2="-12.15" y2="3.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="3.45" x2="-11.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="-11.65" y1="3.45" x2="11.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="11.65" y1="3.45" x2="12.15" y2="3.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="3.45" x2="12.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="7.45" x2="-12.15" y2="6.45" width="0.254" layer="21"/>
<wire x1="-12.15" y1="4.45" x2="-12.15" y2="3.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="6.45" x2="12.15" y2="7.45" width="0.254" layer="21"/>
<wire x1="12.15" y1="3.45" x2="12.15" y2="4.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="2.25" x2="-11.65" y2="0.55" width="0.254" layer="21"/>
<wire x1="12.65" y1="2.25" x2="11.65" y2="0.55" width="0.254" layer="21"/>
<wire x1="-11.65" y1="0.55" x2="-11.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="11.65" y1="0.55" x2="11.65" y2="3.45" width="0.254" layer="21"/>
<wire x1="-12.65" y1="8.55" x2="-11.45" y2="10.75" width="0.254" layer="21"/>
<wire x1="12.65" y1="8.55" x2="11.45" y2="10.75" width="0.254" layer="21"/>
</package>
<package name="25-V2R40B">
<wire x1="-1.27" y1="1.27" x2="49.53" y2="1.27" width="0.254" layer="22"/>
<wire x1="49.53" y1="1.27" x2="49.53" y2="-3.81" width="0.254" layer="22"/>
<wire x1="49.53" y1="-3.81" x2="-1.27" y2="-3.81" width="0.254" layer="22"/>
<wire x1="-1.27" y1="-3.81" x2="-1.27" y2="1.27" width="0.254" layer="22"/>
<wire x1="-1.27" y1="1.27" x2="49.53" y2="1.27" width="0.2032" layer="52"/>
<wire x1="49.53" y1="1.27" x2="49.53" y2="-3.81" width="0.2032" layer="52"/>
<wire x1="49.53" y1="-3.81" x2="-1.27" y2="-3.81" width="0.2032" layer="52"/>
<wire x1="-1.27" y1="-3.81" x2="-1.27" y2="1.27" width="0.2032" layer="52"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="0.508" width="0.2032" layer="52"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="-0.508" width="0.2032" layer="52"/>
<wire x1="-1.651" y1="0" x2="-2.794" y2="0" width="0.2032" layer="52"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="0.508" width="0.254" layer="22"/>
<wire x1="-1.651" y1="0" x2="-2.159" y2="-0.508" width="0.254" layer="22"/>
<wire x1="-1.651" y1="0" x2="-2.794" y2="0" width="0.254" layer="22"/>
<pad name="17" x="20.32" y="0" drill="1" diameter="1.4986"/>
<pad name="18" x="20.32" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="19" x="22.86" y="0" drill="1" diameter="1.4986"/>
<pad name="20" x="22.86" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="1" x="0" y="0" drill="1" diameter="1.4986"/>
<pad name="2" x="0" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="3" x="2.54" y="0" drill="1" diameter="1.4986"/>
<pad name="4" x="2.54" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="5" x="5.08" y="0" drill="1" diameter="1.4986"/>
<pad name="6" x="5.08" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="8" x="7.62" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="7" x="7.62" y="0" drill="1" diameter="1.4986"/>
<pad name="9" x="10.16" y="0" drill="1" diameter="1.4986"/>
<pad name="10" x="10.16" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="12" x="12.7" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="11" x="12.7" y="0" drill="1" diameter="1.4986"/>
<pad name="13" x="15.24" y="0" drill="1" diameter="1.4986"/>
<pad name="14" x="15.24" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="15" x="17.78" y="0" drill="1" diameter="1.4986"/>
<pad name="16" x="17.78" y="-2.54" drill="1" diameter="1.4986"/>
<text x="8.89" y="1.905" size="1.27" layer="26" rot="MR0">&gt;NAME</text>
<text x="19.05" y="1.905" size="1.016" layer="28" rot="MR0">&gt;VALUE</text>
<text x="13.97" y="1.905" size="1.27" layer="52" font="vector" ratio="12" rot="MR0">&gt;NAME</text>
<pad name="21" x="25.4" y="0" drill="1" diameter="1.4986"/>
<pad name="22" x="25.4" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="23" x="27.94" y="0" drill="1" diameter="1.4986"/>
<pad name="24" x="27.94" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="25" x="30.48" y="0" drill="1" diameter="1.4986"/>
<pad name="26" x="30.48" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="27" x="33.02" y="0" drill="1" diameter="1.4986"/>
<pad name="28" x="33.02" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="29" x="35.56" y="0" drill="1" diameter="1.4986"/>
<pad name="30" x="35.56" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="31" x="38.1" y="0" drill="1" diameter="1.4986"/>
<pad name="32" x="38.1" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="33" x="40.64" y="0" drill="1" diameter="1.4986"/>
<pad name="34" x="40.64" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="35" x="43.18" y="0" drill="1" diameter="1.4986"/>
<pad name="36" x="43.18" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="37" x="45.72" y="0" drill="1" diameter="1.4986"/>
<pad name="38" x="45.72" y="-2.54" drill="1" diameter="1.4986"/>
<pad name="39" x="48.26" y="0" drill="1" diameter="1.4986"/>
<pad name="40" x="48.26" y="-2.54" drill="1" diameter="1.4986"/>
</package>
</packages>
<symbols>
<symbol name="VIDL40">
<wire x1="7.62" y1="-2.54" x2="2.54" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="2.54" y2="-5.08" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-7.62" x2="2.54" y2="-7.62" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="2.54" y2="-10.16" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-12.7" x2="2.54" y2="-12.7" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-15.24" x2="2.54" y2="-15.24" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-17.78" x2="2.54" y2="-17.78" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-20.32" x2="2.54" y2="-20.32" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-22.86" x2="2.54" y2="-22.86" width="0.6096" layer="94"/>
<wire x1="0" y1="0" x2="10.16" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="10.16" y2="-104.14" width="0.254" layer="94"/>
<wire x1="10.16" y1="-104.14" x2="0" y2="-104.14" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-5.08" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="0" y1="-7.62" x2="2.54" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="0" y1="-10.16" x2="2.54" y2="-10.16" width="0.1524" layer="94"/>
<wire x1="0" y1="-12.7" x2="2.54" y2="-12.7" width="0.1524" layer="94"/>
<wire x1="0" y1="-15.24" x2="2.54" y2="-15.24" width="0.1524" layer="94"/>
<wire x1="0" y1="-17.78" x2="2.54" y2="-17.78" width="0.1524" layer="94"/>
<wire x1="0" y1="-20.32" x2="2.54" y2="-20.32" width="0.1524" layer="94"/>
<wire x1="0" y1="-22.86" x2="2.54" y2="-22.86" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-25.4" x2="2.54" y2="-25.4" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-27.94" x2="2.54" y2="-27.94" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-30.48" x2="2.54" y2="-30.48" width="0.6096" layer="94"/>
<wire x1="0" y1="-25.4" x2="2.54" y2="-25.4" width="0.1524" layer="94"/>
<wire x1="0" y1="-27.94" x2="2.54" y2="-27.94" width="0.1524" layer="94"/>
<wire x1="0" y1="-30.48" x2="2.54" y2="-30.48" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-33.02" x2="2.54" y2="-33.02" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-35.56" x2="2.54" y2="-35.56" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-38.1" x2="2.54" y2="-38.1" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-40.64" x2="2.54" y2="-40.64" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-43.18" x2="2.54" y2="-43.18" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-45.72" x2="2.54" y2="-45.72" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-48.26" x2="2.54" y2="-48.26" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-50.8" x2="2.54" y2="-50.8" width="0.6096" layer="94"/>
<wire x1="0" y1="-33.02" x2="2.54" y2="-33.02" width="0.1524" layer="94"/>
<wire x1="0" y1="-35.56" x2="2.54" y2="-35.56" width="0.1524" layer="94"/>
<wire x1="0" y1="-38.1" x2="2.54" y2="-38.1" width="0.1524" layer="94"/>
<wire x1="0" y1="-40.64" x2="2.54" y2="-40.64" width="0.1524" layer="94"/>
<wire x1="0" y1="-43.18" x2="2.54" y2="-43.18" width="0.1524" layer="94"/>
<wire x1="0" y1="-45.72" x2="2.54" y2="-45.72" width="0.1524" layer="94"/>
<wire x1="0" y1="-48.26" x2="2.54" y2="-48.26" width="0.1524" layer="94"/>
<wire x1="0" y1="-50.8" x2="2.54" y2="-50.8" width="0.1524" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-104.14" width="0.254" layer="94"/>
<text x="0" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="1.27" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="3" x="-2.54" y="-7.62" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="4" x="-2.54" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="5" x="-2.54" y="-12.7" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="6" x="-2.54" y="-15.24" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="7" x="-2.54" y="-17.78" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="8" x="-2.54" y="-20.32" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="9" x="-2.54" y="-22.86" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="10" x="-2.54" y="-25.4" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="11" x="-2.54" y="-27.94" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="12" x="-2.54" y="-30.48" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="13" x="-2.54" y="-33.02" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="14" x="-2.54" y="-35.56" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="15" x="-2.54" y="-38.1" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="16" x="-2.54" y="-40.64" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="17" x="-2.54" y="-43.18" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="18" x="-2.54" y="-45.72" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="19" x="-2.54" y="-48.26" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="20" x="-2.54" y="-50.8" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="21" x="-2.54" y="-53.34" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="22" x="-2.54" y="-55.88" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="23" x="-2.54" y="-58.42" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="24" x="-2.54" y="-60.96" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="25" x="-2.54" y="-63.5" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="26" x="-2.54" y="-66.04" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="27" x="-2.54" y="-68.58" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="28" x="-2.54" y="-71.12" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="29" x="-2.54" y="-73.66" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="30" x="-2.54" y="-76.2" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="31" x="-2.54" y="-78.74" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="32" x="-2.54" y="-81.28" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="33" x="-2.54" y="-83.82" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="34" x="-2.54" y="-86.36" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="35" x="-2.54" y="-88.9" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="36" x="-2.54" y="-91.44" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="37" x="-2.54" y="-93.98" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="38" x="-2.54" y="-96.52" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="39" x="-2.54" y="-99.06" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="40" x="-2.54" y="-101.6" visible="pad" length="short" direction="pas" swaplevel="1"/>
<wire x1="7.62" y1="-53.34" x2="2.54" y2="-53.34" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-55.88" x2="2.54" y2="-55.88" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-58.42" x2="2.54" y2="-58.42" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-60.96" x2="2.54" y2="-60.96" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-63.5" x2="2.54" y2="-63.5" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-66.04" x2="2.54" y2="-66.04" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-68.58" x2="2.54" y2="-68.58" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-71.12" x2="2.54" y2="-71.12" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-73.66" x2="2.54" y2="-73.66" width="0.6096" layer="94"/>
<wire x1="0" y1="-53.34" x2="2.54" y2="-53.34" width="0.1524" layer="94"/>
<wire x1="0" y1="-55.88" x2="2.54" y2="-55.88" width="0.1524" layer="94"/>
<wire x1="0" y1="-58.42" x2="2.54" y2="-58.42" width="0.1524" layer="94"/>
<wire x1="0" y1="-60.96" x2="2.54" y2="-60.96" width="0.1524" layer="94"/>
<wire x1="0" y1="-63.5" x2="2.54" y2="-63.5" width="0.1524" layer="94"/>
<wire x1="0" y1="-66.04" x2="2.54" y2="-66.04" width="0.1524" layer="94"/>
<wire x1="0" y1="-68.58" x2="2.54" y2="-68.58" width="0.1524" layer="94"/>
<wire x1="0" y1="-71.12" x2="2.54" y2="-71.12" width="0.1524" layer="94"/>
<wire x1="0" y1="-73.66" x2="2.54" y2="-73.66" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-76.2" x2="2.54" y2="-76.2" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-78.74" x2="2.54" y2="-78.74" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-81.28" x2="2.54" y2="-81.28" width="0.6096" layer="94"/>
<wire x1="0" y1="-76.2" x2="2.54" y2="-76.2" width="0.1524" layer="94"/>
<wire x1="0" y1="-78.74" x2="2.54" y2="-78.74" width="0.1524" layer="94"/>
<wire x1="0" y1="-81.28" x2="2.54" y2="-81.28" width="0.1524" layer="94"/>
<wire x1="7.62" y1="-83.82" x2="2.54" y2="-83.82" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-86.36" x2="2.54" y2="-86.36" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-88.9" x2="2.54" y2="-88.9" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-91.44" x2="2.54" y2="-91.44" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-93.98" x2="2.54" y2="-93.98" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-96.52" x2="2.54" y2="-96.52" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-99.06" x2="2.54" y2="-99.06" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-101.6" x2="2.54" y2="-101.6" width="0.6096" layer="94"/>
<wire x1="0" y1="-83.82" x2="2.54" y2="-83.82" width="0.1524" layer="94"/>
<wire x1="0" y1="-86.36" x2="2.54" y2="-86.36" width="0.1524" layer="94"/>
<wire x1="0" y1="-88.9" x2="2.54" y2="-88.9" width="0.1524" layer="94"/>
<wire x1="0" y1="-91.44" x2="2.54" y2="-91.44" width="0.1524" layer="94"/>
<wire x1="0" y1="-93.98" x2="2.54" y2="-93.98" width="0.1524" layer="94"/>
<wire x1="0" y1="-96.52" x2="2.54" y2="-96.52" width="0.1524" layer="94"/>
<wire x1="0" y1="-99.06" x2="2.54" y2="-99.06" width="0.1524" layer="94"/>
<wire x1="0" y1="-101.6" x2="2.54" y2="-101.6" width="0.1524" layer="94"/>
</symbol>
<symbol name="USB-1X">
<wire x1="-10.16" y1="-12.7" x2="0" y2="-12.7" width="0.254" layer="94"/>
<wire x1="0" y1="-12.7" x2="0" y2="0" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="-10.16" y2="0" width="0.254" layer="94"/>
<wire x1="-10.16" y1="0" x2="-10.16" y2="-12.7" width="0.254" layer="94"/>
<text x="-10.16" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="-10.16" y="1.27" size="1.524" layer="96">&gt;VALUE</text>
<pin name="VBUS" x="2.54" y="-2.54" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="D-" x="2.54" y="-5.08" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="D+" x="2.54" y="-7.62" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="GND" x="2.54" y="-10.16" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="S" x="-5.08" y="-15.24" visible="off" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="VIDL4">
<wire x1="7.62" y1="-2.54" x2="2.54" y2="-2.54" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-5.08" x2="2.54" y2="-5.08" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-7.62" x2="2.54" y2="-7.62" width="0.6096" layer="94"/>
<wire x1="7.62" y1="-10.16" x2="2.54" y2="-10.16" width="0.6096" layer="94"/>
<wire x1="0" y1="0" x2="10.16" y2="0" width="0.254" layer="94"/>
<wire x1="10.16" y1="0" x2="10.16" y2="-12.7" width="0.254" layer="94"/>
<wire x1="10.16" y1="-12.7" x2="0" y2="-12.7" width="0.254" layer="94"/>
<wire x1="0" y1="0" x2="0" y2="-12.7" width="0.254" layer="94"/>
<wire x1="0" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="0" y1="-5.08" x2="2.54" y2="-5.08" width="0.1524" layer="94"/>
<wire x1="0" y1="-7.62" x2="2.54" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="0" y1="-10.16" x2="2.54" y2="-10.16" width="0.1524" layer="94"/>
<text x="0" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="1.27" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-2.54" y="-2.54" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="-2.54" y="-5.08" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="3" x="-2.54" y="-7.62" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="4" x="-2.54" y="-10.16" visible="pad" length="short" direction="pas" swaplevel="1"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="25-V2R40" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="VIDL40" x="0" y="0"/>
</gates>
<devices>
<device name="-TOP" package="25-V2R40T">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="13" pad="13"/>
<connect gate="A" pin="14" pad="14"/>
<connect gate="A" pin="15" pad="15"/>
<connect gate="A" pin="16" pad="16"/>
<connect gate="A" pin="17" pad="17"/>
<connect gate="A" pin="18" pad="18"/>
<connect gate="A" pin="19" pad="19"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="20" pad="20"/>
<connect gate="A" pin="21" pad="21"/>
<connect gate="A" pin="22" pad="22"/>
<connect gate="A" pin="23" pad="23"/>
<connect gate="A" pin="24" pad="24"/>
<connect gate="A" pin="25" pad="25"/>
<connect gate="A" pin="26" pad="26"/>
<connect gate="A" pin="27" pad="27"/>
<connect gate="A" pin="28" pad="28"/>
<connect gate="A" pin="29" pad="29"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="30" pad="30"/>
<connect gate="A" pin="31" pad="31"/>
<connect gate="A" pin="32" pad="32"/>
<connect gate="A" pin="33" pad="33"/>
<connect gate="A" pin="34" pad="34"/>
<connect gate="A" pin="35" pad="35"/>
<connect gate="A" pin="36" pad="36"/>
<connect gate="A" pin="37" pad="37"/>
<connect gate="A" pin="38" pad="38"/>
<connect gate="A" pin="39" pad="39"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="40" pad="40"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-BOT" package="25-V2R40B">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="10" pad="10"/>
<connect gate="A" pin="11" pad="11"/>
<connect gate="A" pin="12" pad="12"/>
<connect gate="A" pin="13" pad="13"/>
<connect gate="A" pin="14" pad="14"/>
<connect gate="A" pin="15" pad="15"/>
<connect gate="A" pin="16" pad="16"/>
<connect gate="A" pin="17" pad="17"/>
<connect gate="A" pin="18" pad="18"/>
<connect gate="A" pin="19" pad="19"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="20" pad="20"/>
<connect gate="A" pin="21" pad="21"/>
<connect gate="A" pin="22" pad="22"/>
<connect gate="A" pin="23" pad="23"/>
<connect gate="A" pin="24" pad="24"/>
<connect gate="A" pin="25" pad="25"/>
<connect gate="A" pin="26" pad="26"/>
<connect gate="A" pin="27" pad="27"/>
<connect gate="A" pin="28" pad="28"/>
<connect gate="A" pin="29" pad="29"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="30" pad="30"/>
<connect gate="A" pin="31" pad="31"/>
<connect gate="A" pin="32" pad="32"/>
<connect gate="A" pin="33" pad="33"/>
<connect gate="A" pin="34" pad="34"/>
<connect gate="A" pin="35" pad="35"/>
<connect gate="A" pin="36" pad="36"/>
<connect gate="A" pin="37" pad="37"/>
<connect gate="A" pin="38" pad="38"/>
<connect gate="A" pin="39" pad="39"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="40" pad="40"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="7" pad="7"/>
<connect gate="A" pin="8" pad="8"/>
<connect gate="A" pin="9" pad="9"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="USB-B" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="USB-1X" x="0" y="0"/>
</gates>
<devices>
<device name="-B1" package="USB-B1">
<connects>
<connect gate="A" pin="D+" pad="3"/>
<connect gate="A" pin="D-" pad="2"/>
<connect gate="A" pin="GND" pad="4"/>
<connect gate="A" pin="S" pad="S1 S2"/>
<connect gate="A" pin="VBUS" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="AMP174804" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="VIDL4" x="0" y="0"/>
</gates>
<devices>
<device name="" package="AMP174804">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="IC">
<packages>
<package name="SO20">
<wire x1="-6.3" y1="-2.65" x2="6.3" y2="-2.65" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.65" x2="6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.2987" x2="6.3" y2="-2.0447" width="0.254" layer="21"/>
<wire x1="6.3" y1="-2.0447" x2="6.3" y2="2.65" width="0.254" layer="21"/>
<wire x1="6.3" y1="2.65" x2="-6.3" y2="2.65" width="0.254" layer="21"/>
<wire x1="-6.3" y1="2.65" x2="-6.3" y2="0.635" width="0.254" layer="21"/>
<wire x1="-6.3" y1="0.635" x2="-5.85" y2="0.635" width="0.254" layer="21"/>
<wire x1="-5.85" y1="0.635" x2="-5.85" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-5.85" y1="-0.635" x2="-6.3" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-0.635" x2="-6.3" y2="-2.0447" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.0447" x2="-6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.2987" x2="-6.3" y2="-2.65" width="0.254" layer="21"/>
<wire x1="-6.3246" y1="-0.635" x2="-6.3246" y2="-4.9403" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="-4.9403" x2="6.3246" y2="-4.9403" width="0.2032" layer="51"/>
<wire x1="6.3246" y1="-4.9403" x2="6.3246" y2="4.9403" width="0.2032" layer="51"/>
<wire x1="6.3246" y1="4.9403" x2="-6.3246" y2="4.9403" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="4.9403" x2="-6.3246" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-6.3246" y1="0.635" x2="-5.85" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-5.85" y1="0.635" x2="-5.85" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-5.85" y1="-0.635" x2="-6.3246" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-6.3" y1="-2.2987" x2="6.3" y2="-2.2987" width="0.254" layer="21"/>
<wire x1="-6.3" y1="-2.0447" x2="6.3" y2="-2.0447" width="0.254" layer="21"/>
<smd name="1" x="-5.715" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="20" x="-5.715" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="2" x="-4.445" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="3" x="-3.175" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="19" x="-4.445" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="18" x="-3.175" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="4" x="-1.905" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="17" x="-1.905" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="5" x="-0.635" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="6" x="0.635" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="7" x="1.905" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="8" x="3.175" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="9" x="4.445" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="10" x="5.715" y="-3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="16" x="-0.635" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="15" x="0.635" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="14" x="1.905" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="13" x="3.175" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="12" x="4.445" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<smd name="11" x="5.715" y="3.57" dx="0.6" dy="2.13" layer="1"/>
<text x="-2.54" y="0.3175" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-0.9525" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="-0.4445" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="-5.8928" y1="-3.9" x2="-5.5372" y2="-2.6035" layer="21"/>
<rectangle x1="-4.6228" y1="-3.9" x2="-4.2672" y2="-2.6035" layer="21"/>
<rectangle x1="-3.3528" y1="-3.9" x2="-2.9972" y2="-2.6035" layer="21"/>
<rectangle x1="-2.0828" y1="-3.9" x2="-1.7272" y2="-2.6035" layer="21"/>
<rectangle x1="-0.8128" y1="-3.9" x2="-0.4572" y2="-2.6035" layer="21"/>
<rectangle x1="0.4572" y1="-3.9" x2="0.8128" y2="-2.6035" layer="21"/>
<rectangle x1="1.7272" y1="-3.9" x2="2.0828" y2="-2.6035" layer="21"/>
<rectangle x1="2.9972" y1="-3.9" x2="3.3528" y2="-2.6035" layer="21"/>
<rectangle x1="4.2672" y1="-3.9" x2="4.6228" y2="-2.6035" layer="21"/>
<rectangle x1="5.5372" y1="-3.9" x2="5.8928" y2="-2.6035" layer="21"/>
<rectangle x1="-5.8928" y1="2.6035" x2="-5.5372" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-4.6228" y1="2.6035" x2="-4.2672" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-3.3528" y1="2.6035" x2="-2.9972" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-2.0828" y1="2.6035" x2="-1.7272" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="-0.8128" y1="2.6035" x2="-0.4572" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="0.4572" y1="2.6035" x2="0.8128" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="1.7272" y1="2.6035" x2="2.0828" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="2.9972" y1="2.6035" x2="3.3528" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="4.2672" y1="2.6035" x2="4.6228" y2="3.9" layer="21" rot="R180"/>
<rectangle x1="5.5372" y1="2.6035" x2="5.8928" y2="3.9" layer="21" rot="R180"/>
</package>
<package name="TSSOP20">
<wire x1="-3.3" y1="2.25" x2="3.3" y2="2.25" width="0.254" layer="21"/>
<wire x1="3.3" y1="2.25" x2="3.3" y2="-2.25" width="0.254" layer="21"/>
<wire x1="3.3" y1="-2.25" x2="-3.3" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-3.3" y1="-2.25" x2="-3.3" y2="2.25" width="0.254" layer="21"/>
<wire x1="-3.429" y1="3.81" x2="3.429" y2="3.81" width="0.2032" layer="51"/>
<wire x1="3.429" y1="3.81" x2="3.429" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="3.429" y1="-3.81" x2="-3.429" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="-3.81" x2="-3.429" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="-0.635" x2="-3.0734" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.0734" y1="-0.635" x2="-3.0734" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.0734" y1="0.635" x2="-3.429" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.429" y1="0.635" x2="-3.429" y2="3.81" width="0.2032" layer="51"/>
<circle x="-2.5" y="-1.45" radius="0.3535" width="0.254" layer="21"/>
<smd name="1" x="-2.925" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="2" x="-2.275" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="3" x="-1.625" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="4" x="-0.975" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="5" x="-0.325" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="6" x="0.325" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="7" x="0.975" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="8" x="1.625" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="9" x="2.275" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="10" x="2.925" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="11" x="2.925" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="12" x="2.275" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="13" x="1.625" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="14" x="0.975" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="15" x="0.325" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="16" x="-0.325" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="17" x="-0.975" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="18" x="-1.625" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="19" x="-2.275" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="20" x="-2.925" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<text x="-1.89" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.89" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.89" y="-0.762" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="0.8251" y1="2.2" x2="1.1251" y2="3.2" layer="21"/>
<rectangle x1="0.8251" y1="-3.2" x2="1.1251" y2="-2.2" layer="21"/>
<rectangle x1="0.1751" y1="2.2" x2="0.4751" y2="3.2" layer="21"/>
<rectangle x1="-0.4749" y1="2.2" x2="-0.1749" y2="3.2" layer="21"/>
<rectangle x1="-1.1249" y1="2.2" x2="-0.8249" y2="3.2" layer="21"/>
<rectangle x1="-1.7749" y1="2.2" x2="-1.4749" y2="3.2" layer="21"/>
<rectangle x1="-2.4249" y1="2.2" x2="-2.1249" y2="3.2" layer="21"/>
<rectangle x1="-3.0749" y1="2.2" x2="-2.7749" y2="3.2" layer="21"/>
<rectangle x1="1.4751" y1="2.2" x2="1.7751" y2="3.2" layer="21"/>
<rectangle x1="2.1251" y1="2.2" x2="2.4251" y2="3.2" layer="21"/>
<rectangle x1="2.7751" y1="2.2" x2="3.0751" y2="3.2" layer="21"/>
<rectangle x1="-3.0749" y1="-3.2" x2="-2.7749" y2="-2.2" layer="21"/>
<rectangle x1="-2.4249" y1="-3.2" x2="-2.1249" y2="-2.2" layer="21"/>
<rectangle x1="-1.7749" y1="-3.2" x2="-1.4749" y2="-2.2" layer="21"/>
<rectangle x1="-1.1249" y1="-3.2" x2="-0.8249" y2="-2.2" layer="21"/>
<rectangle x1="-0.4749" y1="-3.2" x2="-0.1749" y2="-2.2" layer="21"/>
<rectangle x1="0.1751" y1="-3.2" x2="0.4751" y2="-2.2" layer="21"/>
<rectangle x1="1.4751" y1="-3.2" x2="1.7751" y2="-2.2" layer="21"/>
<rectangle x1="2.1251" y1="-3.2" x2="2.4251" y2="-2.2" layer="21"/>
<rectangle x1="2.7751" y1="-3.2" x2="3.0751" y2="-2.2" layer="21"/>
</package>
<package name="SOT223">
<wire x1="-3.1242" y1="1.7272" x2="-3.1242" y2="-1.7272" width="0.254" layer="21"/>
<wire x1="3.1242" y1="-1.7272" x2="3.1242" y2="1.7272" width="0.254" layer="21"/>
<wire x1="-3.1242" y1="1.7272" x2="3.1242" y2="1.7272" width="0.254" layer="21"/>
<wire x1="3.1242" y1="-1.7272" x2="-3.1242" y2="-1.7272" width="0.254" layer="21"/>
<wire x1="-3.3401" y1="4.4577" x2="3.3401" y2="4.4577" width="0.2032" layer="51"/>
<wire x1="3.3401" y1="4.4577" x2="3.3401" y2="-4.4577" width="0.2032" layer="51"/>
<wire x1="3.3401" y1="-4.4577" x2="-3.3401" y2="-4.4577" width="0.2032" layer="51"/>
<wire x1="-3.3401" y1="-4.4577" x2="-3.3401" y2="4.4577" width="0.2032" layer="51"/>
<smd name="1" x="-2.286" y="-3.1496" dx="1.4986" dy="2.0066" layer="1"/>
<smd name="2" x="0" y="-3.1496" dx="1.4986" dy="2.0066" layer="1"/>
<smd name="3" x="2.286" y="-3.1496" dx="1.4986" dy="2.0066" layer="1"/>
<smd name="4" x="0" y="3.1496" dx="3.81" dy="2.0066" layer="1"/>
<text x="-1.905" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<rectangle x1="-1.524" y1="1.778" x2="1.524" y2="3.302" layer="21"/>
<rectangle x1="-2.667" y1="-3.302" x2="-1.905" y2="-1.778" layer="21"/>
<rectangle x1="1.905" y1="-3.302" x2="2.667" y2="-1.778" layer="21"/>
<rectangle x1="-0.381" y1="-3.302" x2="0.381" y2="-1.778" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="74245">
<wire x1="-8.89" y1="15.24" x2="-8.89" y2="-15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="-15.24" x2="-8.89" y2="-15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="-15.24" x2="8.89" y2="15.24" width="0.254" layer="94"/>
<wire x1="8.89" y1="15.24" x2="-8.89" y2="15.24" width="0.254" layer="94"/>
<text x="-8.89" y="16.51" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-17.78" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A1" x="-13.97" y="5.08" length="middle" swaplevel="1"/>
<pin name="A2" x="-13.97" y="2.54" length="middle" swaplevel="1"/>
<pin name="A3" x="-13.97" y="0" length="middle" swaplevel="1"/>
<pin name="A4" x="-13.97" y="-2.54" length="middle" swaplevel="1"/>
<pin name="A5" x="-13.97" y="-5.08" length="middle" swaplevel="1"/>
<pin name="A6" x="-13.97" y="-7.62" length="middle" swaplevel="1"/>
<pin name="A7" x="-13.97" y="-10.16" length="middle" swaplevel="1"/>
<pin name="A8" x="-13.97" y="-12.7" length="middle" swaplevel="1"/>
<pin name="!OE" x="-13.97" y="12.7" length="middle" direction="in" swaplevel="1"/>
<pin name="DIR" x="-13.97" y="10.16" length="middle" direction="in" swaplevel="1"/>
<pin name="B1" x="13.97" y="5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="B2" x="13.97" y="2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="B3" x="13.97" y="0" length="middle" swaplevel="1" rot="R180"/>
<pin name="B4" x="13.97" y="-2.54" length="middle" swaplevel="1" rot="R180"/>
<pin name="B5" x="13.97" y="-5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="B6" x="13.97" y="-7.62" length="middle" swaplevel="1" rot="R180"/>
<pin name="B7" x="13.97" y="-10.16" length="middle" swaplevel="1" rot="R180"/>
<pin name="B8" x="13.97" y="-12.7" length="middle" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="NAP">
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R270"/>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R90"/>
</symbol>
<symbol name="LR645">
<wire x1="-5.08" y1="3.81" x2="-5.08" y2="-3.81" width="0.254" layer="94"/>
<wire x1="5.08" y1="-3.81" x2="-5.08" y2="-3.81" width="0.254" layer="94"/>
<wire x1="5.08" y1="-3.81" x2="5.08" y2="3.81" width="0.254" layer="94"/>
<wire x1="-5.08" y1="3.81" x2="5.08" y2="3.81" width="0.254" layer="94"/>
<text x="-4.318" y="0.508" size="1.524" layer="94">IN</text>
<text x="0.508" y="0.508" size="1.524" layer="94">OUT</text>
<text x="-2.032" y="-3.048" size="1.524" layer="94">GND</text>
<text x="-5.08" y="7.62" size="1.524" layer="95">&gt;NAME</text>
<text x="-5.08" y="5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="IN" x="-7.62" y="1.27" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="OUT" x="7.62" y="1.27" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="GND" x="0" y="-6.35" visible="pad" length="short" direction="pas" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="74245" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="74245" x="0" y="0"/>
<gate name="P" symbol="NAP" x="-26.67" y="0" addlevel="request"/>
</gates>
<devices>
<device name="-NS" package="SO20">
<connects>
<connect gate="A" pin="!OE" pad="19"/>
<connect gate="A" pin="A1" pad="2"/>
<connect gate="A" pin="A2" pad="3"/>
<connect gate="A" pin="A3" pad="4"/>
<connect gate="A" pin="A4" pad="5"/>
<connect gate="A" pin="A5" pad="6"/>
<connect gate="A" pin="A6" pad="7"/>
<connect gate="A" pin="A7" pad="8"/>
<connect gate="A" pin="A8" pad="9"/>
<connect gate="A" pin="B1" pad="18"/>
<connect gate="A" pin="B2" pad="17"/>
<connect gate="A" pin="B3" pad="16"/>
<connect gate="A" pin="B4" pad="15"/>
<connect gate="A" pin="B5" pad="14"/>
<connect gate="A" pin="B6" pad="13"/>
<connect gate="A" pin="B7" pad="12"/>
<connect gate="A" pin="B8" pad="11"/>
<connect gate="A" pin="DIR" pad="1"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-PW" package="TSSOP20">
<connects>
<connect gate="A" pin="!OE" pad="19"/>
<connect gate="A" pin="A1" pad="2"/>
<connect gate="A" pin="A2" pad="3"/>
<connect gate="A" pin="A3" pad="4"/>
<connect gate="A" pin="A4" pad="5"/>
<connect gate="A" pin="A5" pad="6"/>
<connect gate="A" pin="A6" pad="7"/>
<connect gate="A" pin="A7" pad="8"/>
<connect gate="A" pin="A8" pad="9"/>
<connect gate="A" pin="B1" pad="18"/>
<connect gate="A" pin="B2" pad="17"/>
<connect gate="A" pin="B3" pad="16"/>
<connect gate="A" pin="B4" pad="15"/>
<connect gate="A" pin="B5" pad="14"/>
<connect gate="A" pin="B6" pad="13"/>
<connect gate="A" pin="B7" pad="12"/>
<connect gate="A" pin="B8" pad="11"/>
<connect gate="A" pin="DIR" pad="1"/>
<connect gate="P" pin="GND" pad="10"/>
<connect gate="P" pin="VCC" pad="20"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LDL1117" prefix="IC" uservalue="yes">
<description>LDO, fixed voltage, input 18V max., 1,2A, high PSRR, ST</description>
<gates>
<gate name="A" symbol="LR645" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SOT223">
<connects>
<connect gate="A" pin="GND" pad="1"/>
<connect gate="A" pin="IN" pad="3"/>
<connect gate="A" pin="OUT" pad="2 4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="74499">
<packages>
<package name="SSOP8">
<wire x1="-1.5" y1="1.5" x2="1.5" y2="1.5" width="0.254" layer="21"/>
<wire x1="1.5" y1="1.5" x2="1.5" y2="-1.5" width="0.254" layer="21"/>
<wire x1="1.5" y1="-1.5" x2="-1.5" y2="-1.5" width="0.254" layer="21"/>
<wire x1="-1.5" y1="-1.5" x2="-1.5" y2="1.5" width="0.254" layer="21"/>
<wire x1="-1.5" y1="2.7432" x2="1.5" y2="2.7432" width="0.2032" layer="51"/>
<wire x1="1.5" y1="2.7432" x2="1.5" y2="-2.7432" width="0.2032" layer="51"/>
<wire x1="1.5" y1="-2.7432" x2="-1.5" y2="-2.7432" width="0.2032" layer="51"/>
<wire x1="-1.5" y1="-2.7432" x2="-1.5" y2="-0.5" width="0.2032" layer="51"/>
<wire x1="-1.5" y1="-0.5" x2="-1" y2="-0.5" width="0.2032" layer="51"/>
<wire x1="-1" y1="-0.5" x2="-1" y2="0.5" width="0.2032" layer="51"/>
<wire x1="-1" y1="0.5" x2="-1.5" y2="0.5" width="0.2032" layer="51"/>
<wire x1="-1.5" y1="0.5" x2="-1.5" y2="2.7432" width="0.2032" layer="51"/>
<circle x="-0.8499" y="-0.85" radius="0.254" width="0.254" layer="21"/>
<smd name="1" x="-0.975" y="-1.9" dx="0.4" dy="1.1" layer="1"/>
<smd name="2" x="-0.325" y="-1.9" dx="0.4" dy="1.1" layer="1"/>
<smd name="3" x="0.325" y="-1.9" dx="0.4" dy="1.1" layer="1"/>
<smd name="4" x="0.975" y="-1.9" dx="0.4" dy="1.1" layer="1"/>
<smd name="5" x="0.975" y="1.9" dx="0.4" dy="1.1" layer="1" rot="R180"/>
<smd name="6" x="0.325" y="1.9" dx="0.4" dy="1.1" layer="1" rot="R180"/>
<smd name="7" x="-0.325" y="1.9" dx="0.4" dy="1.1" layer="1" rot="R180"/>
<smd name="8" x="-0.975" y="1.9" dx="0.4" dy="1.1" layer="1" rot="R180"/>
<text x="-1.27" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.27" y="-0.762" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="-1.125" y1="-2.05" x2="-0.825" y2="-1.5" layer="21"/>
<rectangle x1="-0.475" y1="-2.05" x2="-0.175" y2="-1.5" layer="21"/>
<rectangle x1="0.175" y1="-2.05" x2="0.475" y2="-1.5" layer="21"/>
<rectangle x1="0.825" y1="-2.05" x2="1.125" y2="-1.5" layer="21"/>
<rectangle x1="0.825" y1="1.5" x2="1.125" y2="2.05" layer="21" rot="R180"/>
<rectangle x1="0.175" y1="1.5" x2="0.475" y2="2.05" layer="21" rot="R180"/>
<rectangle x1="-0.475" y1="1.5" x2="-0.175" y2="2.05" layer="21" rot="R180"/>
<rectangle x1="-1.125" y1="1.5" x2="-0.825" y2="2.05" layer="21" rot="R180"/>
</package>
<package name="DIL14">
<wire x1="-1.905" y1="1.27" x2="17.145" y2="1.27" width="0.254" layer="21"/>
<wire x1="17.145" y1="1.27" x2="17.145" y2="6.35" width="0.254" layer="21"/>
<wire x1="17.145" y1="6.35" x2="-1.905" y2="6.35" width="0.254" layer="21"/>
<wire x1="-1.905" y1="6.35" x2="-1.905" y2="5.08" width="0.254" layer="21"/>
<wire x1="-1.905" y1="5.08" x2="-0.635" y2="5.08" width="0.254" layer="21"/>
<wire x1="-0.635" y1="5.08" x2="-0.635" y2="2.54" width="0.254" layer="21"/>
<wire x1="-0.635" y1="2.54" x2="-1.905" y2="2.54" width="0.254" layer="21"/>
<wire x1="-1.905" y1="2.54" x2="-1.905" y2="1.27" width="0.254" layer="21"/>
<wire x1="17.78" y1="-1.27" x2="17.78" y2="8.89" width="0.2032" layer="51"/>
<wire x1="17.78" y1="8.89" x2="-2.54" y2="8.89" width="0.2032" layer="51"/>
<wire x1="-2.54" y1="8.89" x2="-2.54" y2="5.08" width="0.2032" layer="51"/>
<wire x1="-2.54" y1="5.08" x2="-1.27" y2="5.08" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="5.08" x2="-1.27" y2="2.54" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="2.54" x2="-2.54" y2="2.54" width="0.2032" layer="51"/>
<wire x1="-2.54" y1="2.54" x2="-2.54" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-2.54" y1="-1.27" x2="17.78" y2="-1.27" width="0.2032" layer="51"/>
<pad name="1" x="0" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="3" x="5.08" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="4" x="7.62" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="5" x="10.16" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="6" x="12.7" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="7" x="15.24" y="0" drill="0.8128" diameter="1.4986"/>
<pad name="8" x="15.24" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="9" x="12.7" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="10" x="10.16" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="11" x="7.62" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="12" x="5.08" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="13" x="2.54" y="7.62" drill="0.8128" diameter="1.4986"/>
<pad name="14" x="0" y="7.62" drill="0.8128" diameter="1.4986"/>
<text x="5.08" y="4.445" size="1.27" layer="25">&gt;NAME</text>
<text x="5.08" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="5.08" y="3.175" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="TSSOP14">
<wire x1="-2.325" y1="2.25" x2="2.325" y2="2.25" width="0.254" layer="21"/>
<wire x1="2.325" y1="2.25" x2="2.325" y2="-2.25" width="0.254" layer="21"/>
<wire x1="2.325" y1="-2.25" x2="-2.325" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-2.325" y1="-2.25" x2="-2.325" y2="2.25" width="0.254" layer="21"/>
<wire x1="-2.454" y1="3.81" x2="2.454" y2="3.81" width="0.2032" layer="51"/>
<wire x1="2.454" y1="3.81" x2="2.454" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="2.454" y1="-3.81" x2="-2.454" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-2.454" y1="-3.81" x2="-2.454" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-2.454" y1="-0.635" x2="-2.0984" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-2.0984" y1="-0.635" x2="-2.0984" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-2.0984" y1="0.635" x2="-2.454" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-2.454" y1="0.635" x2="-2.454" y2="3.81" width="0.2032" layer="51"/>
<circle x="-1.525" y="-1.45" radius="0.3535" width="0.254" layer="21"/>
<smd name="1" x="-1.95" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="2" x="-1.3" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="3" x="-0.65" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="4" x="0" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="5" x="0.65" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="6" x="1.3" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="7" x="1.95" y="-2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="8" x="1.95" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="9" x="1.3" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="10" x="0.65" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="11" x="0" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="12" x="-0.65" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="13" x="-1.3" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<smd name="14" x="-1.95" y="2.9" dx="0.4" dy="1.2" layer="1"/>
<text x="-0.915" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-0.915" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-0.915" y="-0.762" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="1.8001" y1="2.2" x2="2.1001" y2="3.2" layer="21"/>
<rectangle x1="1.8001" y1="-3.2" x2="2.1001" y2="-2.2" layer="21"/>
<rectangle x1="1.1501" y1="2.2" x2="1.4501" y2="3.2" layer="21"/>
<rectangle x1="0.5001" y1="2.2" x2="0.8001" y2="3.2" layer="21"/>
<rectangle x1="-0.1499" y1="2.2" x2="0.1501" y2="3.2" layer="21"/>
<rectangle x1="-0.7999" y1="2.2" x2="-0.4999" y2="3.2" layer="21"/>
<rectangle x1="-1.4499" y1="2.2" x2="-1.1499" y2="3.2" layer="21"/>
<rectangle x1="-2.0999" y1="2.2" x2="-1.7999" y2="3.2" layer="21"/>
<rectangle x1="-2.0999" y1="-3.2" x2="-1.7999" y2="-2.2" layer="21"/>
<rectangle x1="-1.4499" y1="-3.2" x2="-1.1499" y2="-2.2" layer="21"/>
<rectangle x1="-0.7999" y1="-3.2" x2="-0.4999" y2="-2.2" layer="21"/>
<rectangle x1="-0.1499" y1="-3.2" x2="0.1501" y2="-2.2" layer="21"/>
<rectangle x1="0.5001" y1="-3.2" x2="0.8001" y2="-2.2" layer="21"/>
<rectangle x1="1.1501" y1="-3.2" x2="1.4501" y2="-2.2" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="PWRN">
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" rot="R90"/>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" rot="R270"/>
</symbol>
<symbol name="74125">
<wire x1="5.08" y1="0" x2="-5.08" y2="5.08" width="0.254" layer="94"/>
<wire x1="5.08" y1="0" x2="-5.08" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-5.08" y1="-5.08" x2="-5.08" y2="5.08" width="0.254" layer="94"/>
<wire x1="0" y1="4.318" x2="0" y2="5.08" width="0.1524" layer="94"/>
<circle x="0" y="3.556" radius="0.762" width="0.1524" layer="94"/>
<text x="1.27" y="5.08" size="1.524" layer="95">&gt;NAME</text>
<text x="0" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="OE" x="0" y="5.08" visible="pad" length="point" direction="in" rot="R270"/>
<pin name="I" x="-7.62" y="0" visible="pad" length="short" direction="in"/>
<pin name="O" x="7.62" y="0" visible="pad" length="short" direction="hiz" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="742G125" prefix="IC" uservalue="yes">
<gates>
<gate name="P" symbol="PWRN" x="-7.62" y="0" addlevel="request"/>
<gate name="A" symbol="74125" x="19.05" y="0" swaplevel="1"/>
<gate name="B" symbol="74125" x="19.05" y="-24.13" swaplevel="1"/>
</gates>
<devices>
<device name="-DP" package="SSOP8">
<connects>
<connect gate="A" pin="I" pad="2"/>
<connect gate="A" pin="O" pad="6"/>
<connect gate="A" pin="OE" pad="1"/>
<connect gate="B" pin="I" pad="5"/>
<connect gate="B" pin="O" pad="3"/>
<connect gate="B" pin="OE" pad="7"/>
<connect gate="P" pin="GND" pad="4"/>
<connect gate="P" pin="VCC" pad="8"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="74125" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="74125" x="17.78" y="0" swaplevel="1"/>
<gate name="B" symbol="74125" x="17.78" y="-30.48" swaplevel="1"/>
<gate name="C" symbol="74125" x="53.34" y="0" swaplevel="1"/>
<gate name="D" symbol="74125" x="53.34" y="-30.48" swaplevel="1"/>
<gate name="P" symbol="PWRN" x="-5.08" y="0" addlevel="request"/>
</gates>
<devices>
<device name="-N" package="DIL14">
<connects>
<connect gate="A" pin="I" pad="2"/>
<connect gate="A" pin="O" pad="3"/>
<connect gate="A" pin="OE" pad="1"/>
<connect gate="B" pin="I" pad="5"/>
<connect gate="B" pin="O" pad="6"/>
<connect gate="B" pin="OE" pad="4"/>
<connect gate="C" pin="I" pad="9"/>
<connect gate="C" pin="O" pad="8"/>
<connect gate="C" pin="OE" pad="10"/>
<connect gate="D" pin="I" pad="12"/>
<connect gate="D" pin="O" pad="11"/>
<connect gate="D" pin="OE" pad="13"/>
<connect gate="P" pin="GND" pad="7"/>
<connect gate="P" pin="VCC" pad="14"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-DT" package="TSSOP14">
<connects>
<connect gate="A" pin="I" pad="2"/>
<connect gate="A" pin="O" pad="3"/>
<connect gate="A" pin="OE" pad="1"/>
<connect gate="B" pin="I" pad="5"/>
<connect gate="B" pin="O" pad="6"/>
<connect gate="B" pin="OE" pad="4"/>
<connect gate="C" pin="I" pad="9"/>
<connect gate="C" pin="O" pad="8"/>
<connect gate="C" pin="OE" pad="10"/>
<connect gate="D" pin="I" pad="12"/>
<connect gate="D" pin="O" pad="11"/>
<connect gate="D" pin="OE" pad="13"/>
<connect gate="P" pin="GND" pad="7"/>
<connect gate="P" pin="VCC" pad="14"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="PASIV">
<packages>
<package name="X-5032">
<wire x1="-3.2004" y1="-2.0955" x2="3.2004" y2="-2.0955" width="0.2032" layer="51"/>
<wire x1="3.2004" y1="-2.0955" x2="3.2004" y2="2.0955" width="0.2032" layer="51"/>
<wire x1="3.2004" y1="2.0955" x2="-3.2004" y2="2.0955" width="0.2032" layer="51"/>
<wire x1="-3.2004" y1="2.0955" x2="-3.2004" y2="0.2921" width="0.2032" layer="51"/>
<wire x1="-3.2004" y1="-0.2921" x2="-3.2004" y2="-2.0955" width="0.2032" layer="51"/>
<wire x1="-3.2004" y1="0.2921" x2="-2.9464" y2="0.2921" width="0.2032" layer="51"/>
<wire x1="-2.9464" y1="0.2921" x2="-2.9464" y2="-0.2921" width="0.2032" layer="51"/>
<wire x1="-2.9464" y1="-0.2921" x2="-3.2004" y2="-0.2921" width="0.2032" layer="51"/>
<wire x1="-2.4892" y1="-1.6002" x2="2.4892" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="2.4892" y1="-1.6002" x2="2.4892" y2="1.6002" width="0.254" layer="21"/>
<wire x1="2.4892" y1="1.6002" x2="-2.4892" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.4892" y1="1.6002" x2="-2.4892" y2="-1.6002" width="0.254" layer="21"/>
<circle x="-1.778" y="-0.9525" radius="0.254" width="0.254" layer="21"/>
<smd name="1" x="-2.0066" y="-1.1938" dx="1.778" dy="1.1938" layer="1"/>
<smd name="2" x="2.0066" y="-1.1938" dx="1.778" dy="1.1938" layer="1"/>
<smd name="4" x="-2.0066" y="1.1938" dx="1.778" dy="1.1938" layer="1"/>
<smd name="3" x="2.0066" y="1.1938" dx="1.778" dy="1.1938" layer="1"/>
<text x="-1.905" y="0.762" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-1.143" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="3.175" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
</package>
<package name="X-3225-2">
<description>pouzdro 3.2 x 2.5</description>
<smd name="1" x="-1.1" y="-0.8" dx="1.4" dy="1" layer="1"/>
<smd name="2" x="1.1" y="-0.8" dx="1.4" dy="1" layer="1"/>
<smd name="3" x="1.1" y="0.8" dx="1.4" dy="1" layer="1"/>
<smd name="4" x="-1.1" y="0.8" dx="1.4" dy="1" layer="1"/>
<wire x1="-1.7" y1="-1.35" x2="1.7" y2="-1.35" width="0.1524" layer="21"/>
<wire x1="1.7" y1="-1.35" x2="1.7" y2="1.35" width="0.1524" layer="21"/>
<wire x1="1.7" y1="1.35" x2="-1.7" y2="1.35" width="0.1524" layer="21"/>
<wire x1="-1.7" y1="1.35" x2="-1.7" y2="-1.35" width="0.1524" layer="21"/>
<circle x="-1.25" y="-0.85" radius="0.15" width="0.1524" layer="21"/>
<wire x1="-2.104896875" y1="1.6049" x2="-2.104896875" y2="-1.6049" width="0.2032" layer="51"/>
<wire x1="-2.104896875" y1="-1.6049" x2="2.104896875" y2="-1.6049" width="0.2032" layer="51"/>
<wire x1="2.104896875" y1="-1.6049" x2="2.104896875" y2="1.6049" width="0.2032" layer="51"/>
<wire x1="2.104896875" y1="1.6049" x2="-2.104896875" y2="1.6049" width="0.2032" layer="51"/>
<text x="-2.54" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="1.905" size="1.016" layer="25">&gt;VALUE</text>
<text x="-2.54" y="2.54" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-2.257296875" y1="-1.091946875" x2="-2.257296875" y2="-1.7573" width="0.2032" layer="51"/>
<wire x1="-2.257296875" y1="-1.7573" x2="-1.491996875" y2="-1.7573" width="0.2032" layer="51"/>
</package>
<package name="TL-4020">
<wire x1="-2.8956" y1="-2.1" x2="2.8956" y2="-2.1" width="0.2032" layer="51"/>
<wire x1="2.8956" y1="-2.1" x2="2.8956" y2="2.1" width="0.2032" layer="51"/>
<wire x1="2.8956" y1="2.1" x2="-2.8956" y2="2.1" width="0.2032" layer="51"/>
<wire x1="-2.8956" y1="2.1" x2="-2.8956" y2="-2.1" width="0.2032" layer="51"/>
<smd name="1" x="-1.85" y="0" dx="1.5" dy="2.5" layer="1"/>
<smd name="2" x="1.85" y="0" dx="1.5" dy="2.5" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="2.54" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-2.2" y1="2.1" x2="2.2" y2="2.1" width="0.254" layer="21"/>
<wire x1="2.2" y1="2.1" x2="2.2" y2="-2.1" width="0.254" layer="21"/>
<wire x1="2.2" y1="-2.1" x2="-2.2" y2="-2.1" width="0.254" layer="21"/>
<wire x1="-2.2" y1="-2.1" x2="-2.2" y2="2.1" width="0.254" layer="21"/>
<wire x1="-2.35" y1="1" x2="-2.35" y2="-1" width="0.254" layer="21"/>
<wire x1="2.35" y1="-1" x2="2.35" y2="1" width="0.254" layer="21"/>
</package>
<package name="TL-6045TA">
<wire x1="-3.5687" y1="-3.302" x2="3.5687" y2="-3.302" width="0.2032" layer="51"/>
<wire x1="3.5687" y1="-3.302" x2="3.5687" y2="3.302" width="0.2032" layer="51"/>
<wire x1="3.5687" y1="3.302" x2="-3.5687" y2="3.302" width="0.2032" layer="51"/>
<wire x1="-3.5687" y1="3.302" x2="-3.5687" y2="-3.302" width="0.2032" layer="51"/>
<smd name="1" x="-2.075" y="0" dx="2.35" dy="5.1" layer="1"/>
<smd name="2" x="2.075" y="0" dx="2.35" dy="5.1" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-3" y1="2.4" x2="-3" y2="-2.4" width="0.254" layer="21"/>
<wire x1="-1.1" y1="-3" x2="1.1" y2="-3" width="0.254" layer="21"/>
<wire x1="-1.1" y1="3" x2="1.1" y2="3" width="0.254" layer="21"/>
<wire x1="3" y1="2.4" x2="3" y2="-2.4" width="0.254" layer="21"/>
<wire x1="-1.1" y1="3" x2="-1.7" y2="2.4" width="0.254" layer="21"/>
<wire x1="-1.7" y1="2.4" x2="-2.8" y2="2.4" width="0.254" layer="21"/>
<wire x1="-2.8" y1="2.4" x2="-3" y2="2.4" width="0.254" layer="21"/>
<wire x1="1.1" y1="3" x2="1.7" y2="2.4" width="0.254" layer="21"/>
<wire x1="1.7" y1="2.4" x2="2.8" y2="2.4" width="0.254" layer="21"/>
<wire x1="2.8" y1="2.4" x2="3" y2="2.4" width="0.254" layer="21"/>
<wire x1="-1.1" y1="-3" x2="-1.7" y2="-2.4" width="0.254" layer="21"/>
<wire x1="-1.7" y1="-2.4" x2="-2.8" y2="-2.4" width="0.254" layer="21"/>
<wire x1="-2.8" y1="-2.4" x2="-3" y2="-2.4" width="0.254" layer="21"/>
<wire x1="1.1" y1="-3" x2="1.7" y2="-2.4" width="0.254" layer="21"/>
<wire x1="1.7" y1="-2.4" x2="2.8" y2="-2.4" width="0.254" layer="21"/>
<wire x1="2.8" y1="-2.4" x2="3" y2="-2.4" width="0.254" layer="21"/>
<wire x1="-2.8" y1="2.4" x2="-2.8" y2="-2.4" width="0.254" layer="21"/>
<wire x1="2.8" y1="2.4" x2="2.8" y2="-2.4" width="0.254" layer="21"/>
</package>
<package name="TL-7335">
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-3.81" y1="2.54" x2="-2.54" y2="3.81" width="0.2032" layer="51" curve="-90"/>
<wire x1="3.81" y1="-2.54" x2="2.54" y2="-3.81" width="0.2032" layer="51" curve="-90"/>
<wire x1="-2.54" y1="-3.81" x2="-3.81" y2="-2.54" width="0.2032" layer="51" curve="-90"/>
<wire x1="2.54" y1="3.81" x2="3.81" y2="2.54" width="0.2032" layer="51" curve="-90"/>
<wire x1="-2.54" y1="3.81" x2="2.54" y2="3.81" width="0.2032" layer="51"/>
<wire x1="2.54" y1="-3.81" x2="-2.54" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-2.54" y1="3.81" x2="2.54" y2="3.81" width="0.254" layer="21"/>
<wire x1="3.81" y1="2.54" x2="3.81" y2="-2.54" width="0.254" layer="21"/>
<wire x1="2.54" y1="-3.81" x2="-2.54" y2="-3.81" width="0.254" layer="21"/>
<wire x1="-3.81" y1="-2.54" x2="-3.81" y2="2.54" width="0.254" layer="21"/>
<wire x1="-3.81" y1="2.54" x2="-2.54" y2="3.81" width="0.254" layer="21" curve="-90"/>
<wire x1="-2.54" y1="-3.81" x2="-3.81" y2="-2.54" width="0.254" layer="21" curve="-90"/>
<wire x1="3.81" y1="-2.54" x2="2.54" y2="-3.81" width="0.254" layer="21" curve="-90"/>
<wire x1="2.54" y1="3.81" x2="3.81" y2="2.54" width="0.254" layer="21" curve="-90"/>
<smd name="1" x="-2.921" y="0" dx="2.2098" dy="2.2098" layer="1"/>
<smd name="2" x="2.921" y="0" dx="2.2098" dy="2.2098" layer="1"/>
<wire x1="-3.81" y1="2.54" x2="-3.81" y2="1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="2.54" x2="3.81" y2="1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-2.54" x2="3.81" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-3.81" y1="-2.54" x2="-3.81" y2="-1.27" width="0.2032" layer="51"/>
<circle x="0" y="0" radius="3.175" width="0.2032" layer="21"/>
</package>
<package name="TL-8080">
<wire x1="-4.064" y1="-4.318" x2="4.064" y2="-4.318" width="0.2032" layer="51"/>
<wire x1="4.064" y1="-4.318" x2="4.064" y2="4.318" width="0.2032" layer="51"/>
<wire x1="4.064" y1="4.318" x2="-4.064" y2="4.318" width="0.2032" layer="51"/>
<wire x1="-4.064" y1="4.318" x2="-4.064" y2="-4.318" width="0.2032" layer="51"/>
<smd name="1" x="-2.5781" y="0" dx="1.778" dy="7.0104" layer="1"/>
<smd name="2" x="2.5781" y="0" dx="1.778" dy="7.0104" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.81" y="5.08" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-4.064" y1="-4.318" x2="4.064" y2="-4.318" width="0.2032" layer="21"/>
<wire x1="4.064" y1="-4.318" x2="4.064" y2="4.318" width="0.2032" layer="21"/>
<wire x1="4.064" y1="4.318" x2="-4.064" y2="4.318" width="0.2032" layer="21"/>
<wire x1="-4.064" y1="4.318" x2="-4.064" y2="-4.318" width="0.2032" layer="21"/>
</package>
<package name="TL-1812">
<wire x1="-3.3528" y1="-2.794" x2="3.3528" y2="-2.794" width="0.2032" layer="51"/>
<wire x1="3.3528" y1="-2.794" x2="3.3528" y2="2.794" width="0.2032" layer="51"/>
<wire x1="3.3528" y1="2.794" x2="-3.3528" y2="2.794" width="0.2032" layer="51"/>
<wire x1="-3.3528" y1="2.794" x2="-3.3528" y2="-2.794" width="0.2032" layer="51"/>
<wire x1="-2.4638" y1="-2.54" x2="2.4638" y2="-2.54" width="0.254" layer="21"/>
<wire x1="2.9718" y1="-2.032" x2="2.9718" y2="2.032" width="0.254" layer="21"/>
<wire x1="2.4638" y1="2.54" x2="-2.4638" y2="2.54" width="0.254" layer="21"/>
<wire x1="-2.9718" y1="2.032" x2="-2.9718" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-2.9718" y1="-2.032" x2="-2.4638" y2="-2.54" width="0.254" layer="21" curve="90"/>
<wire x1="-2.9718" y1="2.032" x2="-2.4638" y2="2.54" width="0.254" layer="21" curve="-90"/>
<wire x1="2.4638" y1="-2.54" x2="2.9718" y2="-2.032" width="0.254" layer="21" curve="90"/>
<wire x1="2.4638" y1="2.54" x2="2.9718" y2="2.032" width="0.254" layer="21" curve="-90"/>
<smd name="1" x="-2.2225" y="0" dx="1.524" dy="3.048" layer="1"/>
<smd name="2" x="2.2225" y="0" dx="1.524" dy="3.048" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="TL-1260">
<wire x1="-6.35" y1="-4.445" x2="-6.35" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-6.35" y1="3.81" x2="-6.35" y2="4.445" width="0.2032" layer="51"/>
<wire x1="-4.445" y1="6.35" x2="4.445" y2="6.35" width="0.2032" layer="51"/>
<wire x1="6.35" y1="4.445" x2="6.35" y2="3.81" width="0.2032" layer="51"/>
<wire x1="6.35" y1="-3.81" x2="6.35" y2="-4.445" width="0.2032" layer="51"/>
<wire x1="4.445" y1="-6.35" x2="-4.445" y2="-6.35" width="0.2032" layer="51"/>
<wire x1="-6.35" y1="-4.445" x2="-6.35" y2="4.445" width="0.254" layer="21"/>
<wire x1="-4.445" y1="6.35" x2="4.445" y2="6.35" width="0.254" layer="21"/>
<wire x1="6.35" y1="4.445" x2="6.35" y2="-4.445" width="0.254" layer="21"/>
<wire x1="4.445" y1="-6.35" x2="-4.445" y2="-6.35" width="0.254" layer="21"/>
<wire x1="-6.35" y1="-4.445" x2="-4.445" y2="-6.35" width="0.254" layer="21" curve="90"/>
<wire x1="4.445" y1="6.35" x2="6.35" y2="4.445" width="0.254" layer="21" curve="-90"/>
<wire x1="-6.35" y1="4.445" x2="-4.445" y2="6.35" width="0.254" layer="21" curve="-90"/>
<wire x1="4.445" y1="-6.35" x2="6.35" y2="-4.445" width="0.254" layer="21" curve="90"/>
<wire x1="-4.445" y1="-3.175" x2="-3.175" y2="-4.445" width="0.0254" layer="21" curve="233.130102"/>
<wire x1="-4.445" y1="3.175" x2="-3.175" y2="4.445" width="0.0254" layer="21" curve="-233.130102"/>
<wire x1="3.175" y1="4.445" x2="4.445" y2="3.175" width="0.0254" layer="21" curve="-233.130102"/>
<wire x1="3.175" y1="-4.445" x2="4.445" y2="-3.175" width="0.0254" layer="21" curve="233.130102"/>
<wire x1="-4.445" y1="-3.175" x2="-4.445" y2="3.175" width="0.0254" layer="21" curve="-71.075356"/>
<wire x1="-3.175" y1="-4.445" x2="3.175" y2="-4.445" width="0.0254" layer="21" curve="71.075356"/>
<wire x1="4.445" y1="-3.175" x2="4.445" y2="3.175" width="0.0254" layer="21" curve="71.075356"/>
<wire x1="-3.175" y1="4.445" x2="3.175" y2="4.445" width="0.0254" layer="21" curve="-71.075356"/>
<wire x1="-6.35" y1="4.445" x2="-4.445" y2="6.35" width="0.2032" layer="51" curve="-90"/>
<wire x1="-6.35" y1="-4.445" x2="-4.445" y2="-6.35" width="0.2032" layer="51" curve="90"/>
<wire x1="4.445" y1="-6.35" x2="6.35" y2="-4.445" width="0.2032" layer="51" curve="90"/>
<wire x1="4.445" y1="6.35" x2="6.35" y2="4.445" width="0.2032" layer="51" curve="-90"/>
<circle x="0" y="0" radius="5.08" width="0.0254" layer="21"/>
<smd name="1" x="-4.445" y="0" dx="3.9878" dy="5.5118" layer="1"/>
<smd name="2" x="4.445" y="0" dx="3.9878" dy="5.5118" layer="1"/>
<text x="0" y="-1.905" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.905" size="1.016" layer="27" rot="R90">&gt;VALUE</text>
<text x="0" y="-1.905" size="1.27" layer="51" ratio="12" rot="R90">&gt;NAME</text>
</package>
<package name="TL-2424">
<wire x1="-3.4671" y1="-3.302" x2="3.4671" y2="-3.302" width="0.2032" layer="51"/>
<wire x1="3.4671" y1="-3.302" x2="3.4671" y2="3.302" width="0.2032" layer="51"/>
<wire x1="3.4671" y1="3.302" x2="-3.4671" y2="3.302" width="0.2032" layer="51"/>
<wire x1="-3.4671" y1="3.302" x2="-3.4671" y2="-3.302" width="0.2032" layer="51"/>
<smd name="1" x="-2.15" y="0" dx="2" dy="6" layer="1"/>
<smd name="2" x="2.15" y="0" dx="2" dy="6" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-3" y1="1.6" x2="-3" y2="-1.6" width="0.254" layer="21"/>
<wire x1="-1.6" y1="-3" x2="1.6" y2="-3" width="0.254" layer="21"/>
<wire x1="-1.6" y1="3" x2="1.6" y2="3" width="0.254" layer="21"/>
<wire x1="3" y1="1.6" x2="3" y2="-1.6" width="0.254" layer="21"/>
<wire x1="-3" y1="1.6" x2="-1.6" y2="3" width="0.254" layer="21" curve="-35.362462"/>
<wire x1="-1.6" y1="-3" x2="-3" y2="-1.6" width="0.254" layer="21" curve="-35.362462"/>
<wire x1="3" y1="-1.6" x2="1.6" y2="-3" width="0.254" layer="21" curve="-35.362462"/>
<wire x1="1.6" y1="3" x2="3" y2="1.6" width="0.254" layer="21" curve="-35.362462"/>
</package>
<package name="TL-2323">
<wire x1="-3.3147" y1="-3.2004" x2="3.3147" y2="-3.2004" width="0.2032" layer="51"/>
<wire x1="3.3147" y1="-3.2004" x2="3.3147" y2="3.2004" width="0.2032" layer="51"/>
<wire x1="3.3147" y1="3.2004" x2="-3.3147" y2="3.2004" width="0.2032" layer="51"/>
<wire x1="-3.3147" y1="3.2004" x2="-3.3147" y2="-3.2004" width="0.2032" layer="51"/>
<smd name="1" x="-1.95" y="0" dx="2.1" dy="5.8" layer="1"/>
<smd name="2" x="1.95" y="0" dx="2.1" dy="5.8" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<circle x="0" y="0" radius="2.9" width="0.254" layer="21"/>
</package>
<package name="TL-1583">
<wire x1="-7.5" y1="-4.445" x2="-7.5" y2="4.445" width="0.254" layer="21"/>
<wire x1="7.5" y1="4.445" x2="7.5" y2="-4.445" width="0.254" layer="21"/>
<wire x1="4.445" y1="-7.5" x2="-4.445" y2="-7.5" width="0.254" layer="21"/>
<wire x1="-7.5" y1="-4.445" x2="-4.445" y2="-7.5" width="0.254" layer="21" curve="90"/>
<wire x1="4.445" y1="7.5" x2="7.5" y2="4.445" width="0.254" layer="21" curve="-90"/>
<wire x1="-7.5" y1="4.445" x2="-4.445" y2="7.5" width="0.254" layer="21" curve="-90"/>
<wire x1="4.445" y1="-7.5" x2="7.5" y2="-4.445" width="0.254" layer="21" curve="90"/>
<wire x1="-4.445" y1="-3.175" x2="-3.175" y2="-4.445" width="0.0254" layer="21" curve="233.130102"/>
<wire x1="-4.445" y1="3.175" x2="-3.175" y2="4.445" width="0.0254" layer="21" curve="-233.130102"/>
<wire x1="3.175" y1="4.445" x2="4.445" y2="3.175" width="0.0254" layer="21" curve="-233.130102"/>
<wire x1="3.175" y1="-4.445" x2="4.445" y2="-3.175" width="0.0254" layer="21" curve="233.130102"/>
<wire x1="-4.445" y1="-3.175" x2="-4.445" y2="3.175" width="0.0254" layer="21" curve="-71.075356"/>
<wire x1="-3.175" y1="-4.445" x2="3.175" y2="-4.445" width="0.0254" layer="21" curve="71.075356"/>
<wire x1="4.445" y1="-3.175" x2="4.445" y2="3.175" width="0.0254" layer="21" curve="71.075356"/>
<wire x1="-3.175" y1="4.445" x2="3.175" y2="4.445" width="0.0254" layer="21" curve="-71.075356"/>
<circle x="0" y="0" radius="5.08" width="0.0254" layer="21"/>
<smd name="1" x="-5.75" y="0" dx="3.8" dy="6" layer="1"/>
<smd name="2" x="5.75" y="0" dx="3.8" dy="6" layer="1"/>
<text x="0" y="-1.905" size="1.27" layer="25" rot="R90">&gt;NAME</text>
<text x="1.27" y="-1.905" size="1.016" layer="27" rot="R90">&gt;VALUE</text>
<text x="0" y="-1.905" size="1.27" layer="51" ratio="12" rot="R90">&gt;NAME</text>
<wire x1="-4.445" y1="7.5" x2="4.445" y2="7.5" width="0.254" layer="21"/>
<wire x1="-4.695" y1="7.75" x2="4.695" y2="7.75" width="0.254" layer="51"/>
<wire x1="-7.75" y1="4.695" x2="-4.695" y2="7.75" width="0.254" layer="51" curve="-90"/>
<wire x1="-7.75" y1="-4.695" x2="-7.75" y2="4.695" width="0.254" layer="51"/>
<wire x1="7.75" y1="4.695" x2="7.75" y2="-4.695" width="0.254" layer="51"/>
<wire x1="4.695" y1="7.75" x2="7.75" y2="4.695" width="0.254" layer="51" curve="-90"/>
<wire x1="-7.75" y1="-4.695" x2="-4.695" y2="-7.75" width="0.254" layer="51" curve="90"/>
<wire x1="4.695" y1="-7.75" x2="-4.695" y2="-7.75" width="0.254" layer="51"/>
<wire x1="4.695" y1="-7.75" x2="7.75" y2="-4.695" width="0.254" layer="51" curve="90"/>
</package>
<package name="TL-DL16">
<wire x1="-3.7338" y1="-2.4638" x2="3.7338" y2="-2.4638" width="0.2032" layer="51"/>
<wire x1="3.7338" y1="-2.4638" x2="3.7338" y2="2.4638" width="0.2032" layer="51"/>
<wire x1="3.7338" y1="2.4638" x2="-3.7338" y2="2.4638" width="0.2032" layer="51"/>
<wire x1="-3.7338" y1="2.4638" x2="-3.7338" y2="-2.4638" width="0.2032" layer="51"/>
<smd name="1" x="-2.54" y="0" dx="1.778" dy="3.048" layer="1"/>
<smd name="2" x="2.54" y="0" dx="1.778" dy="3.048" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-3.25" y1="1" x2="-1" y2="2.25" width="0.254" layer="21"/>
<wire x1="-1" y1="2.25" x2="1" y2="2.25" width="0.254" layer="21"/>
<wire x1="1" y1="2.25" x2="3.25" y2="1" width="0.254" layer="21"/>
<wire x1="3.25" y1="1" x2="3.25" y2="-1" width="0.254" layer="21"/>
<wire x1="3.25" y1="-1" x2="1" y2="-2.25" width="0.254" layer="21"/>
<wire x1="1" y1="-2.25" x2="-1" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-1" y1="-2.25" x2="-3.25" y2="-1" width="0.254" layer="21"/>
<wire x1="-3.25" y1="-1" x2="-3.25" y2="1" width="0.254" layer="21"/>
<circle x="0" y="0" radius="2" width="0.254" layer="21"/>
<wire x1="-2.5" y1="-1.25" x2="-2.5" y2="1.25" width="0.254" layer="21"/>
<wire x1="-2.75" y1="-1.25" x2="-2.75" y2="1.25" width="0.254" layer="21"/>
<wire x1="-3" y1="-1" x2="-3" y2="1" width="0.254" layer="21"/>
<wire x1="3" y1="-1" x2="3" y2="1" width="0.254" layer="21"/>
<wire x1="2.75" y1="-1.25" x2="2.75" y2="1.25" width="0.254" layer="21"/>
<wire x1="2.5" y1="-1.25" x2="2.5" y2="1.25" width="0.254" layer="21"/>
</package>
<package name="TL-DL1812">
<wire x1="-2.25" y1="-1.6" x2="-2.25" y2="1.6" width="0.254" layer="21"/>
<wire x1="-2.25" y1="1.6" x2="2.25" y2="1.6" width="0.254" layer="21"/>
<wire x1="2.25" y1="1.6" x2="2.25" y2="-1.6" width="0.254" layer="21"/>
<wire x1="2.25" y1="-1.6" x2="-2.25" y2="-1.6" width="0.254" layer="21"/>
<smd name="1" x="-1.7145" y="0" dx="1.524" dy="1.3208" layer="1" rot="R90"/>
<smd name="2" x="1.7145" y="0" dx="1.524" dy="1.3208" layer="1" rot="R90"/>
<wire x1="-2.667" y1="-1.778" x2="-2.667" y2="1.778" width="0.2032" layer="51"/>
<wire x1="-2.667" y1="1.778" x2="2.667" y2="1.778" width="0.2032" layer="51"/>
<wire x1="2.667" y1="1.778" x2="2.667" y2="-1.778" width="0.2032" layer="51"/>
<wire x1="2.667" y1="-1.778" x2="-2.667" y2="-1.778" width="0.2032" layer="51"/>
<text x="-3.175" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.175" y="-3.175" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="TL-DR73">
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="0" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-3.81" y1="3.81" x2="3.81" y2="3.81" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-3.81" x2="-3.81" y2="-3.81" width="0.2032" layer="51"/>
<wire x1="-3.81" y1="3.81" x2="3.81" y2="3.81" width="0.254" layer="21"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="-3.81" width="0.254" layer="21"/>
<wire x1="3.81" y1="-3.81" x2="-3.81" y2="-3.81" width="0.254" layer="21"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="3.81" width="0.254" layer="21"/>
<smd name="1" x="-3" y="0" dx="2.5" dy="3.25" layer="1"/>
<smd name="2" x="3" y="0" dx="2.5" dy="3.25" layer="1"/>
<wire x1="-3.81" y1="3.81" x2="-3.81" y2="1.9" width="0.2032" layer="51"/>
<wire x1="3.81" y1="3.81" x2="3.81" y2="1.9" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-3.81" x2="3.81" y2="-1.9" width="0.2032" layer="51"/>
<wire x1="-3.81" y1="-3.81" x2="-3.81" y2="-1.9" width="0.2032" layer="51"/>
<circle x="0" y="0" radius="3" width="0.2032" layer="21"/>
</package>
<package name="TL-7050">
<wire x1="-4.318" y1="-3.3" x2="4.318" y2="-3.3" width="0.2032" layer="51"/>
<wire x1="4.318" y1="-3.3" x2="4.318" y2="3.3" width="0.2032" layer="51"/>
<wire x1="4.318" y1="3.3" x2="-4.318" y2="3.3" width="0.2032" layer="51"/>
<wire x1="-4.318" y1="3.3" x2="-4.318" y2="-3.3" width="0.2032" layer="51"/>
<smd name="1" x="-2.875" y="0" dx="2.25" dy="3.4" layer="1"/>
<smd name="2" x="2.875" y="0" dx="2.25" dy="3.4" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="3.81" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-3.5" y1="3.3" x2="3.5" y2="3.3" width="0.254" layer="21"/>
<wire x1="3.5" y1="3.3" x2="3.5" y2="-3.3" width="0.254" layer="21"/>
<wire x1="3.5" y1="-3.3" x2="-3.5" y2="-3.3" width="0.254" layer="21"/>
<wire x1="-3.5" y1="-3.3" x2="-3.5" y2="3.3" width="0.254" layer="21"/>
<wire x1="-3.65" y1="1.5" x2="-3.65" y2="-1.5" width="0.254" layer="21"/>
<wire x1="3.65" y1="-1.5" x2="3.65" y2="1.5" width="0.254" layer="21"/>
</package>
<package name="TL-SPM-10065VC">
<wire x1="-5.25" y1="-5" x2="2" y2="-5" width="0.2032" layer="51"/>
<wire x1="2" y1="-5" x2="3.25" y2="-5" width="0.2032" layer="51"/>
<wire x1="3.25" y1="-5" x2="5.25" y2="-3" width="0.2032" layer="51"/>
<wire x1="5.25" y1="-3" x2="5.25" y2="5" width="0.2032" layer="51"/>
<wire x1="5.25" y1="5" x2="-3.25" y2="5" width="0.2032" layer="51"/>
<wire x1="-3.25" y1="5" x2="-5.25" y2="3" width="0.2032" layer="51"/>
<wire x1="-5.25" y1="3" x2="-5.25" y2="-5" width="0.2032" layer="51"/>
<smd name="1" x="-4.525" y="0" dx="4.5" dy="2.95" layer="1" rot="R270" thermals="no"/>
<smd name="2" x="4.525" y="0" dx="4.5" dy="2.95" layer="1" rot="R90" thermals="no"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.81" y="5.08" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-5.25" y1="-5" x2="3.25" y2="-5" width="0.2032" layer="21"/>
<wire x1="3.25" y1="-5" x2="5.25" y2="-3" width="0.2032" layer="21"/>
<wire x1="5.25" y1="-3" x2="5.25" y2="5" width="0.2032" layer="21"/>
<wire x1="5.25" y1="5" x2="-3.25" y2="5" width="0.2032" layer="21"/>
<wire x1="-3.25" y1="5" x2="-5.25" y2="3" width="0.2032" layer="21"/>
<wire x1="-5.25" y1="3" x2="-5.25" y2="-5" width="0.2032" layer="21"/>
</package>
<package name="TL-2016">
<wire x1="-1.4478" y1="-1.1176" x2="1.4478" y2="-1.1176" width="0.2032" layer="51"/>
<wire x1="1.4478" y1="-1.1176" x2="1.4478" y2="1.1176" width="0.2032" layer="51"/>
<wire x1="1.4478" y1="1.1176" x2="-1.4478" y2="1.1176" width="0.2032" layer="51"/>
<wire x1="-1.4478" y1="1.1176" x2="-1.4478" y2="-1.1176" width="0.2032" layer="51"/>
<smd name="1" x="-0.75" y="0" dx="0.8" dy="1.6" layer="1"/>
<smd name="2" x="0.75" y="0" dx="0.8" dy="1.6" layer="1"/>
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="1.27" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-1" y1="0.8" x2="1" y2="0.8" width="0.254" layer="21"/>
<wire x1="1" y1="0.8" x2="1" y2="-0.8" width="0.254" layer="21"/>
<wire x1="1" y1="-0.8" x2="-1" y2="-0.8" width="0.254" layer="21"/>
<wire x1="-1" y1="-0.8" x2="-1" y2="0.8" width="0.254" layer="21"/>
</package>
<package name="R-0603">
<wire x1="-1.3716" y1="-0.7493" x2="1.3716" y2="-0.7493" width="0.2032" layer="51"/>
<wire x1="-1.3716" y1="-0.7493" x2="-1.3716" y2="0.7493" width="0.2032" layer="51"/>
<wire x1="-1.3716" y1="0.7493" x2="1.3716" y2="0.7493" width="0.2032" layer="51"/>
<wire x1="1.3716" y1="-0.7493" x2="1.3716" y2="0.7493" width="0.2032" layer="51"/>
<wire x1="-0.635" y1="0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="0.254" x2="0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.254" x2="0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="-0.254" x2="-0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.254" x2="-0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<smd name="2" x="0.762" y="0" dx="0.6096" dy="0.889" layer="1"/>
<smd name="1" x="-0.762" y="0" dx="0.6096" dy="0.889" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-0805">
<wire x1="-1.6129" y1="-0.9525" x2="1.6129" y2="-0.9525" width="0.2032" layer="51"/>
<wire x1="-1.6129" y1="-0.9525" x2="-1.6129" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-1.6129" y1="0.9525" x2="1.6129" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="1.6129" y1="-0.9525" x2="1.6129" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-0.8636" y1="0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="0.508" x2="0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="0.508" x2="0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="-0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="-0.508" x2="-0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.8636" y1="-0.508" x2="-0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<smd name="2" x="0.9525" y="0" dx="0.7112" dy="1.2954" layer="1"/>
<smd name="1" x="-0.9525" y="0" dx="0.7112" dy="1.2954" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-1206">
<wire x1="-1.4541" y1="-0.675" x2="-1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.4541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="-0.675" x2="-1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.4541" y1="-0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-2.1844" y1="-1.1303" x2="2.1844" y2="-1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="-1.1303" x2="-2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="2.1844" y1="-1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<smd name="1" x="-1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<smd name="2" x="1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<text x="-1.4287" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.4287" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.0637" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-2010">
<wire x1="-2.54" y1="-1.27" x2="-2.286" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.286" y1="-1.27" x2="-2.032" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.032" y1="-1.27" x2="2.032" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.032" y1="-1.27" x2="2.286" y2="-1.27" width="0.254" layer="21"/>
<wire x1="2.286" y1="-1.27" x2="2.54" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.54" y1="-1.27" x2="-2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="-2.54" y1="1.27" x2="-2.286" y2="1.27" width="0.254" layer="21"/>
<wire x1="-2.286" y1="1.27" x2="-2.032" y2="1.27" width="0.254" layer="21"/>
<wire x1="-2.032" y1="1.27" x2="2.032" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.032" y1="1.27" x2="2.286" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.286" y1="1.27" x2="2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.54" y1="-1.27" x2="2.54" y2="1.27" width="0.254" layer="21"/>
<wire x1="-3.3528" y1="-1.8288" x2="3.3528" y2="-1.8288" width="0.2032" layer="51"/>
<wire x1="-3.3528" y1="-1.8288" x2="-3.3528" y2="1.8288" width="0.2032" layer="51"/>
<wire x1="-3.3528" y1="1.8288" x2="3.3528" y2="1.8288" width="0.2032" layer="51"/>
<wire x1="3.3528" y1="-1.8288" x2="3.3528" y2="1.8288" width="0.2032" layer="51"/>
<smd name="1" x="-2.3495" y="0" dx="1.397" dy="3.048" layer="1"/>
<smd name="2" x="2.3495" y="0" dx="1.397" dy="3.048" layer="1"/>
<text x="-2.5399" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.5399" y="-2.921" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.5399" y="2.2225" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-2.032" y1="-1.27" x2="-2.032" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.032" y1="1.27" x2="2.032" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-2.286" y1="-1.27" x2="-2.286" y2="1.27" width="0.254" layer="21"/>
<wire x1="2.286" y1="1.27" x2="2.286" y2="-1.27" width="0.254" layer="21"/>
</package>
<package name="R-2512">
<wire x1="-3.175" y1="-1.5749" x2="-2.975" y2="-1.5749" width="0.254" layer="21"/>
<wire x1="-2.975" y1="-1.5749" x2="-2.775" y2="-1.5749" width="0.254" layer="21"/>
<wire x1="-2.775" y1="-1.5749" x2="2.7749" y2="-1.5749" width="0.254" layer="21"/>
<wire x1="2.7749" y1="-1.5749" x2="2.9749" y2="-1.5749" width="0.254" layer="21"/>
<wire x1="2.9749" y1="-1.5749" x2="3.1749" y2="-1.5749" width="0.254" layer="21"/>
<wire x1="-3.175" y1="-1.5749" x2="-3.175" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-3.175" y1="1.5749" x2="-2.975" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-2.975" y1="1.5749" x2="-2.775" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-2.775" y1="1.5749" x2="2.7749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="2.7749" y1="1.5749" x2="2.9749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="2.9749" y1="1.5749" x2="3.1749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="3.1749" y1="-1.5749" x2="3.1749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-2.975" y1="-1.5749" x2="-2.975" y2="1.5749" width="0.254" layer="21"/>
<wire x1="2.9749" y1="-1.5749" x2="2.9749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-2.775" y1="-1.5749" x2="-2.775" y2="1.5749" width="0.254" layer="21"/>
<wire x1="2.7749" y1="-1.5749" x2="2.7749" y2="1.5749" width="0.254" layer="21"/>
<wire x1="-4.1148" y1="-1.9558" x2="4.1148" y2="-1.9558" width="0.2032" layer="51"/>
<wire x1="-4.1148" y1="-1.9558" x2="-4.1148" y2="1.9558" width="0.2032" layer="51"/>
<wire x1="-4.1148" y1="1.9558" x2="4.1148" y2="1.9558" width="0.2032" layer="51"/>
<wire x1="4.1148" y1="-1.9558" x2="4.1148" y2="1.9558" width="0.2032" layer="51"/>
<smd name="1" x="-3.175" y="0" dx="1.27" dy="3.302" layer="1"/>
<smd name="2" x="3.175" y="0" dx="1.27" dy="3.302" layer="1"/>
<text x="-2.5399" y="1.905" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.5399" y="-2.921" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.5399" y="2.2225" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-0306">
<wire x1="-0.625" y1="-1.397" x2="0.625" y2="-1.397" width="0.2032" layer="51"/>
<wire x1="-0.625" y1="1.397" x2="0.625" y2="1.397" width="0.2032" layer="51"/>
<wire x1="-0.635" y1="1" x2="-0.381" y2="1" width="0.254" layer="21"/>
<wire x1="-0.381" y1="1" x2="0.381" y2="1" width="0.254" layer="21"/>
<wire x1="0.381" y1="1" x2="0.635" y2="1" width="0.254" layer="21"/>
<wire x1="0.635" y1="1" x2="0.635" y2="-1" width="0.254" layer="21"/>
<wire x1="0.635" y1="-1" x2="0.381" y2="-1" width="0.254" layer="21"/>
<wire x1="0.381" y1="-1" x2="-0.381" y2="-1" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-1" x2="-0.635" y2="-1" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-1" x2="-0.635" y2="1" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-1" x2="-0.381" y2="1" width="0.254" layer="21"/>
<wire x1="0.381" y1="1" x2="0.381" y2="-1" width="0.254" layer="21"/>
<smd name="2" x="0.825" y="0" dx="1.15" dy="2.3" layer="1"/>
<smd name="1" x="-0.825" y="0" dx="1.15" dy="2.3" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-0000">
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<smd name="P$1" x="0" y="0" dx="0.254" dy="0.254" layer="1" stop="no" thermals="no" cream="no"/>
<smd name="P$2" x="0.254" y="0" dx="0.254" dy="0.254" layer="1" stop="no" thermals="no" cream="no"/>
</package>
<package name="CK-0603">
<wire x1="-1.4732" y1="-0.7112" x2="1.4732" y2="-0.7112" width="0.2032" layer="51"/>
<wire x1="-1.4732" y1="-0.7112" x2="-1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="-1.4732" y1="0.7112" x2="1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="1.4732" y1="-0.7112" x2="1.4732" y2="0.7112" width="0.2032" layer="51"/>
<wire x1="-0.635" y1="0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="0.254" x2="0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.254" x2="0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="-0.254" x2="-0.381" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.635" y2="-0.254" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.254" x2="-0.635" y2="0.254" width="0.254" layer="21"/>
<wire x1="-0.381" y1="-0.254" x2="-0.381" y2="0.254" width="0.254" layer="21"/>
<wire x1="0.381" y1="0.254" x2="0.381" y2="-0.254" width="0.254" layer="21"/>
<smd name="2" x="0.762" y="0" dx="0.7874" dy="0.7874" layer="1"/>
<smd name="1" x="-0.762" y="0" dx="0.7874" dy="0.7874" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-0805">
<wire x1="-1.7018" y1="-0.9525" x2="1.7018" y2="-0.9525" width="0.2032" layer="51"/>
<wire x1="-1.7018" y1="-0.9525" x2="-1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-1.7018" y1="0.9525" x2="1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="1.7018" y1="-0.9525" x2="1.7018" y2="0.9525" width="0.2032" layer="51"/>
<wire x1="-0.8636" y1="0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="0.508" x2="0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="0.508" x2="0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.8636" y1="-0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="-0.508" x2="-0.6096" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.8636" y2="-0.508" width="0.254" layer="21"/>
<wire x1="-0.8636" y1="-0.508" x2="-0.8636" y2="0.508" width="0.254" layer="21"/>
<wire x1="-0.6096" y1="-0.508" x2="-0.6096" y2="0.508" width="0.254" layer="21"/>
<wire x1="0.6096" y1="0.508" x2="0.6096" y2="-0.508" width="0.254" layer="21"/>
<smd name="2" x="0.9525" y="0" dx="0.889" dy="1.2954" layer="1"/>
<smd name="1" x="-0.9525" y="0" dx="0.889" dy="1.2954" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-1206">
<wire x1="-1.4541" y1="-0.675" x2="-1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="1.0541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.2541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.4541" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="-0.675" x2="-1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.4541" y1="0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.4541" y1="-0.675" x2="1.4541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2541" y1="-0.675" x2="-1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.2541" y1="-0.675" x2="1.2541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.0541" y1="-0.675" x2="-1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.0541" y1="-0.675" x2="1.0541" y2="0.675" width="0.254" layer="21"/>
<wire x1="-2.1844" y1="-1.1303" x2="2.1844" y2="-1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="-1.1303" x2="-2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-2.1844" y1="1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="2.1844" y1="-1.1303" x2="2.1844" y2="1.1303" width="0.2032" layer="51"/>
<smd name="1" x="-1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<smd name="2" x="1.4224" y="0" dx="0.9144" dy="1.651" layer="1"/>
<text x="-1.4287" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.4287" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.0637" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-1210">
<wire x1="-1.5113" y1="-1.1068" x2="-1.3113" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="-1.1068" x2="-1.1113" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="-1.1068" x2="1.1112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="1.1112" y1="-1.1068" x2="1.3112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="-1.1068" x2="1.5112" y2="-1.1068" width="0.254" layer="21"/>
<wire x1="-1.5113" y1="-1.1068" x2="-1.5113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.5113" y1="1.1068" x2="-1.3113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="1.1068" x2="-1.1113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="1.1068" x2="1.3112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="1.1068" x2="1.5112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.5112" y1="-1.1068" x2="1.5112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.3113" y1="-1.1068" x2="-1.3113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.3112" y1="-1.1068" x2="1.3112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-1.1113" y1="-1.1068" x2="-1.1113" y2="1.1068" width="0.254" layer="21"/>
<wire x1="1.1112" y1="-1.1068" x2="1.1112" y2="1.1068" width="0.254" layer="21"/>
<wire x1="-2.3495" y1="-1.5748" x2="2.3495" y2="-1.5748" width="0.2032" layer="51"/>
<wire x1="-2.3495" y1="-1.5748" x2="-2.3495" y2="1.5748" width="0.2032" layer="51"/>
<wire x1="-2.3495" y1="1.5748" x2="2.3495" y2="1.5748" width="0.2032" layer="51"/>
<wire x1="2.3495" y1="-1.5748" x2="2.3495" y2="1.5748" width="0.2032" layer="51"/>
<smd name="1" x="-1.5875" y="0" dx="0.9144" dy="2.54" layer="1"/>
<smd name="2" x="1.5875" y="0" dx="0.9144" dy="2.54" layer="1"/>
<text x="-1.5875" y="1.3589" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.5875" y="-2.3114" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.2225" y="1.9304" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="CK-2220">
<wire x1="-2.794" y1="-2.54" x2="2.794" y2="-2.54" width="0.254" layer="21"/>
<wire x1="-2.794" y1="-2.54" x2="-2.794" y2="2.54" width="0.254" layer="21"/>
<wire x1="-2.794" y1="2.54" x2="2.794" y2="2.54" width="0.254" layer="21"/>
<wire x1="2.794" y1="-2.54" x2="2.794" y2="2.54" width="0.254" layer="21"/>
<wire x1="-3.9116" y1="-3.2004" x2="3.9116" y2="-3.2004" width="0.2032" layer="51"/>
<wire x1="-3.9116" y1="-3.2004" x2="-3.9116" y2="3.2004" width="0.2032" layer="51"/>
<wire x1="-3.9116" y1="3.2004" x2="3.9116" y2="3.2004" width="0.2032" layer="51"/>
<wire x1="3.9116" y1="-3.2004" x2="3.9116" y2="3.2004" width="0.2032" layer="51"/>
<smd name="1" x="-2.8448" y="0" dx="1.524" dy="5.7912" layer="1"/>
<smd name="2" x="2.8448" y="0" dx="1.524" dy="5.7912" layer="1"/>
<text x="-1.5875" y="3.8989" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.5875" y="-4.8514" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.2225" y="3.8354" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="R-NET4SB">
<wire x1="-1.6002" y1="-0.8001" x2="-0.6604" y2="-0.8001" width="0.254" layer="21"/>
<wire x1="-0.6604" y1="-0.8001" x2="-0.1524" y2="-0.8001" width="0.254" layer="21"/>
<wire x1="-0.1524" y1="-0.8001" x2="1.6002" y2="-0.8001" width="0.254" layer="21"/>
<wire x1="-1.6002" y1="-0.8001" x2="-1.6002" y2="0.8001" width="0.254" layer="21"/>
<wire x1="-1.6002" y1="0.8001" x2="1.6002" y2="0.8001" width="0.254" layer="21"/>
<wire x1="1.6002" y1="-0.8001" x2="1.6002" y2="0.8001" width="0.254" layer="21"/>
<wire x1="-0.6604" y1="-0.4699" x2="-0.6604" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="-0.6604" y1="-0.4699" x2="-0.1524" y2="-0.4699" width="0.0254" layer="21"/>
<wire x1="-0.1524" y1="-0.4699" x2="-0.1524" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="0.1524" y1="-0.4699" x2="0.1524" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="0.1524" y1="-0.4699" x2="0.6604" y2="-0.4699" width="0.0254" layer="21"/>
<wire x1="0.6604" y1="-0.4699" x2="0.6604" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="0.9652" y1="-0.4699" x2="0.9652" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="0.9652" y1="-0.4699" x2="1.4732" y2="-0.4699" width="0.0254" layer="21"/>
<wire x1="1.4732" y1="-0.4699" x2="1.4732" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="-1.4732" y1="-0.4699" x2="-1.4732" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="-1.4732" y1="-0.4699" x2="-0.9652" y2="-0.4699" width="0.0254" layer="21"/>
<wire x1="-0.9652" y1="-0.4699" x2="-0.9652" y2="-0.8001" width="0.0254" layer="21"/>
<wire x1="-0.6604" y1="0.4699" x2="-0.6604" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="-0.6604" y1="0.4699" x2="-0.1524" y2="0.4699" width="0.0254" layer="21"/>
<wire x1="-0.1524" y1="0.4699" x2="-0.1524" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="0.1524" y1="0.4699" x2="0.1524" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="0.1524" y1="0.4699" x2="0.6604" y2="0.4699" width="0.0254" layer="21"/>
<wire x1="0.6604" y1="0.4699" x2="0.6604" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="0.9652" y1="0.4699" x2="0.9652" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="0.9652" y1="0.4699" x2="1.4732" y2="0.4699" width="0.0254" layer="21"/>
<wire x1="1.4732" y1="0.4699" x2="1.4732" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="-1.4732" y1="0.4699" x2="-1.4732" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="-1.4732" y1="0.4699" x2="-0.9652" y2="0.4699" width="0.0254" layer="21"/>
<wire x1="-0.9652" y1="0.4699" x2="-0.9652" y2="0.8001" width="0.0254" layer="21"/>
<wire x1="-1.7399" y1="-1.6002" x2="1.7399" y2="-1.6002" width="0.2032" layer="51"/>
<wire x1="-1.7399" y1="-1.6002" x2="-1.7399" y2="1.6002" width="0.2032" layer="51"/>
<wire x1="-1.7399" y1="1.6002" x2="1.7399" y2="1.6002" width="0.2032" layer="51"/>
<wire x1="1.7399" y1="-1.6002" x2="1.7399" y2="1.6002" width="0.2032" layer="51"/>
<smd name="1" x="-1.2192" y="-0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="2" x="-0.4064" y="-0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="3" x="0.4064" y="-0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="4" x="1.2192" y="-0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="A" x="-1.2192" y="0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="B" x="-0.4064" y="0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="C" x="0.4064" y="0.8509" dx="0.4318" dy="0.889" layer="1"/>
<smd name="D" x="1.2192" y="0.8509" dx="0.4318" dy="0.889" layer="1"/>
<text x="-1.905" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.905" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.905" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
</package>
</packages>
<symbols>
<symbol name="KRYSTAL">
<wire x1="1.905" y1="-2.54" x2="1.905" y2="0" width="0.508" layer="94"/>
<wire x1="-1.905" y1="-2.54" x2="-1.905" y2="0" width="0.508" layer="94"/>
<wire x1="-0.635" y1="-2.54" x2="-0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="-0.635" y1="2.54" x2="0.635" y2="2.54" width="0.254" layer="94"/>
<wire x1="0.635" y1="2.54" x2="0.635" y2="-2.54" width="0.254" layer="94"/>
<wire x1="0.635" y1="-2.54" x2="-0.635" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.905" y1="0" x2="1.905" y2="2.54" width="0.508" layer="94"/>
<wire x1="1.905" y1="0" x2="3.175" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.905" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.905" y1="0" x2="-1.905" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.302" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="CIVKA-F">
<wire x1="-5.08" y1="0" x2="-2.54" y2="0" width="0.1524" layer="94" curve="-180"/>
<wire x1="-2.54" y1="0" x2="0" y2="0" width="0.1524" layer="94" curve="-180"/>
<wire x1="0" y1="0" x2="2.54" y2="0" width="0.1524" layer="94" curve="-180"/>
<wire x1="2.54" y1="0" x2="5.08" y2="0" width="0.1524" layer="94" curve="-180"/>
<wire x1="3.429" y1="2.54" x2="2.159" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.524" y1="2.54" x2="0.254" y2="2.54" width="0.254" layer="94"/>
<wire x1="-0.381" y1="2.54" x2="-1.651" y2="2.54" width="0.254" layer="94"/>
<wire x1="-2.286" y1="2.54" x2="-3.556" y2="2.54" width="0.254" layer="94"/>
<wire x1="-4.191" y1="2.54" x2="-5.461" y2="2.54" width="0.254" layer="94"/>
<wire x1="5.334" y1="2.54" x2="4.064" y2="2.54" width="0.254" layer="94"/>
<text x="-3.81" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="-3.81" y="-2.54" size="1.524" layer="96">&gt;VALUE</text>
<pin name="Z" x="-7.62" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="K" x="7.62" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="ODPOR">
<wire x1="-2.54" y1="1.016" x2="2.54" y2="1.016" width="0.254" layer="94"/>
<wire x1="2.54" y1="-1.016" x2="-2.54" y2="-1.016" width="0.254" layer="94"/>
<wire x1="-2.54" y1="-1.016" x2="-2.54" y2="0" width="0.254" layer="94"/>
<wire x1="2.54" y1="1.016" x2="2.54" y2="0" width="0.254" layer="94"/>
<wire x1="2.54" y1="0" x2="2.54" y2="-1.016" width="0.254" layer="94"/>
<wire x1="-2.54" y1="0" x2="-2.54" y2="1.016" width="0.254" layer="94"/>
<text x="-2.54" y="1.524" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-3.048" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="KOND">
<wire x1="-2.54" y1="0" x2="-0.762" y2="0" width="0.1524" layer="94"/>
<wire x1="0.762" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-0.762" y1="-2.54" x2="-0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="-2.54" x2="0.762" y2="0" width="0.508" layer="94"/>
<wire x1="0.762" y1="0" x2="0.762" y2="2.54" width="0.508" layer="94"/>
<wire x1="-0.762" y1="0" x2="-0.762" y2="2.54" width="0.508" layer="94"/>
<text x="-2.54" y="3.556" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="XTAL-SMD" prefix="X" uservalue="yes">
<gates>
<gate name="A" symbol="KRYSTAL" x="0" y="0"/>
</gates>
<devices>
<device name="-5032" package="X-5032">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-3225" package="X-3225-2">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="3"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="TL-SMD" prefix="L" uservalue="yes">
<gates>
<gate name="A" symbol="CIVKA-F" x="0" y="0"/>
</gates>
<devices>
<device name="-4020" package="TL-4020">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-6045" package="TL-6045TA">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-7335" package="TL-7335">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-8080" package="TL-8080">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1812" package="TL-1812">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1260" package="TL-1260">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2424" package="TL-2424">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2323" package="TL-2323">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1583" package="TL-1583">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-DL16" package="TL-DL16">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-DL1812" package="TL-DL1812">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-DR73" package="TL-DR73">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-7050" package="TL-7050">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-SPM" package="TL-SPM-10065VC">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2016" package="TL-2016">
<connects>
<connect gate="A" pin="K" pad="2"/>
<connect gate="A" pin="Z" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R-SMD" prefix="R" uservalue="yes">
<description>SMD rezistory</description>
<gates>
<gate name="A" symbol="ODPOR" x="0" y="0"/>
</gates>
<devices>
<device name="-0603" package="R-0603">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-0805" package="R-0805">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1206" package="R-1206">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2010" package="R-2010">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2512" package="R-2512">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-0306" package="R-0306">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-0000" package="R-0000">
<connects>
<connect gate="A" pin="1" pad="P$1"/>
<connect gate="A" pin="2" pad="P$2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="CK-SMD" prefix="C" uservalue="yes">
<description>SMD keramické vícevrstvé kondenzátory</description>
<gates>
<gate name="A" symbol="KOND" x="0" y="0"/>
</gates>
<devices>
<device name="-0603" package="CK-0603">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-0805" package="CK-0805">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1206" package="CK-1206">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-1210" package="CK-1210">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-2220" package="CK-2220">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="R-NET4SB" prefix="RB" uservalue="yes">
<gates>
<gate name="A" symbol="ODPOR" x="0" y="0" swaplevel="1"/>
<gate name="B" symbol="ODPOR" x="0" y="-7.62" swaplevel="1"/>
<gate name="C" symbol="ODPOR" x="0" y="-15.24" swaplevel="1"/>
<gate name="D" symbol="ODPOR" x="0" y="-22.86" swaplevel="1"/>
</gates>
<devices>
<device name="" package="R-NET4SB">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="A"/>
<connect gate="B" pin="1" pad="2"/>
<connect gate="B" pin="2" pad="B"/>
<connect gate="C" pin="1" pad="3"/>
<connect gate="C" pin="2" pad="C"/>
<connect gate="D" pin="1" pad="4"/>
<connect gate="D" pin="2" pad="D"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="DISKRET">
<packages>
<package name="SOT23-6">
<wire x1="-1.5494" y1="2.2098" x2="1.5494" y2="2.2098" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="2.2098" x2="1.5494" y2="0.3302" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="0.3302" x2="1.27" y2="0.3302" width="0.2032" layer="51"/>
<wire x1="1.27" y1="0.3302" x2="1.27" y2="-0.3302" width="0.2032" layer="51"/>
<wire x1="1.27" y1="-0.3302" x2="1.5494" y2="-0.3302" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="-0.3302" x2="1.5494" y2="-2.2098" width="0.2032" layer="51"/>
<wire x1="1.5494" y1="-2.2098" x2="-1.5494" y2="-2.2098" width="0.2032" layer="51"/>
<wire x1="-1.5494" y1="-2.2098" x2="-1.5494" y2="2.2098" width="0.2032" layer="51"/>
<wire x1="1.4525" y1="0.77" x2="-1.4526" y2="0.77" width="0.254" layer="21"/>
<wire x1="-1.4526" y1="0.77" x2="-1.4526" y2="-0.7701" width="0.254" layer="21"/>
<wire x1="-1.4526" y1="-0.7701" x2="1.4525" y2="-0.7701" width="0.254" layer="21"/>
<wire x1="1.4525" y1="-0.7701" x2="1.4525" y2="0.77" width="0.254" layer="21"/>
<circle x="0.9525" y="0.3175" radius="0.127" width="0.254" layer="21"/>
<smd name="1" x="0.9525" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="2" x="0" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="3" x="-0.9525" y="1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="4" x="-0.9525" y="-1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="6" x="0.9525" y="-1.27" dx="0.5842" dy="1.27" layer="1"/>
<smd name="5" x="0" y="-1.27" dx="0.5842" dy="1.27" layer="1"/>
<text x="2.2225" y="0.635" size="1.27" layer="25">&gt;NAME</text>
<text x="2.2225" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="2.2225" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<rectangle x1="0.7025" y1="0.77" x2="1.2025" y2="1.27" layer="21"/>
<rectangle x1="-0.25" y1="0.77" x2="0.25" y2="1.27" layer="21"/>
<rectangle x1="-1.2026" y1="0.77" x2="-0.7026" y2="1.27" layer="21"/>
<rectangle x1="0.7025" y1="-1.2701" x2="1.2025" y2="-0.7701" layer="21"/>
<rectangle x1="-1.2026" y1="-1.2701" x2="-0.7026" y2="-0.7701" layer="21"/>
<rectangle x1="-0.25" y1="-1.2701" x2="0.25" y2="-0.7701" layer="21"/>
</package>
<package name="LED1206K">
<wire x1="-1.4542" y1="-0.675" x2="-1.2002" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.2002" y1="-0.675" x2="-0.9462" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-0.9462" y1="-0.675" x2="-0.6922" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-0.6922" y1="-0.675" x2="1.454" y2="-0.675" width="0.254" layer="21"/>
<wire x1="-1.4542" y1="-0.675" x2="-1.4542" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.4542" y1="0.675" x2="-1.2002" y2="0.675" width="0.254" layer="21"/>
<wire x1="-1.2002" y1="0.675" x2="-0.9462" y2="0.675" width="0.254" layer="21"/>
<wire x1="-0.9462" y1="0.675" x2="-0.6922" y2="0.675" width="0.254" layer="21"/>
<wire x1="-0.6922" y1="0.675" x2="1.454" y2="0.675" width="0.254" layer="21"/>
<wire x1="1.454" y1="-0.675" x2="1.454" y2="0.675" width="0.254" layer="21"/>
<wire x1="-2.19075" y1="-1.1303" x2="2.19075" y2="-1.1303" width="0.2032" layer="51"/>
<wire x1="-2.19075" y1="-1.1303" x2="-2.19075" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-2.19075" y1="1.1303" x2="2.19075" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="2.19075" y1="-1.1303" x2="2.19075" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-1.2002" y1="-0.675" x2="-1.2002" y2="0.675" width="0.254" layer="21"/>
<wire x1="-0.9462" y1="-0.675" x2="-0.9462" y2="0.675" width="0.254" layer="21"/>
<wire x1="-2.49555" y1="-1.1303" x2="-2.49555" y2="1.1303" width="0.2032" layer="51"/>
<wire x1="-0.6922" y1="-0.675" x2="-0.6922" y2="0.675" width="0.254" layer="21"/>
<smd name="K" x="-1.4288" y="0" dx="0.9144" dy="1.651" layer="1"/>
<smd name="A" x="1.4287" y="0" dx="0.9144" dy="1.651" layer="1"/>
<text x="-1.27" y="0.9525" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="1.524" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="DO-214AA">
<smd name="K" x="-2.1082" y="0" dx="1.6256" dy="2.1844" layer="1"/>
<smd name="A" x="2.1082" y="0" dx="1.6256" dy="2.1844" layer="1"/>
<wire x1="-3.2258" y1="-2.032" x2="3.2258" y2="-2.032" width="0.2032" layer="51"/>
<wire x1="-3.2258" y1="-2.032" x2="-3.2258" y2="2.032" width="0.2032" layer="51"/>
<wire x1="-3.2258" y1="2.032" x2="3.2258" y2="2.032" width="0.2032" layer="51"/>
<wire x1="3.2258" y1="-2.032" x2="3.2258" y2="2.032" width="0.2032" layer="51"/>
<wire x1="-2.413" y1="-2.032" x2="-2.159" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-2.159" y1="-2.032" x2="-1.905" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-1.905" y1="-2.032" x2="-1.651" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-1.651" y1="-2.032" x2="-1.397" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-1.397" y1="-2.032" x2="-1.143" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-1.143" y1="-2.032" x2="2.413" y2="-2.032" width="0.254" layer="21"/>
<wire x1="-2.413" y1="-2.032" x2="-2.413" y2="2.032" width="0.254" layer="21"/>
<wire x1="-2.413" y1="2.032" x2="-2.159" y2="2.032" width="0.254" layer="21"/>
<wire x1="-2.159" y1="2.032" x2="-1.905" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.905" y1="2.032" x2="-1.651" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.651" y1="2.032" x2="-1.397" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.397" y1="2.032" x2="-1.143" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.143" y1="2.032" x2="2.413" y2="2.032" width="0.254" layer="21"/>
<wire x1="2.413" y1="-2.032" x2="2.413" y2="2.032" width="0.254" layer="21"/>
<text x="-2.54" y="2.2225" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-3.175" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="2.2225" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-2.159" y1="-2.032" x2="-2.159" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.905" y1="-2.032" x2="-1.905" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.651" y1="-2.032" x2="-1.651" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.397" y1="-2.032" x2="-1.397" y2="2.032" width="0.254" layer="21"/>
<wire x1="-1.143" y1="-2.032" x2="-1.143" y2="2.032" width="0.254" layer="21"/>
<wire x1="-3.5306" y1="-2.032" x2="-3.5306" y2="2.032" width="0.2032" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="USBLC6-2">
<wire x1="-8.89" y1="5.08" x2="-8.89" y2="-5.08" width="0.254" layer="94"/>
<wire x1="-8.89" y1="-5.08" x2="8.89" y2="-5.08" width="0.254" layer="94"/>
<wire x1="8.89" y1="-5.08" x2="8.89" y2="5.08" width="0.254" layer="94"/>
<wire x1="8.89" y1="5.08" x2="-8.89" y2="5.08" width="0.254" layer="94"/>
<text x="-8.89" y="6.35" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-7.62" size="1.524" layer="96">&gt;VALUE</text>
<pin name="O2" x="13.97" y="0" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="O1" x="13.97" y="2.54" length="middle" direction="pas" swaplevel="1" rot="R180"/>
<pin name="I2" x="-13.97" y="0" length="middle" direction="pas" swaplevel="1"/>
<pin name="I1" x="-13.97" y="2.54" length="middle" direction="pas" swaplevel="1"/>
<pin name="GND" x="-13.97" y="-2.54" length="middle" direction="pas" swaplevel="1"/>
<pin name="VBUS" x="13.97" y="-2.54" length="middle" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="LED">
<wire x1="1.27" y1="0" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-4.445" x2="-1.905" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="-4.445" x2="0.635" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="-3.175" y1="-4.445" x2="-3.81" y2="-4.445" width="0.254" layer="94"/>
<wire x1="-3.81" y1="-4.445" x2="-3.81" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-0.635" y1="-4.445" x2="-1.27" y2="-4.445" width="0.254" layer="94"/>
<wire x1="1.27" y1="2.54" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="-1.27" y1="2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="-4.445" x2="-1.27" y2="-3.81" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="-2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="2.54" y1="0" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-2.54" width="0.254" layer="94"/>
<text x="-1.27" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="-2.54" y="6.35" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="K" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="UNIPOL-D">
<wire x1="1.27" y1="2.54" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-1.27" y1="2.54" x2="1.27" y2="0" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="-1.27" y2="-2.54" width="0.254" layer="94"/>
<wire x1="-1.27" y1="-2.54" x2="-1.27" y2="0" width="0.254" layer="94"/>
<wire x1="-1.27" y1="0" x2="-1.27" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="0" y2="-2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="2.54" x2="2.54" y2="2.54" width="0.254" layer="94"/>
<wire x1="1.27" y1="0" x2="2.54" y2="0" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="0" x2="1.27" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="0" x2="-1.27" y2="0" width="0.1524" layer="94"/>
<text x="-1.27" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="-3.81" y="-5.08" size="1.524" layer="96">&gt;VALUE</text>
<pin name="A" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="K" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="USBLC6-2" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="USBLC6-2" x="0" y="0"/>
</gates>
<devices>
<device name="SC6" package="SOT23-6">
<connects>
<connect gate="A" pin="GND" pad="2"/>
<connect gate="A" pin="I1" pad="1"/>
<connect gate="A" pin="I2" pad="3"/>
<connect gate="A" pin="O1" pad="6"/>
<connect gate="A" pin="O2" pad="4"/>
<connect gate="A" pin="VBUS" pad="5"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="LED-1206" prefix="D" uservalue="yes">
<gates>
<gate name="A" symbol="LED" x="0" y="0"/>
</gates>
<devices>
<device name="" package="LED1206K">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="600W-USM" prefix="D" uservalue="yes">
<gates>
<gate name="A" symbol="UNIPOL-D" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="" package="DO-214AA">
<connects>
<connect gate="A" pin="A" pad="A"/>
<connect gate="A" pin="K" pad="K"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="KONSTR">
<packages>
<package name="TL-TS21">
<description>SAME SKY Series TS21</description>
<smd name="1" x="-1.625" y="1" dx="0.6" dy="1.25" layer="1" rot="R90"/>
<smd name="2" x="1.625" y="1" dx="0.6" dy="1.25" layer="1" rot="R90"/>
<smd name="3" x="-1.625" y="-1" dx="0.6" dy="1.25" layer="1" rot="R90"/>
<smd name="4" x="1.625" y="-1" dx="0.6" dy="1.25" layer="1" rot="R90"/>
<wire x1="1.3" y1="1.7" x2="1.7" y2="1.3" width="0.254" layer="21"/>
<wire x1="1.7" y1="1.3" x2="1.7" y2="-1.3" width="0.254" layer="21"/>
<wire x1="1.7" y1="-1.3" x2="1.3" y2="-1.7" width="0.254" layer="21"/>
<wire x1="1.3" y1="-1.7" x2="-1.3" y2="-1.7" width="0.254" layer="21"/>
<wire x1="-1.3" y1="-1.7" x2="-1.7" y2="-1.3" width="0.254" layer="21"/>
<wire x1="-1.7" y1="-1.3" x2="-1.7" y2="1.3" width="0.254" layer="21"/>
<wire x1="-1.7" y1="1.3" x2="-1.3" y2="1.7" width="0.254" layer="21"/>
<wire x1="-1.3" y1="1.7" x2="1.3" y2="1.7" width="0.254" layer="21"/>
<text x="-3.175" y="3.175" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.175" y="1.905" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="3.175" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<circle x="0" y="0" radius="0.85" width="0.2032" layer="21"/>
<smd name="S1" x="0" y="1.65" dx="0.5" dy="1" layer="1" rot="R90"/>
<smd name="S2" x="0" y="-1.65" dx="0.5" dy="1" layer="1" rot="R270"/>
<wire x1="1.4" y1="2.1" x2="-1.4" y2="2.1" width="0.2032" layer="51"/>
<wire x1="-1.4" y1="2.1" x2="-2" y2="1.5" width="0.2032" layer="51"/>
<wire x1="2" y1="1.5" x2="1.4" y2="2.1" width="0.2032" layer="51"/>
<wire x1="-2.1" y1="0.5" x2="-2.1" y2="-0.5" width="0.2032" layer="51"/>
<wire x1="2.1" y1="0.5" x2="2.1" y2="-0.5" width="0.2032" layer="51"/>
<wire x1="2" y1="-1.5" x2="1.4" y2="-2.1" width="0.2032" layer="51"/>
<wire x1="1.4" y1="-2.1" x2="-1.4" y2="-2.1" width="0.2032" layer="51"/>
<wire x1="-1.4" y1="-2.1" x2="-2" y2="-1.5" width="0.2032" layer="51"/>
</package>
<package name="JMP2-1">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="3.81" y2="-1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="1" diameter="1.6764"/>
<pad name="2" x="2.54" y="0" drill="1" diameter="1.6764"/>
<text x="4.445" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="4.445" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="4.445" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-1.27" y1="1.27" x2="3.81" y2="1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
</package>
<package name="JMP2-1Z-R">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="3.81" y2="-1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="1.0922" diameter="2.0066"/>
<pad name="2" x="2.54" y="0" drill="1.0922" diameter="2.0066"/>
<text x="-1.905" y="0" size="1.27" layer="25" rot="R180">&gt;NAME</text>
<text x="-1.905" y="1.27" size="1.016" layer="27" rot="R180">&gt;VALUE</text>
<text x="-1.905" y="0.635" size="1.27" layer="51" ratio="12" rot="R180">&gt;NAME</text>
<wire x1="-1.27" y1="1.27" x2="3.81" y2="1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
<wire x1="0" y1="0" x2="12.7" y2="0" width="0.508" layer="21"/>
<rectangle x1="4.445" y1="-1.27" x2="6.35" y2="1.27" layer="21"/>
</package>
<package name="JMP2-1Z-L">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="3.81" y2="-1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="1.27" width="0.254" layer="21"/>
<wire x1="3.81" y1="1.27" x2="-1.27" y2="1.27" width="0.254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="1.0922" diameter="2.0066"/>
<pad name="2" x="2.54" y="0" drill="1.0922" diameter="2.0066"/>
<text x="4.445" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="4.445" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="4.445" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-1.27" y1="1.27" x2="3.81" y2="1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="1.27" x2="3.81" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="3.81" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="1.27" width="0.2032" layer="51"/>
<wire x1="2.54" y1="0" x2="-10.16" y2="0" width="0.508" layer="21"/>
<rectangle x1="-3.81" y1="-1.27" x2="-1.905" y2="1.27" layer="21" rot="R180"/>
</package>
<package name="JMP2-LEZ-R">
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="1.27" y1="-1.27" x2="1.27" y2="3.81" width="0.254" layer="21"/>
<wire x1="1.27" y1="3.81" x2="-1.27" y2="3.81" width="0.254" layer="21"/>
<wire x1="-1.27" y1="3.81" x2="-1.27" y2="-1.27" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="1.905" x2="0.635" y2="1.905" width="0.254" layer="21"/>
<wire x1="0.635" y1="3.175" x2="0.635" y2="1.905" width="0.254" layer="21"/>
<wire x1="0.635" y1="3.175" x2="-0.635" y2="3.175" width="0.254" layer="21"/>
<wire x1="-0.635" y1="1.905" x2="-0.635" y2="3.175" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="1.0922" diameter="2.0066" rot="R90"/>
<pad name="2" x="0" y="2.54" drill="1.0922" diameter="2.0066" rot="R90"/>
<text x="-1.905" y="1.27" size="1.27" layer="25" rot="R180">&gt;NAME</text>
<text x="-1.905" y="2.54" size="1.016" layer="27" rot="R180">&gt;VALUE</text>
<text x="-1.905" y="1.905" size="1.27" layer="51" ratio="12" rot="R180">&gt;NAME</text>
<wire x1="-1.27" y1="-1.27" x2="-1.27" y2="3.81" width="0.2032" layer="51"/>
<wire x1="-1.27" y1="3.81" x2="1.27" y2="3.81" width="0.2032" layer="51"/>
<wire x1="1.27" y1="3.81" x2="1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="1.27" y1="-1.27" x2="-1.27" y2="-1.27" width="0.2032" layer="51"/>
<wire x1="0" y1="0" x2="12.7" y2="0" width="0.508" layer="21"/>
<rectangle x1="1.905" y1="-1.27" x2="3.81" y2="1.27" layer="21"/>
<rectangle x1="1.905" y1="1.27" x2="3.81" y2="3.81" layer="21"/>
<wire x1="0" y1="2.54" x2="12.7" y2="2.54" width="0.508" layer="21"/>
</package>
<package name="JMP2-1PR">
<wire x1="-1.27" y1="1.27" x2="-1.27" y2="-1.27" width="0.0254" layer="21"/>
<wire x1="-1.27" y1="-1.27" x2="3.81" y2="-1.27" width="0.0254" layer="21"/>
<wire x1="3.81" y1="-1.27" x2="3.81" y2="1.27" width="0.0254" layer="21"/>
<wire x1="3.81" y1="1.27" x2="-1.27" y2="1.27" width="0.0254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="-0.635" x2="0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="3.175" y1="-0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="0.635" x2="3.175" y2="0.635" width="0.254" layer="21"/>
<pad name="1" x="0" y="0" drill="0.9906" diameter="1.4986"/>
<pad name="2" x="2.54" y="0" drill="0.9906" diameter="1.4986"/>
<text x="4.445" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="4.445" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="4.445" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="JUMP2-1PR-SMD">
<text x="-2.54" y="1.27" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="3.175" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="1.905" size="1.27" layer="51" ratio="12">&gt;NAME</text>
<wire x1="-2.54" y1="1.27" x2="-2.54" y2="-1.27" width="0.0254" layer="21"/>
<wire x1="-2.54" y1="-1.27" x2="2.54" y2="-1.27" width="0.0254" layer="21"/>
<wire x1="2.54" y1="-1.27" x2="2.54" y2="1.27" width="0.0254" layer="21"/>
<wire x1="2.54" y1="1.27" x2="-2.54" y2="1.27" width="0.0254" layer="21"/>
<wire x1="-1.905" y1="0.635" x2="-1.905" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-1.905" y1="-0.635" x2="-0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="-0.635" x2="-0.635" y2="0.635" width="0.254" layer="21"/>
<wire x1="-0.635" y1="0.635" x2="-1.905" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="-0.635" x2="0.635" y2="-0.635" width="0.254" layer="21"/>
<wire x1="1.905" y1="-0.635" x2="1.905" y2="0.635" width="0.254" layer="21"/>
<wire x1="0.635" y1="0.635" x2="1.905" y2="0.635" width="0.254" layer="21"/>
<smd name="1" x="-2.54" y="0" dx="3.556" dy="1.27" layer="1"/>
<smd name="2" x="2.54" y="0" dx="3.556" dy="1.27" layer="1"/>
</package>
<package name="P_BOD_16">
<circle x="0" y="0" radius="0.9398" width="0.254" layer="21"/>
<circle x="0" y="0" radius="0.9398" width="0.254" layer="22"/>
<pad name="1" x="0" y="0" drill="1.6002" diameter="3.2004"/>
<text x="1.905" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="1.905" y="-0.635" size="1.27" layer="51" ratio="12">&gt;NAME</text>
</package>
<package name="SW-100DP1T2">
<wire x1="-12.7" y1="6.35" x2="-3.7" y2="6.35" width="0.254" layer="21"/>
<wire x1="-3.7" y1="6.35" x2="-3.7" y2="1.65" width="0.254" layer="21"/>
<wire x1="-3.7" y1="1.65" x2="-3.7" y2="-1.65" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-1.65" x2="-3.7" y2="-3.05" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-3.05" x2="-3.7" y2="-6.35" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-6.35" x2="-12.7" y2="-6.35" width="0.254" layer="21"/>
<wire x1="-12.7" y1="-6.35" x2="-12.7" y2="-3.175" width="0.254" layer="21"/>
<wire x1="-12.7" y1="-3.175" x2="-12.7" y2="3.175" width="0.254" layer="21"/>
<wire x1="-12.7" y1="3.175" x2="-12.7" y2="6.35" width="0.254" layer="21"/>
<pad name="2" x="0" y="0" drill="1.85" diameter="3"/>
<pad name="3" x="0" y="4.7" drill="1.85" diameter="3"/>
<pad name="1" x="0" y="-4.7" drill="1.85" diameter="3"/>
<pad name="S1" x="-12.7" y="-2.54" drill="1.85" diameter="3"/>
<pad name="S2" x="-12.7" y="2.54" drill="1.85" diameter="3"/>
<text x="-10.16" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-10.16" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-10.795" y="6.985" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<pad name="4" x="3.81" y="-4.7" drill="1.85" diameter="3"/>
<pad name="5" x="3.81" y="0" drill="1.85" diameter="3"/>
<pad name="6" x="3.81" y="4.7" drill="1.85" diameter="3"/>
<wire x1="-2.7" y1="0.635" x2="4.445" y2="0.635" width="0.254" layer="21"/>
<wire x1="4.445" y1="0.635" x2="4.445" y2="-0.635" width="0.254" layer="21"/>
<wire x1="4.445" y1="-0.635" x2="-2.7" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-2.7" y1="5.335" x2="4.445" y2="5.335" width="0.254" layer="21"/>
<wire x1="4.445" y1="4.065" x2="-2.7" y2="4.065" width="0.254" layer="21"/>
<wire x1="4.445" y1="5.335" x2="4.445" y2="4.065" width="0.254" layer="21"/>
<wire x1="4.445" y1="-5.335" x2="-2.7" y2="-5.335" width="0.254" layer="21"/>
<wire x1="-2.7" y1="-4.065" x2="4.445" y2="-4.065" width="0.254" layer="21"/>
<wire x1="4.445" y1="-4.065" x2="4.445" y2="-5.335" width="0.254" layer="21"/>
<wire x1="-2.7" y1="4.065" x2="-2.7" y2="5.335" width="0.254" layer="21"/>
<wire x1="-3.7" y1="6.35" x2="-2.7" y2="5.335" width="0.254" layer="21"/>
<wire x1="-3.7" y1="3.05" x2="-2.7" y2="4.065" width="0.254" layer="21"/>
<wire x1="-3.7" y1="1.65" x2="-2.7" y2="0.635" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-3.05" x2="-2.7" y2="-4.065" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-1.65" x2="-2.7" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-3.7" y1="-6.35" x2="-2.7" y2="-5.335" width="0.254" layer="21"/>
<wire x1="-2.7" y1="-0.635" x2="-2.7" y2="0.635" width="0.254" layer="21"/>
<wire x1="-2.7" y1="-5.335" x2="-2.7" y2="-4.065" width="0.254" layer="21"/>
<wire x1="-19.8" y1="2.375" x2="-19.8" y2="1.8" width="0.254" layer="21"/>
<wire x1="-19.8" y1="1.8" x2="-19.8" y2="-2.375" width="0.254" layer="21"/>
<wire x1="-19" y1="3.175" x2="-12.7" y2="3.175" width="0.254" layer="21"/>
<wire x1="-19" y1="-3.175" x2="-12.7" y2="-3.175" width="0.254" layer="21"/>
<wire x1="-19" y1="-3.175" x2="-19" y2="3.175" width="0.254" layer="21"/>
<wire x1="-19.8" y1="2.375" x2="-19" y2="3.175" width="0.254" layer="21"/>
<wire x1="-19" y1="-3.175" x2="-19.8" y2="-2.375" width="0.254" layer="21"/>
<wire x1="-19.8" y1="-0.4" x2="-25.1" y2="0.9" width="0.254" layer="21"/>
<wire x1="-19.8" y1="1.8" x2="-24.7" y2="3" width="0.254" layer="21"/>
<wire x1="-25.1" y1="0.9" x2="-24.7" y2="3" width="0.254" layer="21" curve="-180"/>
<wire x1="-12.7" y1="6.35" x2="-3.7" y2="6.35" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="6.35" x2="-3.7" y2="5.335" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="5.335" x2="-3.7" y2="4.065" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="4.065" x2="-3.7" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="0.635" x2="-3.7" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-0.635" x2="-3.7" y2="-4.065" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-4.065" x2="-3.7" y2="-5.335" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-5.335" x2="-3.7" y2="-6.35" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-6.35" x2="-12.7" y2="-6.35" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="5.335" x2="-1.7" y2="5.335" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="4.065" x2="-1.7" y2="4.065" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="0.635" x2="-1.7" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-0.635" x2="-1.7" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-4.065" x2="-1.7" y2="-4.065" width="0.2032" layer="51"/>
<wire x1="-3.7" y1="-5.335" x2="-1.7" y2="-5.335" width="0.2032" layer="51"/>
</package>
<package name="TL-PTS647">
<description>Littelfuse PTS647 Series Tactile Switch 4,5x4,5mm</description>
<smd name="1" x="-2.8" y="1.5" dx="1.55" dy="1" layer="1"/>
<smd name="2" x="2.8" y="1.5" dx="1.55" dy="1" layer="1"/>
<smd name="3" x="-2.8" y="-1.5" dx="1.55" dy="1" layer="1"/>
<smd name="4" x="2.8" y="-1.5" dx="1.55" dy="1" layer="1"/>
<text x="-3.175" y="3.81" size="1.27" layer="25">&gt;NAME</text>
<text x="-3.175" y="2.54" size="1.016" layer="27">&gt;VALUE</text>
<text x="-2.54" y="2.54" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<circle x="0" y="0" radius="1.15" width="0.2032" layer="21"/>
<wire x1="2.25" y1="2.25" x2="-2.25" y2="2.25" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="0.75" x2="-2.25" y2="-0.75" width="0.2032" layer="51"/>
<wire x1="2.25" y1="0.75" x2="2.25" y2="-0.75" width="0.2032" layer="51"/>
<wire x1="2.25" y1="-2.25" x2="-2.25" y2="-2.25" width="0.2032" layer="51"/>
<wire x1="-2.25" y1="2.25" x2="2.25" y2="2.25" width="0.254" layer="21"/>
<wire x1="2.25" y1="-2.25" x2="-2.25" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-2.25" y1="-2.25" x2="-2.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="-2.25" y1="-1.85" x2="-2.25" y2="-1.15" width="0.254" layer="21"/>
<wire x1="-2.25" y1="-1.15" x2="-2.25" y2="1.15" width="0.254" layer="21"/>
<wire x1="-2.25" y1="1.15" x2="-2.25" y2="1.85" width="0.254" layer="21"/>
<wire x1="-2.25" y1="1.85" x2="-2.25" y2="2.25" width="0.254" layer="21"/>
<wire x1="2.25" y1="2.25" x2="2.25" y2="-1.15" width="0.254" layer="21"/>
<wire x1="2.25" y1="-1.15" x2="2.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="2.25" y1="-1.85" x2="2.25" y2="-2.25" width="0.254" layer="21"/>
<wire x1="-2.25" y1="1.15" x2="-3.25" y2="1.15" width="0.254" layer="21"/>
<wire x1="-3.25" y1="1.15" x2="-3.25" y2="1.85" width="0.254" layer="21"/>
<wire x1="-3.25" y1="1.85" x2="-2.25" y2="1.85" width="0.254" layer="21"/>
<wire x1="3.25" y1="-1.15" x2="3.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="3.25" y1="-1.85" x2="2.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="2.25" y1="-1.15" x2="3.25" y2="-1.15" width="0.254" layer="21"/>
<wire x1="2.25" y1="1.15" x2="3.25" y2="1.15" width="0.254" layer="21"/>
<wire x1="3.25" y1="1.85" x2="2.25" y2="1.85" width="0.254" layer="21"/>
<wire x1="3.25" y1="1.15" x2="3.25" y2="1.85" width="0.254" layer="21"/>
<wire x1="-3.25" y1="-1.85" x2="-2.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="-3.25" y1="-1.15" x2="-3.25" y2="-1.85" width="0.254" layer="21"/>
<wire x1="-2.25" y1="-1.15" x2="-3.25" y2="-1.15" width="0.254" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="TLACIT_S">
<wire x1="3.0988" y1="0" x2="3.81" y2="0" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="0" x2="-3.0734" y2="0" width="0.1524" layer="94"/>
<wire x1="-2.54" y1="1.27" x2="-0.635" y2="1.27" width="0.4064" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="-0.635" y2="3.175" width="0.1524" layer="94"/>
<wire x1="-0.635" y1="1.27" x2="0.635" y2="1.27" width="0.4064" layer="94"/>
<wire x1="0.635" y1="1.27" x2="0.635" y2="3.175" width="0.1524" layer="94"/>
<wire x1="0.635" y1="1.27" x2="2.54" y2="1.27" width="0.4064" layer="94"/>
<circle x="2.54" y="0" radius="0.5334" width="0.1524" layer="94"/>
<circle x="-2.54" y="0" radius="0.5334" width="0.1524" layer="94"/>
<text x="-2.54" y="3.81" size="1.524" layer="95">&gt;NAME</text>
<text x="-3.81" y="-2.54" size="1.524" layer="96">&gt;VALUE</text>
<pin name="1" x="-6.35" y="0" visible="pad" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="6.35" y="0" visible="pad" length="short" direction="pas" swaplevel="1" rot="R180"/>
</symbol>
<symbol name="JMP2-1">
<wire x1="-3.302" y1="0.762" x2="-1.778" y2="0.762" width="0.254" layer="94"/>
<wire x1="-1.778" y1="0.762" x2="-1.778" y2="-0.762" width="0.254" layer="94"/>
<wire x1="-1.778" y1="-0.762" x2="-3.302" y2="-0.762" width="0.254" layer="94"/>
<wire x1="-3.302" y1="0.762" x2="-3.302" y2="-0.762" width="0.254" layer="94"/>
<wire x1="3.302" y1="-0.762" x2="1.778" y2="-0.762" width="0.254" layer="94"/>
<wire x1="1.778" y1="-0.762" x2="1.778" y2="0.762" width="0.254" layer="94"/>
<wire x1="1.778" y1="0.762" x2="3.302" y2="0.762" width="0.254" layer="94"/>
<wire x1="3.302" y1="-0.762" x2="3.302" y2="0.762" width="0.254" layer="94"/>
<text x="-0.635" y="1.905" size="1.524" layer="95">&gt;NAME</text>
<pin name="1" x="-5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="2" x="5.08" y="0" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<text x="-0.635" y="-3.175" size="1.524" layer="96">&gt;VALUE</text>
</symbol>
<symbol name="M-BOD">
<wire x1="-2.54" y1="0" x2="-1.016" y2="0" width="0.1524" layer="94"/>
<circle x="0" y="0" radius="1.016" width="0.1524" layer="94"/>
<text x="-2.54" y="1.27" size="1.524" layer="95">&gt;NAME</text>
<pin name="1" x="-2.54" y="0" visible="off" length="point" direction="pas" swaplevel="1"/>
</symbol>
<symbol name="SW-PREP2">
<wire x1="-2.5654" y1="5.08" x2="1.27" y2="7.2644" width="0.4064" layer="94"/>
<wire x1="1.27" y1="6.35" x2="1.27" y2="7.2644" width="0.1524" layer="94"/>
<wire x1="1.27" y1="7.2644" x2="1.27" y2="7.62" width="0.1524" layer="94"/>
<wire x1="1.27" y1="2.54" x2="2.54" y2="2.54" width="0.1524" layer="94"/>
<wire x1="1.27" y1="7.62" x2="2.54" y2="7.62" width="0.1524" layer="94"/>
<circle x="-2.54" y="5.08" radius="0.4064" width="0.4064" layer="94"/>
<circle x="-2.54" y="5.08" radius="0.0762" width="0.4064" layer="94"/>
<text x="-2.54" y="12.7" size="1.524" layer="95">&gt;NAME</text>
<pin name="2" x="-5.08" y="5.08" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="1" x="5.08" y="7.62" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="3" x="5.08" y="2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<wire x1="1.27" y1="2.54" x2="1.27" y2="3.81" width="0.1524" layer="94"/>
<text x="-2.54" y="10.16" size="1.524" layer="96">&gt;VALUE</text>
<wire x1="-2.5654" y1="-5.08" x2="1.27" y2="-2.8956" width="0.4064" layer="94"/>
<wire x1="1.27" y1="-3.81" x2="1.27" y2="-2.8956" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-2.8956" x2="1.27" y2="-2.54" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-7.62" x2="2.54" y2="-7.62" width="0.1524" layer="94"/>
<wire x1="1.27" y1="-2.54" x2="2.54" y2="-2.54" width="0.1524" layer="94"/>
<circle x="-2.54" y="-5.08" radius="0.4064" width="0.4064" layer="94"/>
<circle x="-2.54" y="-5.08" radius="0.0762" width="0.4064" layer="94"/>
<pin name="5" x="-5.08" y="-5.08" visible="off" length="short" direction="pas" swaplevel="1"/>
<pin name="4" x="5.08" y="-2.54" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<pin name="6" x="5.08" y="-7.62" visible="off" length="short" direction="pas" swaplevel="1" rot="R180"/>
<wire x1="1.27" y1="-7.62" x2="1.27" y2="-6.35" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-4.445" x2="-3.81" y2="-3.175" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-5.715" x2="-3.81" y2="-6.985" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-8.255" x2="-3.81" y2="-8.89" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-8.89" x2="-3.81" y2="-9.525" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-9.525" x2="-2.54" y2="-9.525" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="8.255" x2="-3.81" y2="9.525" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="9.525" x2="-2.54" y2="9.525" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="-9.525" x2="0" y2="-9.525" width="0.1524" layer="94"/>
<wire x1="-1.27" y1="9.525" x2="0" y2="9.525" width="0.1524" layer="94"/>
<circle x="-3.81" y="-8.89" radius="0.2032" width="0.4064" layer="94"/>
<pin name="SHLD" x="-5.08" y="-8.89" visible="off" length="point" direction="pas" swaplevel="1"/>
<wire x1="-5.08" y1="-8.89" x2="-3.81" y2="-8.89" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="-1.905" x2="-3.81" y2="-0.635" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="0.635" x2="-3.81" y2="1.905" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="3.175" x2="-3.81" y2="4.445" width="0.1524" layer="94"/>
<wire x1="-3.81" y1="5.715" x2="-3.81" y2="6.985" width="0.1524" layer="94"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="TL-SMD" prefix="TL" uservalue="yes">
<gates>
<gate name="A" symbol="TLACIT_S" x="0" y="0"/>
</gates>
<devices>
<device name="-TS21" package="TL-TS21">
<connects>
<connect gate="A" pin="1" pad="1 2"/>
<connect gate="A" pin="2" pad="3 4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-PTS647" package="TL-PTS647">
<connects>
<connect gate="A" pin="1" pad="1 2"/>
<connect gate="A" pin="2" pad="3 4"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="JMP2-1" prefix="XT" uservalue="yes">
<gates>
<gate name="A" symbol="JMP2-1" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="" package="JMP2-1">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="Z-R" package="JMP2-1Z-R">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="Z-L" package="JMP2-1Z-L">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="LEZ-R" package="JMP2-LEZ-R">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-PR" package="JMP2-1PR">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
<device name="-PRSMD" package="JUMP2-1PR-SMD">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PAJ_B_16" prefix="XT" uservalue="yes">
<gates>
<gate name="A" symbol="M-BOD" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="" package="P_BOD_16">
<connects>
<connect gate="A" pin="1" pad="1"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="SW-100DP1T2B" prefix="SW" uservalue="yes">
<gates>
<gate name="A" symbol="SW-PREP2" x="0" y="0"/>
</gates>
<devices>
<device name="" package="SW-100DP1T2">
<connects>
<connect gate="A" pin="1" pad="1"/>
<connect gate="A" pin="2" pad="2"/>
<connect gate="A" pin="3" pad="3"/>
<connect gate="A" pin="4" pad="4"/>
<connect gate="A" pin="5" pad="5"/>
<connect gate="A" pin="6" pad="6"/>
<connect gate="A" pin="SHLD" pad="S1 S2"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="MEMORY">
<packages>
<package name="SO8">
<smd name="1" x="-1.905" y="-2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="8" x="-1.905" y="2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="2" x="-0.635" y="-2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="3" x="0.635" y="-2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="7" x="-0.635" y="2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="6" x="0.635" y="2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="4" x="1.905" y="-2.54" dx="0.6096" dy="1.524" layer="1"/>
<smd name="5" x="1.905" y="2.54" dx="0.6096" dy="1.524" layer="1"/>
<wire x1="-2.5146" y1="-1.6002" x2="2.5146" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="2.5146" y1="-1.6002" x2="2.5146" y2="-1.3462" width="0.254" layer="21"/>
<wire x1="2.5146" y1="-1.3462" x2="2.5146" y2="-1.0922" width="0.254" layer="21"/>
<wire x1="2.5146" y1="-1.0922" x2="2.5146" y2="1.6002" width="0.254" layer="21"/>
<wire x1="2.5146" y1="1.6002" x2="-2.5146" y2="1.6002" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="1.6002" x2="-2.5146" y2="0.635" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="0.635" x2="-2.0574" y2="0.635" width="0.254" layer="21"/>
<wire x1="-2.0574" y1="0.635" x2="-2.0574" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-2.0574" y1="-0.635" x2="-2.5146" y2="-0.635" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="-0.635" x2="-2.5146" y2="-1.0922" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="-1.0922" x2="-2.5146" y2="-1.3462" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="-1.3462" x2="-2.5146" y2="-1.6002" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="-0.635" x2="-2.5146" y2="-3.6068" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="-3.6068" x2="2.5146" y2="-3.6068" width="0.2032" layer="51"/>
<wire x1="2.5146" y1="-3.6068" x2="2.5146" y2="3.6068" width="0.2032" layer="51"/>
<wire x1="2.5146" y1="3.6068" x2="-2.5146" y2="3.6068" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="3.6068" x2="-2.5146" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="0.635" x2="-2.0574" y2="0.635" width="0.2032" layer="51"/>
<wire x1="-2.0574" y1="0.635" x2="-2.0574" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-2.0574" y1="-0.635" x2="-2.5146" y2="-0.635" width="0.2032" layer="51"/>
<wire x1="-2.5146" y1="-1.3462" x2="2.5146" y2="-1.3462" width="0.254" layer="21"/>
<wire x1="-2.5146" y1="-1.0922" x2="2.5146" y2="-1.0922" width="0.254" layer="21"/>
<text x="-1.27" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-1.27" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-1.905" y="-0.4445" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<rectangle x1="-2.0828" y1="-2.667" x2="-1.7272" y2="-1.651" layer="21"/>
<rectangle x1="-0.8128" y1="-2.667" x2="-0.4572" y2="-1.651" layer="21"/>
<rectangle x1="0.4572" y1="-2.667" x2="0.8128" y2="-1.651" layer="21"/>
<rectangle x1="1.7272" y1="-2.667" x2="2.0828" y2="-1.651" layer="21"/>
<rectangle x1="-2.0828" y1="1.651" x2="-1.7272" y2="2.667" layer="21"/>
<rectangle x1="-0.8128" y1="1.651" x2="-0.4572" y2="2.667" layer="21"/>
<rectangle x1="0.4572" y1="1.651" x2="0.8128" y2="2.667" layer="21"/>
<rectangle x1="1.7272" y1="1.651" x2="2.0828" y2="2.667" layer="21"/>
</package>
</packages>
<symbols>
<symbol name="PWR18">
<text x="-0.635" y="-0.635" size="1.27" layer="95">&gt;NAME</text>
<text x="0.635" y="-6.985" size="1.27" layer="95" rot="R90">GND</text>
<text x="0.635" y="3.81" size="1.27" layer="95" rot="R90">VCC</text>
<pin name="GND" x="0" y="-10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R90"/>
<pin name="VCC" x="0" y="10.16" visible="pad" length="short" direction="pwr" swaplevel="1" rot="R270"/>
</symbol>
<symbol name="W25Q16">
<wire x1="-8.89" y1="-6.35" x2="8.89" y2="-6.35" width="0.254" layer="94"/>
<wire x1="8.89" y1="-6.35" x2="8.89" y2="6.35" width="0.254" layer="94"/>
<wire x1="8.89" y1="6.35" x2="-8.89" y2="6.35" width="0.254" layer="94"/>
<wire x1="-8.89" y1="6.35" x2="-8.89" y2="-6.35" width="0.254" layer="94"/>
<text x="-8.89" y="7.62" size="1.524" layer="95">&gt;NAME</text>
<text x="-8.89" y="-8.89" size="1.524" layer="96">&gt;VALUE</text>
<pin name="!HOLD!(IO3)" x="-13.97" y="-3.81" length="middle" direction="in" swaplevel="1"/>
<pin name="!WP!(IO2)" x="-13.97" y="-1.27" length="middle" direction="in" swaplevel="1"/>
<pin name="DO(IO1)" x="-13.97" y="1.27" length="middle" direction="out" swaplevel="1"/>
<pin name="DI(IO0)" x="-13.97" y="3.81" length="middle" direction="in" swaplevel="1"/>
<pin name="CLK" x="13.97" y="-1.27" length="middle" direction="in" swaplevel="1" rot="R180"/>
<pin name="!CS" x="13.97" y="1.27" length="middle" direction="in" swaplevel="1" rot="R180"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="W25Q16" prefix="IC" uservalue="yes">
<gates>
<gate name="P" symbol="PWR18" x="13.97" y="0" addlevel="request"/>
<gate name="A" symbol="W25Q16" x="-8.89" y="0"/>
</gates>
<devices>
<device name="-SN" package="SO8">
<connects>
<connect gate="A" pin="!CS" pad="1"/>
<connect gate="A" pin="!HOLD!(IO3)" pad="7"/>
<connect gate="A" pin="!WP!(IO2)" pad="3"/>
<connect gate="A" pin="CLK" pad="6"/>
<connect gate="A" pin="DI(IO0)" pad="5"/>
<connect gate="A" pin="DO(IO1)" pad="2"/>
<connect gate="P" pin="GND" pad="4"/>
<connect gate="P" pin="VCC" pad="8"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="INTEL">
<packages>
<package name="QFN80">
<text x="-2.54" y="0" size="1.27" layer="25">&gt;NAME</text>
<text x="-2.54" y="-1.27" size="1.016" layer="27">&gt;VALUE</text>
<text x="-3.175" y="5.6515" size="1.27" layer="51" font="vector" ratio="12">&gt;NAME</text>
<wire x1="-5" y1="5" x2="-4.1" y2="5" width="0.2032" layer="51"/>
<wire x1="4.1" y1="5" x2="5" y2="5" width="0.2032" layer="51"/>
<wire x1="-5" y1="4.1" x2="-5" y2="5" width="0.2032" layer="51"/>
<smd name="1" x="-4.8965" y="3.8" dx="0.78" dy="0.22" layer="1"/>
<wire x1="-5" y1="5" x2="5" y2="5" width="0.254" layer="21"/>
<wire x1="5" y1="5" x2="5" y2="-5" width="0.254" layer="21"/>
<wire x1="5" y1="-5" x2="-5" y2="-5" width="0.254" layer="21"/>
<wire x1="-5" y1="-5" x2="-5" y2="5" width="0.254" layer="21"/>
<circle x="-4" y="4" radius="0.2827" width="0.254" layer="21"/>
<smd name="EP" x="0" y="0" dx="3.4" dy="3.4" layer="1"/>
<smd name="2" x="-4.8965" y="3.4" dx="0.78" dy="0.22" layer="1"/>
<smd name="3" x="-4.8965" y="3" dx="0.78" dy="0.22" layer="1"/>
<smd name="4" x="-4.8965" y="2.6" dx="0.78" dy="0.22" layer="1"/>
<smd name="5" x="-4.8965" y="2.2" dx="0.78" dy="0.22" layer="1"/>
<smd name="6" x="-4.8965" y="1.8" dx="0.78" dy="0.22" layer="1"/>
<smd name="7" x="-4.8965" y="1.4" dx="0.78" dy="0.22" layer="1"/>
<smd name="8" x="-4.8965" y="1" dx="0.78" dy="0.22" layer="1"/>
<smd name="9" x="-4.8965" y="0.6" dx="0.78" dy="0.22" layer="1"/>
<smd name="10" x="-4.8965" y="0.2" dx="0.78" dy="0.22" layer="1"/>
<smd name="11" x="-4.8965" y="-0.2" dx="0.78" dy="0.22" layer="1"/>
<smd name="12" x="-4.8965" y="-0.6" dx="0.78" dy="0.22" layer="1"/>
<smd name="13" x="-4.8965" y="-1" dx="0.78" dy="0.22" layer="1"/>
<smd name="14" x="-4.8965" y="-1.4" dx="0.78" dy="0.22" layer="1"/>
<smd name="15" x="-4.8965" y="-1.8" dx="0.78" dy="0.22" layer="1"/>
<smd name="16" x="-4.8965" y="-2.2" dx="0.78" dy="0.22" layer="1"/>
<smd name="17" x="-4.8965" y="-2.6" dx="0.78" dy="0.22" layer="1"/>
<smd name="18" x="-4.8965" y="-3" dx="0.78" dy="0.22" layer="1"/>
<smd name="19" x="-4.8965" y="-3.4" dx="0.78" dy="0.22" layer="1"/>
<smd name="20" x="-4.8965" y="-3.8" dx="0.78" dy="0.22" layer="1"/>
<smd name="21" x="-3.8" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="22" x="-3.4" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="23" x="-3" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="24" x="-2.6" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="25" x="-2.2" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="26" x="-1.8" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="27" x="-1.4" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="28" x="-1" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="29" x="-0.6" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="30" x="-0.2" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="31" x="0.2" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="32" x="0.6" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="33" x="1" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="34" x="1.4" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="35" x="1.8" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="36" x="2.2" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="37" x="2.6" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="38" x="3" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="39" x="3.4" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="40" x="3.8" y="-4.8965" dx="0.78" dy="0.22" layer="1" rot="R90"/>
<smd name="41" x="4.8965" y="-3.8" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="42" x="4.8965" y="-3.4" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="43" x="4.8965" y="-3" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="44" x="4.8965" y="-2.6" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="45" x="4.8965" y="-2.2" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="46" x="4.8965" y="-1.8" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="47" x="4.8965" y="-1.4" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="48" x="4.8965" y="-1" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="49" x="4.8965" y="-0.6" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="50" x="4.8965" y="-0.2" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="51" x="4.8965" y="0.2" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="52" x="4.8965" y="0.6" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="53" x="4.8965" y="1" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="54" x="4.8965" y="1.4" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="55" x="4.8965" y="1.8" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="56" x="4.8965" y="2.2" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="57" x="4.8965" y="2.6" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="58" x="4.8965" y="3" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="59" x="4.8965" y="3.4" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="60" x="4.8965" y="3.8" dx="0.78" dy="0.22" layer="1" rot="R180"/>
<smd name="61" x="3.8" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="62" x="3.4" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="63" x="3" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="64" x="2.6" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="65" x="2.2" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="66" x="1.8" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="67" x="1.4" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="68" x="1" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="69" x="0.6" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="70" x="0.2" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="71" x="-0.2" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="72" x="-0.6" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="73" x="-1" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="74" x="-1.4" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="75" x="-1.8" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="76" x="-2.2" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="77" x="-2.6" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="78" x="-3" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="79" x="-3.4" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<smd name="80" x="-3.8" y="4.8965" dx="0.78" dy="0.22" layer="1" rot="R270"/>
<wire x1="-5.3" y1="4.3" x2="-5.3" y2="5.3" width="0.254" layer="51"/>
<wire x1="-5.3" y1="5.3" x2="-4.3" y2="5.3" width="0.254" layer="51"/>
<wire x1="5" y1="-4.1" x2="5" y2="-5" width="0.2032" layer="51"/>
<wire x1="5" y1="-5" x2="4.1" y2="-5" width="0.2032" layer="51"/>
<wire x1="-4.1" y1="-5" x2="-5" y2="-5" width="0.2032" layer="51"/>
<wire x1="-5" y1="-5" x2="-5" y2="-4.1" width="0.2032" layer="51"/>
<wire x1="5" y1="5" x2="5" y2="4.1" width="0.2032" layer="51"/>
</package>
</packages>
<symbols>
<symbol name="RP2350">
<wire x1="-30.48" y1="-68.58" x2="30.48" y2="-68.58" width="0.254" layer="94"/>
<wire x1="30.48" y1="-68.58" x2="30.48" y2="68.58" width="0.254" layer="94"/>
<wire x1="30.48" y1="68.58" x2="-30.48" y2="68.58" width="0.254" layer="94"/>
<wire x1="-30.48" y1="68.58" x2="-30.48" y2="-68.58" width="0.254" layer="94"/>
<text x="-30.48" y="69.85" size="1.524" layer="95">&gt;NAME</text>
<text x="-30.48" y="-71.12" size="1.524" layer="96">&gt;VALUE</text>
<pin name="USB_DP" x="-35.56" y="66.04" length="middle" swaplevel="1"/>
<pin name="USB_DM" x="-35.56" y="63.5" length="middle" swaplevel="1"/>
<pin name="GPIO0" x="-35.56" y="55.88" length="middle" swaplevel="1"/>
<pin name="GPIO1" x="-35.56" y="53.34" length="middle" swaplevel="1"/>
<pin name="GPIO2" x="-35.56" y="50.8" length="middle" swaplevel="1"/>
<pin name="GPIO3" x="-35.56" y="48.26" length="middle" swaplevel="1"/>
<pin name="GPIO4" x="-35.56" y="45.72" length="middle" swaplevel="1"/>
<pin name="GPIO5" x="-35.56" y="43.18" length="middle" swaplevel="1"/>
<pin name="GPIO6" x="-35.56" y="40.64" length="middle" swaplevel="1"/>
<pin name="GPIO7" x="-35.56" y="38.1" length="middle" swaplevel="1"/>
<pin name="GPIO8" x="-35.56" y="35.56" length="middle" swaplevel="1"/>
<pin name="GPIO9" x="-35.56" y="33.02" length="middle" swaplevel="1"/>
<pin name="GPIO10" x="-35.56" y="30.48" length="middle" swaplevel="1"/>
<pin name="GPIO11" x="-35.56" y="27.94" length="middle" swaplevel="1"/>
<pin name="GPIO12" x="-35.56" y="25.4" length="middle" swaplevel="1"/>
<pin name="GPIO13" x="-35.56" y="22.86" length="middle" swaplevel="1"/>
<pin name="GPIO14" x="-35.56" y="20.32" length="middle" swaplevel="1"/>
<pin name="GPIO15" x="-35.56" y="17.78" length="middle" swaplevel="1"/>
<pin name="GPIO16" x="-35.56" y="15.24" length="middle" swaplevel="1"/>
<pin name="GPIO17" x="-35.56" y="12.7" length="middle" swaplevel="1"/>
<pin name="GPIO18" x="-35.56" y="10.16" length="middle" swaplevel="1"/>
<pin name="GPIO19" x="-35.56" y="7.62" length="middle" swaplevel="1"/>
<pin name="GPIO20" x="-35.56" y="5.08" length="middle" swaplevel="1"/>
<pin name="GPIO21" x="-35.56" y="2.54" length="middle" swaplevel="1"/>
<pin name="GPIO22" x="-35.56" y="0" length="middle" swaplevel="1"/>
<pin name="GPIO23" x="-35.56" y="-2.54" length="middle" swaplevel="1"/>
<pin name="GPIO24" x="-35.56" y="-5.08" length="middle" swaplevel="1"/>
<pin name="GPIO25" x="-35.56" y="-7.62" length="middle" swaplevel="1"/>
<pin name="GPIO26" x="-35.56" y="-10.16" length="middle" swaplevel="1"/>
<pin name="GPIO27" x="-35.56" y="-12.7" length="middle" swaplevel="1"/>
<pin name="GPIO28" x="-35.56" y="-15.24" length="middle" swaplevel="1"/>
<pin name="GPIO29" x="-35.56" y="-17.78" length="middle" swaplevel="1"/>
<pin name="GPIO30" x="-35.56" y="-20.32" length="middle" swaplevel="1"/>
<pin name="GPIO31" x="-35.56" y="-22.86" length="middle" swaplevel="1"/>
<pin name="GPIO32" x="-35.56" y="-25.4" length="middle" swaplevel="1"/>
<pin name="GPIO33" x="-35.56" y="-27.94" length="middle" swaplevel="1"/>
<pin name="GPIO34" x="-35.56" y="-30.48" length="middle" swaplevel="1"/>
<pin name="GPIO35" x="-35.56" y="-33.02" length="middle" swaplevel="1"/>
<pin name="GPIO36" x="-35.56" y="-35.56" length="middle" swaplevel="1"/>
<pin name="GPIO37" x="-35.56" y="-38.1" length="middle" swaplevel="1"/>
<pin name="GPIO38" x="-35.56" y="-40.64" length="middle" swaplevel="1"/>
<pin name="GPIO39" x="-35.56" y="-43.18" length="middle" swaplevel="1"/>
<pin name="GPIO40_ADC0" x="-35.56" y="-48.26" length="middle" swaplevel="1"/>
<pin name="GPIO41_ADC1" x="-35.56" y="-50.8" length="middle" swaplevel="1"/>
<pin name="GPIO42_ADC2" x="-35.56" y="-53.34" length="middle" swaplevel="1"/>
<pin name="GPIO43_ADC3" x="-35.56" y="-55.88" length="middle" swaplevel="1"/>
<pin name="GPIO44_ADC4" x="-35.56" y="-58.42" length="middle" swaplevel="1"/>
<pin name="GPIO45_ADC5" x="-35.56" y="-60.96" length="middle" swaplevel="1"/>
<pin name="GPIO46_ADC6" x="-35.56" y="-63.5" length="middle" swaplevel="1"/>
<pin name="GPIO47_ADC7" x="-35.56" y="-66.04" length="middle" swaplevel="1"/>
<pin name="ADC_AVDD" x="-16.51" y="73.66" length="middle" swaplevel="1" rot="R270"/>
<pin name="USB_OTP_VDD" x="-11.43" y="73.66" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD5" x="-6.35" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD29" x="-3.81" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD15" x="-1.27" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD24" x="1.27" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD41" x="3.81" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD50" x="6.35" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD60" x="8.89" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="IOVDD76" x="11.43" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<text x="-6.35" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<pin name="QSPI_IOVDD" x="16.51" y="73.66" length="middle" swaplevel="1" rot="R270"/>
<pin name="DVDD10" x="21.59" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="DVDD32" x="24.13" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<pin name="DVDD51" x="26.67" y="73.66" visible="pad" length="middle" swaplevel="1" rot="R270"/>
<text x="21.59" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">DVDD</text>
<text x="-3.81" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="-1.27" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="1.27" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="3.81" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="6.35" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="8.89" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="11.43" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">IOVDD</text>
<text x="24.13" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">DVDD</text>
<text x="26.67" y="66.04" size="1.524" layer="95" rot="R90" align="center-right">DVDD</text>
<pin name="VREG_AVDD" x="35.56" y="48.26" length="middle" swaplevel="1" rot="R180"/>
<pin name="VREG_VIN" x="35.56" y="45.72" length="middle" swaplevel="1" rot="R180"/>
<pin name="VREG_FB" x="35.56" y="43.18" length="middle" swaplevel="1" rot="R180"/>
<pin name="VREG_LX" x="35.56" y="40.64" length="middle" swaplevel="1" rot="R180"/>
<pin name="VREG_PGND" x="35.56" y="38.1" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SS" x="35.56" y="30.48" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SD0" x="35.56" y="25.4" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SD1" x="35.56" y="22.86" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SD2" x="35.56" y="20.32" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SD3" x="35.56" y="17.78" length="middle" swaplevel="1" rot="R180"/>
<pin name="QSPI_SCLK" x="35.56" y="12.7" length="middle" swaplevel="1" rot="R180"/>
<pin name="XIN" x="35.56" y="5.08" length="middle" swaplevel="1" rot="R180"/>
<pin name="XOUT" x="35.56" y="0" length="middle" swaplevel="1" rot="R180"/>
<pin name="!RESET" x="35.56" y="-12.7" length="middle" swaplevel="1" rot="R180"/>
<pin name="SWCLK" x="35.56" y="-25.4" length="middle" swaplevel="1" rot="R180"/>
<pin name="SWDIO" x="35.56" y="-27.94" length="middle" swaplevel="1" rot="R180"/>
<pin name="GND" x="0" y="-73.66" length="middle" swaplevel="1" rot="R90"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="RP2350" prefix="IC" uservalue="yes">
<gates>
<gate name="A" symbol="RP2350" x="0" y="0"/>
</gates>
<devices>
<device name="" package="QFN80">
<connects>
<connect gate="A" pin="!RESET" pad="35"/>
<connect gate="A" pin="ADC_AVDD" pad="59"/>
<connect gate="A" pin="DVDD10" pad="10"/>
<connect gate="A" pin="DVDD32" pad="32"/>
<connect gate="A" pin="DVDD51" pad="51"/>
<connect gate="A" pin="GND" pad="EP"/>
<connect gate="A" pin="GPIO0" pad="77"/>
<connect gate="A" pin="GPIO1" pad="78"/>
<connect gate="A" pin="GPIO10" pad="8"/>
<connect gate="A" pin="GPIO11" pad="9"/>
<connect gate="A" pin="GPIO12" pad="11"/>
<connect gate="A" pin="GPIO13" pad="12"/>
<connect gate="A" pin="GPIO14" pad="13"/>
<connect gate="A" pin="GPIO15" pad="14"/>
<connect gate="A" pin="GPIO16" pad="16"/>
<connect gate="A" pin="GPIO17" pad="17"/>
<connect gate="A" pin="GPIO18" pad="18"/>
<connect gate="A" pin="GPIO19" pad="19"/>
<connect gate="A" pin="GPIO2" pad="79"/>
<connect gate="A" pin="GPIO20" pad="20"/>
<connect gate="A" pin="GPIO21" pad="21"/>
<connect gate="A" pin="GPIO22" pad="22"/>
<connect gate="A" pin="GPIO23" pad="23"/>
<connect gate="A" pin="GPIO24" pad="25"/>
<connect gate="A" pin="GPIO25" pad="26"/>
<connect gate="A" pin="GPIO26" pad="27"/>
<connect gate="A" pin="GPIO27" pad="28"/>
<connect gate="A" pin="GPIO28" pad="36"/>
<connect gate="A" pin="GPIO29" pad="37"/>
<connect gate="A" pin="GPIO3" pad="80"/>
<connect gate="A" pin="GPIO30" pad="38"/>
<connect gate="A" pin="GPIO31" pad="39"/>
<connect gate="A" pin="GPIO32" pad="40"/>
<connect gate="A" pin="GPIO33" pad="42"/>
<connect gate="A" pin="GPIO34" pad="43"/>
<connect gate="A" pin="GPIO35" pad="44"/>
<connect gate="A" pin="GPIO36" pad="45"/>
<connect gate="A" pin="GPIO37" pad="46"/>
<connect gate="A" pin="GPIO38" pad="47"/>
<connect gate="A" pin="GPIO39" pad="48"/>
<connect gate="A" pin="GPIO4" pad="1"/>
<connect gate="A" pin="GPIO40_ADC0" pad="49"/>
<connect gate="A" pin="GPIO41_ADC1" pad="52"/>
<connect gate="A" pin="GPIO42_ADC2" pad="53"/>
<connect gate="A" pin="GPIO43_ADC3" pad="54"/>
<connect gate="A" pin="GPIO44_ADC4" pad="55"/>
<connect gate="A" pin="GPIO45_ADC5" pad="56"/>
<connect gate="A" pin="GPIO46_ADC6" pad="57"/>
<connect gate="A" pin="GPIO47_ADC7" pad="58"/>
<connect gate="A" pin="GPIO5" pad="2"/>
<connect gate="A" pin="GPIO6" pad="3"/>
<connect gate="A" pin="GPIO7" pad="4"/>
<connect gate="A" pin="GPIO8" pad="6"/>
<connect gate="A" pin="GPIO9" pad="7"/>
<connect gate="A" pin="IOVDD15" pad="15"/>
<connect gate="A" pin="IOVDD24" pad="24"/>
<connect gate="A" pin="IOVDD29" pad="29"/>
<connect gate="A" pin="IOVDD41" pad="41"/>
<connect gate="A" pin="IOVDD5" pad="5"/>
<connect gate="A" pin="IOVDD50" pad="50"/>
<connect gate="A" pin="IOVDD60" pad="60"/>
<connect gate="A" pin="IOVDD76" pad="76"/>
<connect gate="A" pin="QSPI_IOVDD" pad="69"/>
<connect gate="A" pin="QSPI_SCLK" pad="71"/>
<connect gate="A" pin="QSPI_SD0" pad="72"/>
<connect gate="A" pin="QSPI_SD1" pad="74"/>
<connect gate="A" pin="QSPI_SD2" pad="73"/>
<connect gate="A" pin="QSPI_SD3" pad="70"/>
<connect gate="A" pin="QSPI_SS" pad="75"/>
<connect gate="A" pin="SWCLK" pad="33"/>
<connect gate="A" pin="SWDIO" pad="34"/>
<connect gate="A" pin="USB_DM" pad="66"/>
<connect gate="A" pin="USB_DP" pad="67"/>
<connect gate="A" pin="USB_OTP_VDD" pad="68"/>
<connect gate="A" pin="VREG_AVDD" pad="61"/>
<connect gate="A" pin="VREG_FB" pad="65"/>
<connect gate="A" pin="VREG_LX" pad="63"/>
<connect gate="A" pin="VREG_PGND" pad="62"/>
<connect gate="A" pin="VREG_VIN" pad="64"/>
<connect gate="A" pin="XIN" pad="30"/>
<connect gate="A" pin="XOUT" pad="31"/>
</connects>
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
<library name="SYMBOLY">
<packages>
</packages>
<symbols>
<symbol name="GND">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<pin name="GND" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
<symbol name="+3,3V">
<text x="-0.508" y="-0.635" size="1.524" layer="94" rot="MR0">+3,3V</text>
<pin name="+3,3V" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="+5V">
<text x="-0.508" y="-0.635" size="1.524" layer="94" rot="MR0">+5V</text>
<pin name="+5V" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="+1,1V">
<text x="-0.508" y="-0.635" size="1.524" layer="94" rot="MR0">+1,1V</text>
<pin name="+1,1V" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="+12V">
<text x="-0.508" y="-0.635" size="1.524" layer="94" rot="MR0">+12V</text>
<pin name="+12V" x="2.54" y="0" visible="off" length="short" direction="sup" rot="R180"/>
</symbol>
<symbol name="PE">
<wire x1="-2.54" y1="0" x2="2.54" y2="0" width="0.6096" layer="94"/>
<wire x1="-1.27" y1="-1.27" x2="1.27" y2="-1.27" width="0.6096" layer="94"/>
<wire x1="-0.127" y1="-2.286" x2="0.127" y2="-2.286" width="0.6096" layer="94"/>
<pin name="PE" x="0" y="2.54" visible="off" length="short" direction="sup" rot="R270"/>
</symbol>
</symbols>
<devicesets>
<deviceset name="GND">
<gates>
<gate name="GND" symbol="GND" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+3,3V">
<gates>
<gate name="G$1" symbol="+3,3V" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+5V">
<gates>
<gate name="A" symbol="+5V" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+1,1V">
<gates>
<gate name="G$1" symbol="+1,1V" x="0" y="0" swaplevel="1"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="+12V">
<gates>
<gate name="A" symbol="+12V" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
<deviceset name="PE">
<gates>
<gate name="A" symbol="PE" x="0" y="0"/>
</gates>
<devices>
<device name="">
<technologies>
<technology name=""/>
</technologies>
</device>
</devices>
</deviceset>
</devicesets>
</library>
</libraries>
<attributes>
</attributes>
<variantdefs>
</variantdefs>
<classes>
<class number="0" name="default" width="0" drill="0">
</class>
</classes>
<parts>
<part name="XC1" library="CONNEC" deviceset="25-V2R40" device="-TOP" value="2x20"/>
<part name="IC3" library="IC" deviceset="74245" device="-PW" value="74HCT245PW"/>
<part name="IC4" library="IC" deviceset="74245" device="-PW" value="74HCT245PW"/>
<part name="IC7" library="74499" deviceset="742G125" device="-DP" value="74LVC2G125DCT"/>
<part name="IC6" library="74499" deviceset="74125" device="-DT" value="74HCT125PW"/>
<part name="IC5" library="74499" deviceset="74125" device="-DT" value="74HCT125PW"/>
<part name="IC8" library="IC" deviceset="LDL1117" device="" value="NCP1117ST33"/>
<part name="X1" library="PASIV" deviceset="XTAL-SMD" device="-3225" value="12MHz"/>
<part name="L1" library="PASIV" deviceset="TL-SMD" device="-2016" value="3,3uH"/>
<part name="USB" library="CONNEC" deviceset="USB-B" device="-B1" value="MX-67068-8000"/>
<part name="IC9" library="DISKRET" deviceset="USBLC6-2" device="SC6" value="USBLC6-2SC6"/>
<part name="PB1" library="KONSTR" deviceset="TL-SMD" device="-PTS647" value="BOOT"/>
<part name="IC2" library="MEMORY" deviceset="W25Q16" device="-SN" value="W25Q16JVSN"/>
<part name="IC1" library="INTEL" deviceset="RP2350" device="" value="RP2350B"/>
<part name="U$1" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R6" library="PASIV" deviceset="R-SMD" device="-0805" value="27R"/>
<part name="R7" library="PASIV" deviceset="R-SMD" device="-0805" value="27R"/>
<part name="U$2" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R14" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="R15" library="PASIV" deviceset="R-SMD" device="-0805" value="1k0"/>
<part name="U$3" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$4" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="R13" library="PASIV" deviceset="R-SMD" device="-0805" value="1k0"/>
<part name="C22" library="PASIV" deviceset="CK-SMD" device="-0805" value="15p"/>
<part name="C23" library="PASIV" deviceset="CK-SMD" device="-0805" value="15p"/>
<part name="U$5" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$6" library="SYMBOLY" deviceset="GND" device=""/>
<part name="C21" library="PASIV" deviceset="CK-SMD" device="-0603" value="4,7uF"/>
<part name="U$7" library="SYMBOLY" deviceset="GND" device=""/>
<part name="C17" library="PASIV" deviceset="CK-SMD" device="-0603" value="4,7uF"/>
<part name="C16" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C18" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="U$12" library="SYMBOLY" deviceset="GND" device=""/>
<part name="C19" library="PASIV" deviceset="CK-SMD" device="-0603" value="4,7uF"/>
<part name="U$13" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R12" library="PASIV" deviceset="R-SMD" device="-0805" value="33R"/>
<part name="U$14" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$15" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="C20" library="PASIV" deviceset="CK-SMD" device="-0603" value="4,7uF"/>
<part name="U$16" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$17" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$19" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R17" library="PASIV" deviceset="R-SMD" device="-1206" value="1M0"/>
<part name="U$20" library="SYMBOLY" deviceset="GND" device=""/>
<part name="C26" library="PASIV" deviceset="CK-SMD" device="-1206" value="4n7/1,5kV"/>
<part name="U$21" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$22" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$23" library="SYMBOLY" deviceset="GND" device=""/>
<part name="C24" library="PASIV" deviceset="CK-SMD" device="-1206" value="10uF/16V"/>
<part name="C25" library="PASIV" deviceset="CK-SMD" device="-1206" value="10uF/16V"/>
<part name="U$24" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="C1" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="U$25" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$26" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="C3" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C4" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C5" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C6" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C2" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="U$27" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$28" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$30" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$31" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$32" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$33" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$18" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$34" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$35" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$36" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$37" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$38" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$39" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$40" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$41" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$42" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R3" library="PASIV" deviceset="R-SMD" device="-0805" value="4k7"/>
<part name="R4" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="U$43" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$44" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R5" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="R8" library="PASIV" deviceset="R-SMD" device="-1206" value="680R"/>
<part name="U$51" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="R11" library="PASIV" deviceset="R-SMD" device="-1206" value="1k5"/>
<part name="R9" library="PASIV" deviceset="R-SMD" device="-1206" value="1k0"/>
<part name="U$53" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$54" library="SYMBOLY" deviceset="GND" device=""/>
<part name="JP1" library="KONSTR" deviceset="JMP2-1" device=""/>
<part name="JP2" library="KONSTR" deviceset="JMP2-1" device=""/>
<part name="U$55" library="SYMBOLY" deviceset="GND" device=""/>
<part name="D2" library="DISKRET" deviceset="LED-1206" device="" value="Red"/>
<part name="D4" library="DISKRET" deviceset="LED-1206" device="" value="Green"/>
<part name="D1" library="DISKRET" deviceset="LED-1206" device="" value="Yellow"/>
<part name="C7" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C8" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C9" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C10" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C11" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C12" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C13" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C14" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="C15" library="PASIV" deviceset="CK-SMD" device="-0603" value="100n"/>
<part name="U$56" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$57" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$8" library="SYMBOLY" deviceset="+1,1V" device=""/>
<part name="U$9" library="SYMBOLY" deviceset="+1,1V" device=""/>
<part name="U$10" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$11" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$45" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$46" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$47" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="R2" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="R1" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="U$48" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$49" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="PWR" library="CONNEC" deviceset="AMP174804" device="" value="AMP-174804-1"/>
<part name="+12V" library="KONSTR" deviceset="PAJ_B_16" device="" value="+12V"/>
<part name="GND1" library="KONSTR" deviceset="PAJ_B_16" device="" value="GND"/>
<part name="GND2" library="KONSTR" deviceset="PAJ_B_16" device="" value="GND"/>
<part name="+5V" library="KONSTR" deviceset="PAJ_B_16" device="" value="+5V"/>
<part name="U$50" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$58" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$59" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$29" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="U$60" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$61" library="SYMBOLY" deviceset="+12V" device=""/>
<part name="SW1" library="KONSTR" deviceset="SW-100DP1T2B" device="" value="100DP1T2B4M6QE"/>
<part name="U$62" library="SYMBOLY" deviceset="PE" device=""/>
<part name="U$63" library="SYMBOLY" deviceset="PE" device=""/>
<part name="D3" library="DISKRET" deviceset="LED-1206" device="" value="Green"/>
<part name="R10" library="PASIV" deviceset="R-SMD" device="-1206" value="470R"/>
<part name="U$64" library="SYMBOLY" deviceset="+5V" device=""/>
<part name="U$65" library="SYMBOLY" deviceset="GND" device=""/>
<part name="U$52" library="SYMBOLY" deviceset="+12V" device=""/>
<part name="RN6" library="PASIV" deviceset="R-NET4SB" device="" value="47R"/>
<part name="RN7" library="PASIV" deviceset="R-NET4SB" device="" value="47R"/>
<part name="RN8" library="PASIV" deviceset="R-NET4SB" device="" value="47R"/>
<part name="RN9" library="PASIV" deviceset="R-NET4SB" device="" value="47R"/>
<part name="RN1" library="PASIV" deviceset="R-NET4SB" device="" value="10k"/>
<part name="RN2" library="PASIV" deviceset="R-NET4SB" device="" value="10k"/>
<part name="RN3" library="PASIV" deviceset="R-NET4SB" device="" value="10k"/>
<part name="RN4" library="PASIV" deviceset="R-NET4SB" device="" value="10k"/>
<part name="PB2" library="KONSTR" deviceset="TL-SMD" device="-PTS647" value="RST"/>
<part name="U$66" library="SYMBOLY" deviceset="GND" device=""/>
<part name="R16" library="PASIV" deviceset="R-SMD" device="-0805" value="10k"/>
<part name="U$67" library="SYMBOLY" deviceset="+3,3V" device=""/>
<part name="D6" library="DISKRET" deviceset="600W-USM" device="" value="SMBJ15A"/>
<part name="D5" library="DISKRET" deviceset="600W-USM" device="" value="SMBJ6.0A"/>
<part name="RN5" library="PASIV" deviceset="R-NET4SB" device="" value="10k"/>
</parts>
<sheets>
<sheet>
<plain>
<circle x="290.83" y="118.11" radius="0.254" width="0.4064" layer="94"/>
<text x="312.42" y="81.28" size="1.27" layer="96">Winbond:
W25Q16JVSN
W25Q16JLSN

Renesas:
AT25FF161A-SS

ISSI:
IS25LP016D-JN</text>
<text x="278.13" y="69.85" size="1.27" layer="96">ABM8-272-T3</text>
<text x="287.02" y="114.3" size="1.27" layer="96">AOTA-B201610S3R3-101-T</text>
<text x="193.04" y="5.08" size="1.27" layer="96">Alternatively RP2354B
without external flash IC2</text>
</plain>
<instances>
<instance part="XC1" gate="A" x="8.89" y="144.78" rot="MR0"/>
<instance part="IC3" gate="A" x="102.87" y="123.19" smashed="yes" rot="MR0">
<attribute name="NAME" x="93.98" y="139.7" size="1.524" layer="95"/>
<attribute name="VALUE" x="93.98" y="105.41" size="1.524" layer="96"/>
</instance>
<instance part="IC4" gate="A" x="102.87" y="82.55" smashed="yes" rot="MR0">
<attribute name="NAME" x="93.98" y="99.06" size="1.524" layer="95"/>
<attribute name="VALUE" x="93.98" y="64.77" size="1.524" layer="96"/>
</instance>
<instance part="IC7" gate="A" x="50.8" y="35.56" rot="MR180"/>
<instance part="IC7" gate="B" x="50.8" y="11.43" rot="MR180"/>
<instance part="IC6" gate="C" x="149.86" y="-10.16" rot="R180"/>
<instance part="IC6" gate="B" x="97.79" y="-10.16" rot="R180"/>
<instance part="IC6" gate="A" x="149.86" y="-34.29" rot="R180"/>
<instance part="IC6" gate="D" x="97.79" y="-34.29" rot="R180"/>
<instance part="IC5" gate="B" x="149.86" y="35.56" rot="R180"/>
<instance part="IC5" gate="A" x="97.79" y="35.56" rot="R180"/>
<instance part="IC5" gate="D" x="149.86" y="11.43" rot="R180"/>
<instance part="IC5" gate="C" x="97.79" y="11.43" rot="R180"/>
<instance part="IC7" gate="P" x="55.88" y="173.99"/>
<instance part="IC6" gate="P" x="139.7" y="173.99"/>
<instance part="IC5" gate="P" x="127" y="173.99"/>
<instance part="IC3" gate="P" x="100.33" y="173.99"/>
<instance part="IC4" gate="P" x="114.3" y="173.99"/>
<instance part="IC8" gate="A" x="287.02" y="13.97" smashed="yes" rot="MR0">
<attribute name="NAME" x="281.94" y="21.59" size="1.524" layer="95"/>
<attribute name="VALUE" x="281.94" y="19.05" size="1.524" layer="96"/>
</instance>
<instance part="X1" gate="A" x="283.21" y="80.01" smashed="yes">
<attribute name="NAME" x="281.94" y="83.312" size="1.524" layer="95"/>
<attribute name="VALUE" x="280.67" y="74.93" size="1.524" layer="96"/>
</instance>
<instance part="L1" gate="A" x="284.48" y="116.84" smashed="yes">
<attribute name="NAME" x="283.464" y="120.65" size="1.524" layer="95"/>
<attribute name="VALUE" x="279.908" y="114.3" size="1.524" layer="96"/>
</instance>
<instance part="USB" gate="A" x="321.31" y="46.99" smashed="yes" rot="MR0">
<attribute name="NAME" x="321.31" y="50.8" size="1.524" layer="95"/>
<attribute name="VALUE" x="321.31" y="48.26" size="1.524" layer="96"/>
</instance>
<instance part="IC9" gate="A" x="299.72" y="39.37" smashed="yes" rot="MR0">
<attribute name="NAME" x="290.83" y="45.72" size="1.524" layer="95"/>
<attribute name="VALUE" x="290.83" y="31.75" size="1.524" layer="96"/>
</instance>
<instance part="PB1" gate="A" x="332.74" y="102.87" smashed="yes">
<attribute name="NAME" x="330.962" y="106.68" size="1.524" layer="95"/>
<attribute name="VALUE" x="330.2" y="100.076" size="1.524" layer="96"/>
</instance>
<instance part="IC2" gate="A" x="294.64" y="101.6"/>
<instance part="IC2" gate="P" x="68.58" y="173.99"/>
<instance part="IC1" gate="A" x="223.52" y="80.01"/>
<instance part="U$1" gate="GND" x="223.52" y="1.27"/>
<instance part="R6" gate="A" x="181.61" y="146.05" smashed="yes">
<attribute name="NAME" x="177.8" y="147.574" size="1.524" layer="95"/>
<attribute name="VALUE" x="182.88" y="147.574" size="1.524" layer="96"/>
</instance>
<instance part="R7" gate="A" x="181.61" y="143.51" smashed="yes">
<attribute name="NAME" x="177.8" y="140.462" size="1.524" layer="95"/>
<attribute name="VALUE" x="182.88" y="140.462" size="1.524" layer="96"/>
</instance>
<instance part="U$2" gate="GND" x="261.62" y="114.3"/>
<instance part="R14" gate="A" x="320.04" y="113.03"/>
<instance part="R15" gate="A" x="320.04" y="102.87"/>
<instance part="U$3" gate="GND" x="340.36" y="99.06"/>
<instance part="U$4" gate="G$1" x="328.93" y="113.03" rot="R180"/>
<instance part="R13" gate="A" x="266.7" y="80.01"/>
<instance part="C22" gate="A" x="275.59" y="73.66" smashed="yes" rot="R90">
<attribute name="NAME" x="271.78" y="75.946" size="1.524" layer="95"/>
<attribute name="VALUE" x="271.78" y="69.85" size="1.524" layer="96"/>
</instance>
<instance part="C23" gate="A" x="292.1" y="73.66" smashed="yes" rot="R90">
<attribute name="NAME" x="293.37" y="75.946" size="1.524" layer="95"/>
<attribute name="VALUE" x="293.37" y="69.85" size="1.524" layer="96"/>
</instance>
<instance part="U$5" gate="GND" x="275.59" y="64.77"/>
<instance part="U$6" gate="GND" x="292.1" y="64.77"/>
<instance part="C21" gate="A" x="314.96" y="128.27" smashed="yes" rot="R270">
<attribute name="NAME" x="316.23" y="130.556" size="1.524" layer="95"/>
<attribute name="VALUE" x="316.23" y="124.46" size="1.524" layer="96"/>
</instance>
<instance part="U$7" gate="GND" x="314.96" y="119.38"/>
<instance part="C17" gate="A" x="271.78" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="267.97" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="265.43" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C16" gate="A" x="264.16" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="260.35" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="259.08" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C18" gate="A" x="279.4" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="275.59" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="274.32" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="U$12" gate="GND" x="283.21" y="158.75"/>
<instance part="C19" gate="A" x="275.59" y="144.78" smashed="yes" rot="R180">
<attribute name="NAME" x="269.24" y="145.796" size="1.524" layer="95"/>
<attribute name="VALUE" x="269.24" y="142.24" size="1.524" layer="96"/>
</instance>
<instance part="U$13" gate="GND" x="283.21" y="140.97"/>
<instance part="R12" gate="A" x="275.59" y="152.4"/>
<instance part="U$14" gate="G$1" x="284.48" y="152.4" rot="R180"/>
<instance part="U$15" gate="G$1" x="284.48" y="135.89" rot="R180"/>
<instance part="C20" gate="A" x="275.59" y="129.54" smashed="yes" rot="R180">
<attribute name="NAME" x="269.24" y="130.556" size="1.524" layer="95"/>
<attribute name="VALUE" x="269.24" y="127" size="1.524" layer="96"/>
</instance>
<instance part="U$16" gate="GND" x="283.21" y="125.73"/>
<instance part="U$17" gate="GND" x="326.39" y="15.24"/>
<instance part="U$19" gate="GND" x="314.96" y="31.75"/>
<instance part="R17" gate="A" x="334.01" y="24.13" smashed="yes" rot="R90">
<attribute name="NAME" x="332.486" y="21.59" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="337.058" y="21.59" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="U$20" gate="GND" x="334.01" y="15.24"/>
<instance part="C26" gate="A" x="326.39" y="24.13" smashed="yes" rot="R90">
<attribute name="NAME" x="322.58" y="26.416" size="1.524" layer="95"/>
<attribute name="VALUE" x="316.23" y="20.32" size="1.524" layer="96"/>
</instance>
<instance part="U$21" gate="GND" x="276.86" y="0"/>
<instance part="U$22" gate="GND" x="297.18" y="0"/>
<instance part="U$23" gate="GND" x="287.02" y="0"/>
<instance part="C24" gate="A" x="276.86" y="8.89" smashed="yes" rot="R90">
<attribute name="NAME" x="273.05" y="11.176" size="1.524" layer="95"/>
<attribute name="VALUE" x="266.7" y="5.08" size="1.524" layer="96"/>
</instance>
<instance part="C25" gate="A" x="297.18" y="8.89" smashed="yes" rot="R90">
<attribute name="NAME" x="298.45" y="11.176" size="1.524" layer="95"/>
<attribute name="VALUE" x="298.45" y="5.08" size="1.524" layer="96"/>
</instance>
<instance part="U$24" gate="G$1" x="273.05" y="15.24"/>
<instance part="C1" gate="A" x="50.8" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="46.99" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="45.72" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="U$25" gate="GND" x="46.99" y="158.75"/>
<instance part="U$26" gate="G$1" x="44.45" y="185.42"/>
<instance part="C3" gate="A" x="95.25" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="91.44" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="90.17" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C4" gate="A" x="107.95" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="104.14" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="102.87" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C5" gate="A" x="121.92" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="118.11" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="116.84" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C6" gate="A" x="134.62" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="130.81" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="129.54" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C2" gate="A" x="63.5" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="59.69" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="58.42" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="U$27" gate="GND" x="91.44" y="158.75"/>
<instance part="U$28" gate="A" x="88.9" y="185.42"/>
<instance part="U$30" gate="GND" x="16.51" y="39.37"/>
<instance part="U$31" gate="A" x="21.59" y="71.12" rot="R180"/>
<instance part="U$32" gate="A" x="64.77" y="147.32"/>
<instance part="U$33" gate="A" x="64.77" y="106.68"/>
<instance part="U$18" gate="GND" x="50.8" y="26.67"/>
<instance part="U$34" gate="GND" x="50.8" y="2.54"/>
<instance part="U$35" gate="GND" x="97.79" y="26.67"/>
<instance part="U$36" gate="GND" x="149.86" y="26.67"/>
<instance part="U$37" gate="GND" x="97.79" y="2.54"/>
<instance part="U$38" gate="GND" x="149.86" y="2.54"/>
<instance part="U$39" gate="GND" x="149.86" y="-19.05"/>
<instance part="U$40" gate="GND" x="97.79" y="-19.05"/>
<instance part="U$41" gate="GND" x="97.79" y="-43.18"/>
<instance part="U$42" gate="GND" x="149.86" y="-43.18"/>
<instance part="R3" gate="A" x="40.64" y="43.18" rot="R90"/>
<instance part="R4" gate="A" x="40.64" y="3.81" rot="R90"/>
<instance part="U$43" gate="A" x="40.64" y="50.8" rot="R270"/>
<instance part="U$44" gate="GND" x="40.64" y="-5.08"/>
<instance part="R5" gate="A" x="107.95" y="-26.67" rot="R90"/>
<instance part="R8" gate="A" x="157.48" y="-52.07"/>
<instance part="U$51" gate="A" x="166.37" y="-52.07" rot="R180"/>
<instance part="R11" gate="A" x="212.09" y="-38.1"/>
<instance part="R9" gate="A" x="189.23" y="-24.13"/>
<instance part="U$53" gate="GND" x="190.5" y="-41.91"/>
<instance part="U$54" gate="GND" x="210.82" y="-27.94"/>
<instance part="JP1" gate="A" x="196.85" y="-3.81" smashed="yes">
<attribute name="NAME" x="195.199" y="-1.905" size="1.524" layer="95"/>
<attribute name="VALUE" x="196.215" y="-6.985" size="1.524" layer="96"/>
</instance>
<instance part="JP2" gate="A" x="196.85" y="-11.43" smashed="yes">
<attribute name="NAME" x="195.199" y="-9.525" size="1.524" layer="95"/>
<attribute name="VALUE" x="196.215" y="-14.605" size="1.524" layer="96"/>
</instance>
<instance part="U$55" gate="GND" x="210.82" y="-15.24"/>
<instance part="D2" gate="A" x="200.66" y="-24.13" smashed="yes" rot="MR0">
<attribute name="NAME" x="195.58" y="-22.86" size="1.524" layer="95"/>
<attribute name="VALUE" x="194.818" y="-26.416" size="1.524" layer="96"/>
</instance>
<instance part="D4" gate="A" x="200.66" y="-38.1" smashed="yes">
<attribute name="NAME" x="195.58" y="-36.83" size="1.524" layer="95"/>
<attribute name="VALUE" x="193.04" y="-40.386" size="1.524" layer="96"/>
</instance>
<instance part="D1" gate="A" x="146.05" y="-52.07" smashed="yes">
<attribute name="NAME" x="140.97" y="-50.8" size="1.524" layer="95"/>
<attribute name="VALUE" x="137.922" y="-54.61" size="1.524" layer="96"/>
</instance>
<instance part="C7" gate="A" x="165.1" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="161.29" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="160.02" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C8" gate="A" x="172.72" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="168.91" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="167.64" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C9" gate="A" x="180.34" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="176.53" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="175.26" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C10" gate="A" x="187.96" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="184.15" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="182.88" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C11" gate="A" x="195.58" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="191.77" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="190.5" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C12" gate="A" x="203.2" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="199.39" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="198.12" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C13" gate="A" x="210.82" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="207.01" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="205.74" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C14" gate="A" x="218.44" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="214.63" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="213.36" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="C15" gate="A" x="226.06" y="173.99" smashed="yes" rot="R90">
<attribute name="NAME" x="222.25" y="176.276" size="1.524" layer="95"/>
<attribute name="VALUE" x="220.98" y="170.18" size="1.524" layer="96"/>
</instance>
<instance part="U$56" gate="GND" x="161.29" y="158.75"/>
<instance part="U$57" gate="G$1" x="158.75" y="185.42"/>
<instance part="U$8" gate="G$1" x="320.04" y="135.89" rot="R180"/>
<instance part="U$9" gate="G$1" x="285.75" y="185.42" rot="R180"/>
<instance part="U$10" gate="G$1" x="107.95" y="50.8" rot="R270"/>
<instance part="U$11" gate="G$1" x="107.95" y="26.67" rot="R270"/>
<instance part="U$45" gate="G$1" x="160.02" y="50.8" rot="R270"/>
<instance part="U$46" gate="G$1" x="160.02" y="26.67" rot="R270"/>
<instance part="U$47" gate="G$1" x="107.95" y="-19.05" rot="R270"/>
<instance part="R2" gate="A" x="127" y="100.33"/>
<instance part="R1" gate="A" x="127" y="140.97"/>
<instance part="U$48" gate="G$1" x="134.62" y="100.33" rot="R180"/>
<instance part="U$49" gate="G$1" x="134.62" y="140.97" rot="R180"/>
<instance part="PWR" gate="A" x="323.85" y="-29.21"/>
<instance part="+12V" gate="A" x="254" y="-22.86" smashed="yes" rot="MR0">
<attribute name="NAME" x="246.888" y="-23.368" size="1.524" layer="95"/>
</instance>
<instance part="GND2" gate="A" x="254" y="-33.02" smashed="yes" rot="MR0">
<attribute name="NAME" x="246.888" y="-33.528" size="1.524" layer="95"/>
</instance>
<instance part="GND1" gate="A" x="254" y="-38.1" smashed="yes" rot="MR0">
<attribute name="NAME" x="246.888" y="-38.608" size="1.524" layer="95"/>
</instance>
<instance part="+5V" gate="A" x="254" y="-48.26" smashed="yes" rot="MR0">
<attribute name="NAME" x="248.158" y="-48.768" size="1.524" layer="95"/>
</instance>
<instance part="U$50" gate="GND" x="313.69" y="-38.1"/>
<instance part="U$58" gate="GND" x="273.05" y="-38.1"/>
<instance part="U$59" gate="A" x="281.94" y="-40.64"/>
<instance part="U$29" gate="G$1" x="280.67" y="36.83"/>
<instance part="U$60" gate="A" x="302.26" y="15.24" rot="R180"/>
<instance part="U$61" gate="A" x="281.94" y="-30.48"/>
<instance part="SW1" gate="A" x="299.72" y="-35.56" smashed="yes">
<attribute name="NAME" x="295.91" y="-22.86" size="1.524" layer="95"/>
<attribute name="VALUE" x="290.83" y="-25.4" size="1.524" layer="96"/>
</instance>
<instance part="U$62" gate="A" x="342.9" y="15.24"/>
<instance part="U$63" gate="A" x="292.1" y="-48.26"/>
<instance part="D3" gate="A" x="200.66" y="-49.53" smashed="yes">
<attribute name="NAME" x="195.58" y="-48.26" size="1.524" layer="95"/>
<attribute name="VALUE" x="193.04" y="-51.816" size="1.524" layer="96"/>
</instance>
<instance part="R10" gate="A" x="212.09" y="-49.53"/>
<instance part="U$64" gate="A" x="220.98" y="-49.53" rot="R180"/>
<instance part="U$65" gate="GND" x="190.5" y="-53.34"/>
<instance part="U$52" gate="A" x="220.98" y="-38.1" rot="R180"/>
<instance part="RN6" gate="A" x="127" y="120.65" smashed="yes">
<attribute name="NAME" x="118.11" y="120.904" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="120.904" size="1.524" layer="96"/>
</instance>
<instance part="RN6" gate="B" x="127" y="123.19" smashed="yes">
<attribute name="NAME" x="118.11" y="123.444" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="123.444" size="1.524" layer="96"/>
</instance>
<instance part="RN6" gate="C" x="127" y="125.73" smashed="yes">
<attribute name="NAME" x="118.11" y="125.984" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="125.984" size="1.524" layer="96"/>
</instance>
<instance part="RN6" gate="D" x="127" y="128.27" smashed="yes">
<attribute name="NAME" x="118.11" y="128.524" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="128.524" size="1.524" layer="96"/>
</instance>
<instance part="RN7" gate="A" x="127" y="110.49" smashed="yes">
<attribute name="NAME" x="118.11" y="110.744" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="110.744" size="1.524" layer="96"/>
</instance>
<instance part="RN7" gate="B" x="127" y="113.03" smashed="yes">
<attribute name="NAME" x="118.11" y="113.284" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="113.284" size="1.524" layer="96"/>
</instance>
<instance part="RN7" gate="C" x="127" y="115.57" smashed="yes">
<attribute name="NAME" x="118.11" y="115.824" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="115.824" size="1.524" layer="96"/>
</instance>
<instance part="RN7" gate="D" x="127" y="118.11" smashed="yes">
<attribute name="NAME" x="118.11" y="118.364" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="118.364" size="1.524" layer="96"/>
</instance>
<instance part="RN8" gate="A" x="127" y="80.01" smashed="yes">
<attribute name="NAME" x="118.11" y="80.264" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="80.264" size="1.524" layer="96"/>
</instance>
<instance part="RN8" gate="B" x="127" y="82.55" smashed="yes">
<attribute name="NAME" x="118.11" y="82.804" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="82.804" size="1.524" layer="96"/>
</instance>
<instance part="RN8" gate="C" x="127" y="85.09" smashed="yes">
<attribute name="NAME" x="118.11" y="85.344" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="85.344" size="1.524" layer="96"/>
</instance>
<instance part="RN8" gate="D" x="127" y="87.63" smashed="yes">
<attribute name="NAME" x="118.11" y="87.884" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="87.884" size="1.524" layer="96"/>
</instance>
<instance part="RN9" gate="A" x="127" y="69.85" smashed="yes">
<attribute name="NAME" x="118.11" y="70.104" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="70.104" size="1.524" layer="96"/>
</instance>
<instance part="RN9" gate="B" x="127" y="72.39" smashed="yes">
<attribute name="NAME" x="118.11" y="72.644" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="72.644" size="1.524" layer="96"/>
</instance>
<instance part="RN9" gate="C" x="127" y="74.93" smashed="yes">
<attribute name="NAME" x="118.11" y="75.184" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="75.184" size="1.524" layer="96"/>
</instance>
<instance part="RN9" gate="D" x="127" y="77.47" smashed="yes">
<attribute name="NAME" x="118.11" y="77.724" size="1.524" layer="95"/>
<attribute name="VALUE" x="130.81" y="77.724" size="1.524" layer="96"/>
</instance>
<instance part="RN1" gate="A" x="68.58" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="68.326" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="68.326" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN1" gate="B" x="71.12" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="70.866" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="70.866" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN1" gate="C" x="73.66" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="73.406" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="73.406" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN1" gate="D" x="76.2" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="75.946" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="75.946" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN2" gate="A" x="78.74" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="78.486" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="78.486" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN2" gate="B" x="81.28" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="81.026" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="81.026" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN2" gate="C" x="83.82" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="83.566" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="83.566" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN2" gate="D" x="86.36" y="138.43" smashed="yes" rot="R90">
<attribute name="NAME" x="86.106" y="129.54" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="86.106" y="142.24" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN3" gate="A" x="68.58" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="68.326" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="68.326" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN3" gate="B" x="71.12" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="70.866" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="70.866" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN3" gate="C" x="73.66" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="73.406" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="73.406" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN3" gate="D" x="76.2" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="75.946" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="75.946" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN4" gate="A" x="78.74" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="78.486" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="78.486" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN4" gate="B" x="81.28" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="81.026" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="81.026" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN4" gate="C" x="83.82" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="83.566" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="83.566" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="RN4" gate="D" x="86.36" y="97.79" smashed="yes" rot="R90">
<attribute name="NAME" x="86.106" y="88.9" size="1.524" layer="95" rot="R90"/>
<attribute name="VALUE" x="86.106" y="101.6" size="1.524" layer="96" rot="R90"/>
</instance>
<instance part="PB2" gate="A" x="316.23" y="62.23" smashed="yes">
<attribute name="NAME" x="314.706" y="66.04" size="1.524" layer="95"/>
<attribute name="VALUE" x="314.452" y="59.69" size="1.524" layer="96"/>
</instance>
<instance part="U$66" gate="GND" x="323.85" y="58.42"/>
<instance part="R16" gate="A" x="314.96" y="73.66" smashed="yes">
<attribute name="NAME" x="313.69" y="75.184" size="1.524" layer="95"/>
<attribute name="VALUE" x="313.69" y="70.612" size="1.524" layer="96"/>
</instance>
<instance part="U$67" gate="G$1" x="323.85" y="73.66" rot="R180"/>
<instance part="D6" gate="A" x="266.7" y="-29.21" smashed="yes" rot="R90">
<attribute name="NAME" x="260.35" y="-27.94" size="1.524" layer="95"/>
<attribute name="VALUE" x="255.27" y="-30.48" size="1.524" layer="96"/>
</instance>
<instance part="D5" gate="A" x="266.7" y="-41.91" smashed="yes" rot="R270">
<attribute name="NAME" x="260.35" y="-41.91" size="1.524" layer="95"/>
<attribute name="VALUE" x="254" y="-44.45" size="1.524" layer="96"/>
</instance>
<instance part="RN5" gate="A" x="160.02" y="43.18" rot="R90"/>
<instance part="RN5" gate="B" x="107.95" y="43.18" rot="R90"/>
<instance part="RN5" gate="C" x="160.02" y="19.05" rot="R90"/>
<instance part="RN5" gate="D" x="107.95" y="19.05" rot="R90"/>
</instances>
<busses>
<bus name="BUS1:D0,D1,D2,D3,D4,D5,D6,D7,D8,D9,D10,D11,D12,D13,D14,D15,D_DIR0,D_DIR1,!D_OE0,!D_OE1">
<segment>
<wire x1="172.72" y1="88.9" x2="172.72" y2="138.43" width="0.762" layer="92"/>
<wire x1="172.72" y1="138.43" x2="146.05" y2="138.43" width="0.762" layer="92"/>
<wire x1="146.05" y1="138.43" x2="146.05" y2="71.12" width="0.762" layer="92"/>
</segment>
</bus>
<bus name="BUS2:DD0,DD1,DD2,DD3,DD4,DD5,DD6,DD7,DD8,DD9,DD10,DD11,DD12,DD13,DD14,DD15">
<segment>
<wire x1="57.15" y1="71.12" x2="57.15" y2="139.7" width="0.762" layer="92"/>
<wire x1="57.15" y1="139.7" x2="30.48" y2="139.7" width="0.762" layer="92"/>
<wire x1="30.48" y1="139.7" x2="30.48" y2="100.33" width="0.762" layer="92"/>
</segment>
</bus>
<bus name="BUS3:!DIOW,!DIOR,!IORDY,INTRQ,DA1,DA0,DA2,!IDE_CS0,!IDE_CS1,!ACTIVE">
<segment>
<wire x1="30.48" y1="87.63" x2="30.48" y2="-52.07" width="0.762" layer="92"/>
<wire x1="30.48" y1="-52.07" x2="77.47" y2="-52.07" width="0.762" layer="92"/>
<wire x1="77.47" y1="-52.07" x2="129.54" y2="-52.07" width="0.762" layer="92"/>
<wire x1="129.54" y1="-52.07" x2="129.54" y2="36.83" width="0.762" layer="92"/>
<wire x1="77.47" y1="-52.07" x2="77.47" y2="36.83" width="0.762" layer="92"/>
</segment>
</bus>
<bus name="BUS4:A0,A1,A2,!M_RESET,!M_CS0,!M_CS1,!M_DIOR,!M_DIOW,M_INTRQ,!M_IORDY,OPT1_JMP,OPT2_JMP,!ERR_LED">
<segment>
<wire x1="172.72" y1="86.36" x2="172.72" y2="59.69" width="0.762" layer="92"/>
<wire x1="69.85" y1="12.7" x2="69.85" y2="59.69" width="0.762" layer="92"/>
<wire x1="69.85" y1="59.69" x2="121.92" y2="59.69" width="0.762" layer="92"/>
<wire x1="121.92" y1="59.69" x2="172.72" y2="59.69" width="0.762" layer="92"/>
<wire x1="121.92" y1="-33.02" x2="121.92" y2="59.69" width="0.762" layer="92"/>
<wire x1="172.72" y1="-33.02" x2="172.72" y2="59.69" width="0.762" layer="92"/>
</segment>
</bus>
</busses>
<nets>
<net name="D0" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO0"/>
<wire x1="172.72" y1="137.16" x2="173.99" y2="135.89" width="0.1524" layer="91"/>
<wire x1="173.99" y1="135.89" x2="187.96" y2="135.89" width="0.1524" layer="91"/>
<label x="175.26" y="136.398" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="129.54" x2="144.78" y2="128.27" width="0.1524" layer="91"/>
<wire x1="144.78" y1="128.27" x2="132.08" y2="128.27" width="0.1524" layer="91"/>
<label x="143.51" y="128.778" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN6" gate="D" pin="2"/>
</segment>
</net>
<net name="D1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO1"/>
<wire x1="172.72" y1="134.62" x2="173.99" y2="133.35" width="0.1524" layer="91"/>
<wire x1="173.99" y1="133.35" x2="187.96" y2="133.35" width="0.1524" layer="91"/>
<label x="175.26" y="133.858" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="127" x2="144.78" y2="125.73" width="0.1524" layer="91"/>
<wire x1="144.78" y1="125.73" x2="132.08" y2="125.73" width="0.1524" layer="91"/>
<label x="143.51" y="126.238" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN6" gate="C" pin="2"/>
</segment>
</net>
<net name="D2" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO2"/>
<wire x1="172.72" y1="132.08" x2="173.99" y2="130.81" width="0.1524" layer="91"/>
<wire x1="173.99" y1="130.81" x2="187.96" y2="130.81" width="0.1524" layer="91"/>
<label x="175.26" y="131.318" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="124.46" x2="144.78" y2="123.19" width="0.1524" layer="91"/>
<wire x1="144.78" y1="123.19" x2="132.08" y2="123.19" width="0.1524" layer="91"/>
<label x="143.51" y="123.698" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN6" gate="B" pin="2"/>
</segment>
</net>
<net name="D3" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO3"/>
<wire x1="172.72" y1="129.54" x2="173.99" y2="128.27" width="0.1524" layer="91"/>
<wire x1="173.99" y1="128.27" x2="187.96" y2="128.27" width="0.1524" layer="91"/>
<label x="175.26" y="128.778" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="121.92" x2="144.78" y2="120.65" width="0.1524" layer="91"/>
<wire x1="144.78" y1="120.65" x2="132.08" y2="120.65" width="0.1524" layer="91"/>
<label x="143.51" y="121.158" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN6" gate="A" pin="2"/>
</segment>
</net>
<net name="D4" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO4"/>
<wire x1="172.72" y1="127" x2="173.99" y2="125.73" width="0.1524" layer="91"/>
<wire x1="173.99" y1="125.73" x2="187.96" y2="125.73" width="0.1524" layer="91"/>
<label x="175.26" y="126.238" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="119.38" x2="144.78" y2="118.11" width="0.1524" layer="91"/>
<wire x1="144.78" y1="118.11" x2="132.08" y2="118.11" width="0.1524" layer="91"/>
<label x="143.51" y="118.618" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN7" gate="D" pin="2"/>
</segment>
</net>
<net name="D5" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO5"/>
<wire x1="172.72" y1="124.46" x2="173.99" y2="123.19" width="0.1524" layer="91"/>
<wire x1="173.99" y1="123.19" x2="187.96" y2="123.19" width="0.1524" layer="91"/>
<label x="175.26" y="123.698" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="116.84" x2="144.78" y2="115.57" width="0.1524" layer="91"/>
<wire x1="144.78" y1="115.57" x2="132.08" y2="115.57" width="0.1524" layer="91"/>
<label x="143.51" y="116.078" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN7" gate="C" pin="2"/>
</segment>
</net>
<net name="D6" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO6"/>
<wire x1="172.72" y1="121.92" x2="173.99" y2="120.65" width="0.1524" layer="91"/>
<wire x1="173.99" y1="120.65" x2="187.96" y2="120.65" width="0.1524" layer="91"/>
<label x="175.26" y="121.158" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="114.3" x2="144.78" y2="113.03" width="0.1524" layer="91"/>
<wire x1="144.78" y1="113.03" x2="132.08" y2="113.03" width="0.1524" layer="91"/>
<label x="143.51" y="113.538" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN7" gate="B" pin="2"/>
</segment>
</net>
<net name="D7" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO7"/>
<wire x1="172.72" y1="119.38" x2="173.99" y2="118.11" width="0.1524" layer="91"/>
<wire x1="173.99" y1="118.11" x2="187.96" y2="118.11" width="0.1524" layer="91"/>
<label x="175.26" y="118.618" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="146.05" y1="111.76" x2="144.78" y2="110.49" width="0.1524" layer="91"/>
<wire x1="144.78" y1="110.49" x2="132.08" y2="110.49" width="0.1524" layer="91"/>
<label x="143.51" y="110.998" size="1.524" layer="95" rot="MR0"/>
<pinref part="RN7" gate="A" pin="2"/>
</segment>
</net>
<net name="D8" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO8"/>
<wire x1="172.72" y1="116.84" x2="173.99" y2="115.57" width="0.1524" layer="91"/>
<wire x1="173.99" y1="115.57" x2="187.96" y2="115.57" width="0.1524" layer="91"/>
<label x="175.26" y="116.078" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="69.85" x2="132.08" y2="69.85" width="0.1524" layer="91"/>
<label x="143.51" y="70.358" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="71.12" x2="144.78" y2="69.85" width="0.1524" layer="91"/>
<pinref part="RN9" gate="A" pin="2"/>
</segment>
</net>
<net name="D9" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO9"/>
<wire x1="172.72" y1="114.3" x2="173.99" y2="113.03" width="0.1524" layer="91"/>
<wire x1="173.99" y1="113.03" x2="187.96" y2="113.03" width="0.1524" layer="91"/>
<label x="175.26" y="113.538" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="72.39" x2="132.08" y2="72.39" width="0.1524" layer="91"/>
<label x="143.51" y="72.898" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="73.66" x2="144.78" y2="72.39" width="0.1524" layer="91"/>
<pinref part="RN9" gate="B" pin="2"/>
</segment>
</net>
<net name="D10" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO10"/>
<wire x1="172.72" y1="111.76" x2="173.99" y2="110.49" width="0.1524" layer="91"/>
<wire x1="173.99" y1="110.49" x2="187.96" y2="110.49" width="0.1524" layer="91"/>
<label x="175.26" y="110.998" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="74.93" x2="132.08" y2="74.93" width="0.1524" layer="91"/>
<label x="143.51" y="75.438" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="76.2" x2="144.78" y2="74.93" width="0.1524" layer="91"/>
<pinref part="RN9" gate="C" pin="2"/>
</segment>
</net>
<net name="D11" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO11"/>
<wire x1="172.72" y1="109.22" x2="173.99" y2="107.95" width="0.1524" layer="91"/>
<wire x1="173.99" y1="107.95" x2="187.96" y2="107.95" width="0.1524" layer="91"/>
<label x="175.26" y="108.458" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="77.47" x2="132.08" y2="77.47" width="0.1524" layer="91"/>
<label x="143.51" y="77.978" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="78.74" x2="144.78" y2="77.47" width="0.1524" layer="91"/>
<pinref part="RN9" gate="D" pin="2"/>
</segment>
</net>
<net name="D12" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO12"/>
<wire x1="172.72" y1="106.68" x2="173.99" y2="105.41" width="0.1524" layer="91"/>
<wire x1="173.99" y1="105.41" x2="187.96" y2="105.41" width="0.1524" layer="91"/>
<label x="175.26" y="105.918" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="80.01" x2="132.08" y2="80.01" width="0.1524" layer="91"/>
<label x="143.51" y="80.518" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="81.28" x2="144.78" y2="80.01" width="0.1524" layer="91"/>
<pinref part="RN8" gate="A" pin="2"/>
</segment>
</net>
<net name="D13" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO13"/>
<wire x1="172.72" y1="104.14" x2="173.99" y2="102.87" width="0.1524" layer="91"/>
<wire x1="173.99" y1="102.87" x2="187.96" y2="102.87" width="0.1524" layer="91"/>
<label x="175.26" y="103.378" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="82.55" x2="132.08" y2="82.55" width="0.1524" layer="91"/>
<label x="143.51" y="83.058" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="83.82" x2="144.78" y2="82.55" width="0.1524" layer="91"/>
<pinref part="RN8" gate="B" pin="2"/>
</segment>
</net>
<net name="D14" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO14"/>
<wire x1="172.72" y1="101.6" x2="173.99" y2="100.33" width="0.1524" layer="91"/>
<wire x1="173.99" y1="100.33" x2="187.96" y2="100.33" width="0.1524" layer="91"/>
<label x="175.26" y="100.838" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="85.09" x2="132.08" y2="85.09" width="0.1524" layer="91"/>
<label x="143.51" y="85.598" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="86.36" x2="144.78" y2="85.09" width="0.1524" layer="91"/>
<pinref part="RN8" gate="C" pin="2"/>
</segment>
</net>
<net name="D15" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO15"/>
<wire x1="172.72" y1="99.06" x2="173.99" y2="97.79" width="0.1524" layer="91"/>
<wire x1="173.99" y1="97.79" x2="187.96" y2="97.79" width="0.1524" layer="91"/>
<label x="175.26" y="98.298" size="1.524" layer="95"/>
</segment>
<segment>
<wire x1="144.78" y1="87.63" x2="132.08" y2="87.63" width="0.1524" layer="91"/>
<label x="143.51" y="88.138" size="1.524" layer="95" rot="MR0"/>
<wire x1="146.05" y1="88.9" x2="144.78" y2="87.63" width="0.1524" layer="91"/>
<pinref part="RN8" gate="D" pin="2"/>
</segment>
</net>
<net name="D_DIR0" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO16"/>
<wire x1="172.72" y1="96.52" x2="173.99" y2="95.25" width="0.1524" layer="91"/>
<wire x1="173.99" y1="95.25" x2="187.96" y2="95.25" width="0.1524" layer="91"/>
<label x="175.26" y="95.758" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="DIR"/>
<wire x1="146.05" y1="134.62" x2="144.78" y2="133.35" width="0.1524" layer="91"/>
<wire x1="144.78" y1="133.35" x2="116.84" y2="133.35" width="0.1524" layer="91"/>
<label x="143.51" y="133.858" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="D_DIR1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO17"/>
<wire x1="172.72" y1="93.98" x2="173.99" y2="92.71" width="0.1524" layer="91"/>
<wire x1="173.99" y1="92.71" x2="187.96" y2="92.71" width="0.1524" layer="91"/>
<label x="175.26" y="93.218" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="DIR"/>
<wire x1="146.05" y1="93.98" x2="144.78" y2="92.71" width="0.1524" layer="91"/>
<wire x1="144.78" y1="92.71" x2="116.84" y2="92.71" width="0.1524" layer="91"/>
<label x="143.51" y="93.218" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="!D_OE0" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO18"/>
<wire x1="172.72" y1="91.44" x2="173.99" y2="90.17" width="0.1524" layer="91"/>
<wire x1="173.99" y1="90.17" x2="187.96" y2="90.17" width="0.1524" layer="91"/>
<label x="175.26" y="90.678" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="IC3" gate="A" pin="!OE"/>
<wire x1="146.05" y1="137.16" x2="144.78" y2="135.89" width="0.1524" layer="91"/>
<wire x1="144.78" y1="135.89" x2="120.65" y2="135.89" width="0.1524" layer="91"/>
<label x="143.51" y="136.398" size="1.524" layer="95" rot="MR0"/>
<pinref part="R1" gate="A" pin="1"/>
<wire x1="120.65" y1="135.89" x2="116.84" y2="135.89" width="0.1524" layer="91"/>
<wire x1="121.92" y1="140.97" x2="120.65" y2="140.97" width="0.1524" layer="91"/>
<wire x1="120.65" y1="140.97" x2="120.65" y2="135.89" width="0.1524" layer="91"/>
<junction x="120.65" y="135.89"/>
</segment>
</net>
<net name="!D_OE1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO19"/>
<wire x1="172.72" y1="88.9" x2="173.99" y2="87.63" width="0.1524" layer="91"/>
<wire x1="173.99" y1="87.63" x2="187.96" y2="87.63" width="0.1524" layer="91"/>
<label x="175.26" y="88.138" size="1.524" layer="95"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="!OE"/>
<wire x1="146.05" y1="96.52" x2="144.78" y2="95.25" width="0.1524" layer="91"/>
<wire x1="144.78" y1="95.25" x2="120.65" y2="95.25" width="0.1524" layer="91"/>
<label x="143.51" y="95.758" size="1.524" layer="95" rot="MR0"/>
<pinref part="R2" gate="A" pin="1"/>
<wire x1="120.65" y1="95.25" x2="116.84" y2="95.25" width="0.1524" layer="91"/>
<wire x1="121.92" y1="100.33" x2="120.65" y2="100.33" width="0.1524" layer="91"/>
<wire x1="120.65" y1="100.33" x2="120.65" y2="95.25" width="0.1524" layer="91"/>
<junction x="120.65" y="95.25"/>
</segment>
</net>
<net name="!ERR_LED" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO32"/>
<wire x1="187.96" y1="54.61" x2="173.99" y2="54.61" width="0.1524" layer="91"/>
<label x="175.26" y="55.118" size="1.524" layer="95"/>
<wire x1="173.99" y1="54.61" x2="172.72" y2="55.88" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="172.72" y1="-22.86" x2="173.99" y2="-24.13" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-24.13" x2="184.15" y2="-24.13" width="0.1524" layer="91"/>
<label x="175.26" y="-23.622" size="1.524" layer="95"/>
<pinref part="R9" gate="A" pin="1"/>
</segment>
</net>
<net name="OPT2_JMP" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO31"/>
<wire x1="187.96" y1="57.15" x2="173.99" y2="57.15" width="0.1524" layer="91"/>
<label x="175.26" y="57.658" size="1.524" layer="95"/>
<wire x1="173.99" y1="57.15" x2="172.72" y2="58.42" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="172.72" y1="-10.16" x2="173.99" y2="-11.43" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-11.43" x2="191.77" y2="-11.43" width="0.1524" layer="91"/>
<pinref part="JP2" gate="A" pin="1"/>
<label x="175.26" y="-10.922" size="1.524" layer="95"/>
</segment>
</net>
<net name="OPT1_JMP" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO30"/>
<wire x1="187.96" y1="59.69" x2="173.99" y2="59.69" width="0.1524" layer="91"/>
<label x="175.26" y="60.198" size="1.524" layer="95"/>
<wire x1="173.99" y1="59.69" x2="172.72" y2="60.96" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="172.72" y1="-2.54" x2="173.99" y2="-3.81" width="0.1524" layer="91"/>
<wire x1="173.99" y1="-3.81" x2="191.77" y2="-3.81" width="0.1524" layer="91"/>
<pinref part="JP1" gate="A" pin="1"/>
<label x="175.26" y="-3.302" size="1.524" layer="95"/>
</segment>
</net>
<net name="!M_IORDY" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO29"/>
<wire x1="187.96" y1="62.23" x2="173.99" y2="62.23" width="0.1524" layer="91"/>
<label x="175.26" y="62.738" size="1.524" layer="95"/>
<wire x1="173.99" y1="62.23" x2="172.72" y2="63.5" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="A" pin="O"/>
<wire x1="58.42" y1="35.56" x2="68.58" y2="35.56" width="0.1524" layer="91"/>
<label x="67.31" y="36.068" size="1.524" layer="95" rot="MR0"/>
<wire x1="68.58" y1="35.56" x2="69.85" y2="36.83" width="0.1524" layer="91"/>
</segment>
</net>
<net name="M_INTRQ" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO28"/>
<wire x1="187.96" y1="64.77" x2="173.99" y2="64.77" width="0.1524" layer="91"/>
<label x="175.26" y="65.278" size="1.524" layer="95"/>
<wire x1="173.99" y1="64.77" x2="172.72" y2="66.04" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="B" pin="O"/>
<wire x1="58.42" y1="11.43" x2="68.58" y2="11.43" width="0.1524" layer="91"/>
<label x="67.31" y="11.938" size="1.524" layer="95" rot="MR0"/>
<wire x1="68.58" y1="11.43" x2="69.85" y2="12.7" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!M_DIOW" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO27"/>
<wire x1="187.96" y1="67.31" x2="173.99" y2="67.31" width="0.1524" layer="91"/>
<label x="175.26" y="67.818" size="1.524" layer="95"/>
<wire x1="173.99" y1="67.31" x2="172.72" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="C" pin="I"/>
<wire x1="121.92" y1="12.7" x2="120.65" y2="11.43" width="0.1524" layer="91"/>
<wire x1="120.65" y1="11.43" x2="107.95" y2="11.43" width="0.1524" layer="91"/>
<label x="119.38" y="11.938" size="1.524" layer="95" rot="MR0"/>
<wire x1="107.95" y1="11.43" x2="105.41" y2="11.43" width="0.1524" layer="91"/>
<wire x1="107.95" y1="13.97" x2="107.95" y2="11.43" width="0.1524" layer="91"/>
<junction x="107.95" y="11.43"/>
<pinref part="RN5" gate="D" pin="1"/>
</segment>
</net>
<net name="!M_DIOR" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO26"/>
<wire x1="187.96" y1="69.85" x2="173.99" y2="69.85" width="0.1524" layer="91"/>
<label x="175.26" y="70.358" size="1.524" layer="95"/>
<wire x1="173.99" y1="69.85" x2="172.72" y2="71.12" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="D" pin="I"/>
<wire x1="172.72" y1="12.7" x2="171.45" y2="11.43" width="0.1524" layer="91"/>
<wire x1="171.45" y1="11.43" x2="160.02" y2="11.43" width="0.1524" layer="91"/>
<label x="170.18" y="11.938" size="1.524" layer="95" rot="MR0"/>
<wire x1="160.02" y1="11.43" x2="157.48" y2="11.43" width="0.1524" layer="91"/>
<wire x1="160.02" y1="13.97" x2="160.02" y2="11.43" width="0.1524" layer="91"/>
<junction x="160.02" y="11.43"/>
<pinref part="RN5" gate="C" pin="1"/>
</segment>
</net>
<net name="!M_CS1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO25"/>
<wire x1="187.96" y1="72.39" x2="173.99" y2="72.39" width="0.1524" layer="91"/>
<label x="175.26" y="72.898" size="1.524" layer="95"/>
<wire x1="173.99" y1="72.39" x2="172.72" y2="73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="A" pin="I"/>
<wire x1="121.92" y1="36.83" x2="120.65" y2="35.56" width="0.1524" layer="91"/>
<wire x1="120.65" y1="35.56" x2="107.95" y2="35.56" width="0.1524" layer="91"/>
<label x="119.38" y="36.068" size="1.524" layer="95" rot="MR0"/>
<wire x1="107.95" y1="35.56" x2="105.41" y2="35.56" width="0.1524" layer="91"/>
<wire x1="107.95" y1="38.1" x2="107.95" y2="35.56" width="0.1524" layer="91"/>
<junction x="107.95" y="35.56"/>
<pinref part="RN5" gate="B" pin="1"/>
</segment>
</net>
<net name="!M_CS0" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO24"/>
<wire x1="187.96" y1="74.93" x2="173.99" y2="74.93" width="0.1524" layer="91"/>
<label x="175.26" y="75.438" size="1.524" layer="95"/>
<wire x1="173.99" y1="74.93" x2="172.72" y2="76.2" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="B" pin="I"/>
<wire x1="172.72" y1="36.83" x2="171.45" y2="35.56" width="0.1524" layer="91"/>
<wire x1="171.45" y1="35.56" x2="160.02" y2="35.56" width="0.1524" layer="91"/>
<label x="170.18" y="36.068" size="1.524" layer="95" rot="MR0"/>
<wire x1="160.02" y1="35.56" x2="157.48" y2="35.56" width="0.1524" layer="91"/>
<wire x1="160.02" y1="38.1" x2="160.02" y2="35.56" width="0.1524" layer="91"/>
<junction x="160.02" y="35.56"/>
<pinref part="RN5" gate="A" pin="1"/>
</segment>
</net>
<net name="!M_RESET" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO23"/>
<wire x1="187.96" y1="77.47" x2="173.99" y2="77.47" width="0.1524" layer="91"/>
<label x="175.26" y="77.978" size="1.524" layer="95"/>
<wire x1="173.99" y1="77.47" x2="172.72" y2="78.74" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="D" pin="I"/>
<wire x1="121.92" y1="-33.02" x2="120.65" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="120.65" y1="-34.29" x2="107.95" y2="-34.29" width="0.1524" layer="91"/>
<label x="119.38" y="-33.782" size="1.524" layer="95" rot="MR0"/>
<pinref part="R5" gate="A" pin="1"/>
<wire x1="107.95" y1="-34.29" x2="105.41" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="107.95" y1="-31.75" x2="107.95" y2="-34.29" width="0.1524" layer="91"/>
<junction x="107.95" y="-34.29"/>
</segment>
</net>
<net name="A2" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO22"/>
<wire x1="187.96" y1="80.01" x2="173.99" y2="80.01" width="0.1524" layer="91"/>
<label x="175.26" y="80.518" size="1.524" layer="95"/>
<wire x1="173.99" y1="80.01" x2="172.72" y2="81.28" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="A" pin="I"/>
<wire x1="172.72" y1="-33.02" x2="171.45" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="171.45" y1="-34.29" x2="157.48" y2="-34.29" width="0.1524" layer="91"/>
<label x="170.18" y="-33.782" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="A1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO21"/>
<wire x1="187.96" y1="82.55" x2="173.99" y2="82.55" width="0.1524" layer="91"/>
<label x="175.26" y="83.058" size="1.524" layer="95"/>
<wire x1="173.99" y1="82.55" x2="172.72" y2="83.82" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="B" pin="I"/>
<wire x1="121.92" y1="-8.89" x2="120.65" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="120.65" y1="-10.16" x2="105.41" y2="-10.16" width="0.1524" layer="91"/>
<label x="119.38" y="-9.652" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="A0" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GPIO20"/>
<wire x1="187.96" y1="85.09" x2="173.99" y2="85.09" width="0.1524" layer="91"/>
<label x="175.26" y="85.598" size="1.524" layer="95"/>
<wire x1="173.99" y1="85.09" x2="172.72" y2="86.36" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="C" pin="I"/>
<wire x1="172.72" y1="-8.89" x2="171.45" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="171.45" y1="-10.16" x2="157.48" y2="-10.16" width="0.1524" layer="91"/>
<label x="170.18" y="-9.652" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="GND" class="0">
<segment>
<pinref part="IC1" gate="A" pin="GND"/>
<pinref part="U$1" gate="GND" pin="GND"/>
<wire x1="223.52" y1="3.81" x2="223.52" y2="6.35" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="A" pin="VREG_PGND"/>
<pinref part="U$2" gate="GND" pin="GND"/>
<wire x1="259.08" y1="118.11" x2="261.62" y2="118.11" width="0.1524" layer="91"/>
<wire x1="261.62" y1="118.11" x2="261.62" y2="116.84" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="PB1" gate="A" pin="2"/>
<pinref part="U$3" gate="GND" pin="GND"/>
<wire x1="339.09" y1="102.87" x2="340.36" y2="102.87" width="0.1524" layer="91"/>
<wire x1="340.36" y1="102.87" x2="340.36" y2="101.6" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C22" gate="A" pin="1"/>
<pinref part="U$5" gate="GND" pin="GND"/>
<wire x1="275.59" y1="67.31" x2="275.59" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C23" gate="A" pin="1"/>
<pinref part="U$6" gate="GND" pin="GND"/>
<wire x1="292.1" y1="67.31" x2="292.1" y2="68.58" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C21" gate="A" pin="2"/>
<pinref part="U$7" gate="GND" pin="GND"/>
<wire x1="314.96" y1="123.19" x2="314.96" y2="121.92" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C19" gate="A" pin="1"/>
<pinref part="U$13" gate="GND" pin="GND"/>
<wire x1="283.21" y1="143.51" x2="283.21" y2="144.78" width="0.1524" layer="91"/>
<wire x1="283.21" y1="144.78" x2="280.67" y2="144.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="C20" gate="A" pin="1"/>
<pinref part="U$16" gate="GND" pin="GND"/>
<wire x1="280.67" y1="129.54" x2="283.21" y2="129.54" width="0.1524" layer="91"/>
<wire x1="283.21" y1="129.54" x2="283.21" y2="128.27" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC9" gate="A" pin="GND"/>
<pinref part="U$19" gate="GND" pin="GND"/>
<wire x1="313.69" y1="36.83" x2="314.96" y2="36.83" width="0.1524" layer="91"/>
<wire x1="314.96" y1="36.83" x2="314.96" y2="34.29" width="0.1524" layer="91"/>
<pinref part="USB" gate="A" pin="GND"/>
<wire x1="318.77" y1="36.83" x2="314.96" y2="36.83" width="0.1524" layer="91"/>
<junction x="314.96" y="36.83"/>
</segment>
<segment>
<pinref part="U$17" gate="GND" pin="GND"/>
<pinref part="C26" gate="A" pin="1"/>
<wire x1="326.39" y1="19.05" x2="326.39" y2="17.78" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R17" gate="A" pin="1"/>
<pinref part="U$20" gate="GND" pin="GND"/>
<wire x1="334.01" y1="17.78" x2="334.01" y2="19.05" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$21" gate="GND" pin="GND"/>
<wire x1="276.86" y1="2.54" x2="276.86" y2="3.81" width="0.1524" layer="91"/>
<pinref part="C24" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="U$22" gate="GND" pin="GND"/>
<wire x1="297.18" y1="2.54" x2="297.18" y2="3.81" width="0.1524" layer="91"/>
<pinref part="C25" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="IC8" gate="A" pin="GND"/>
<pinref part="U$23" gate="GND" pin="GND"/>
<wire x1="287.02" y1="2.54" x2="287.02" y2="7.62" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="P" pin="GND"/>
<wire x1="55.88" y1="162.56" x2="55.88" y2="163.83" width="0.1524" layer="91"/>
<wire x1="50.8" y1="162.56" x2="55.88" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C1" gate="A" pin="1"/>
<wire x1="50.8" y1="168.91" x2="50.8" y2="162.56" width="0.1524" layer="91"/>
<junction x="50.8" y="162.56"/>
<pinref part="U$25" gate="GND" pin="GND"/>
<wire x1="46.99" y1="161.29" x2="46.99" y2="162.56" width="0.1524" layer="91"/>
<wire x1="46.99" y1="162.56" x2="50.8" y2="162.56" width="0.1524" layer="91"/>
<pinref part="IC2" gate="P" pin="GND"/>
<wire x1="68.58" y1="162.56" x2="68.58" y2="163.83" width="0.1524" layer="91"/>
<wire x1="63.5" y1="162.56" x2="68.58" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C2" gate="A" pin="1"/>
<wire x1="63.5" y1="168.91" x2="63.5" y2="162.56" width="0.1524" layer="91"/>
<wire x1="55.88" y1="162.56" x2="63.5" y2="162.56" width="0.1524" layer="91"/>
<junction x="55.88" y="162.56"/>
<junction x="63.5" y="162.56"/>
</segment>
<segment>
<pinref part="IC3" gate="P" pin="GND"/>
<wire x1="95.25" y1="162.56" x2="100.33" y2="162.56" width="0.1524" layer="91"/>
<wire x1="100.33" y1="162.56" x2="100.33" y2="163.83" width="0.1524" layer="91"/>
<pinref part="C3" gate="A" pin="1"/>
<wire x1="95.25" y1="168.91" x2="95.25" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C4" gate="A" pin="1"/>
<wire x1="107.95" y1="168.91" x2="107.95" y2="162.56" width="0.1524" layer="91"/>
<wire x1="107.95" y1="162.56" x2="100.33" y2="162.56" width="0.1524" layer="91"/>
<junction x="100.33" y="162.56"/>
<junction x="107.95" y="162.56"/>
<wire x1="107.95" y1="162.56" x2="114.3" y2="162.56" width="0.1524" layer="91"/>
<wire x1="114.3" y1="162.56" x2="121.92" y2="162.56" width="0.1524" layer="91"/>
<wire x1="121.92" y1="162.56" x2="127" y2="162.56" width="0.1524" layer="91"/>
<wire x1="127" y1="162.56" x2="134.62" y2="162.56" width="0.1524" layer="91"/>
<wire x1="134.62" y1="162.56" x2="139.7" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C6" gate="A" pin="1"/>
<wire x1="134.62" y1="168.91" x2="134.62" y2="162.56" width="0.1524" layer="91"/>
<junction x="134.62" y="162.56"/>
<pinref part="C5" gate="A" pin="1"/>
<wire x1="121.92" y1="168.91" x2="121.92" y2="162.56" width="0.1524" layer="91"/>
<junction x="121.92" y="162.56"/>
<pinref part="U$27" gate="GND" pin="GND"/>
<wire x1="95.25" y1="162.56" x2="91.44" y2="162.56" width="0.1524" layer="91"/>
<wire x1="91.44" y1="162.56" x2="91.44" y2="161.29" width="0.1524" layer="91"/>
<junction x="95.25" y="162.56"/>
<pinref part="IC4" gate="P" pin="GND"/>
<wire x1="114.3" y1="163.83" x2="114.3" y2="162.56" width="0.1524" layer="91"/>
<junction x="114.3" y="162.56"/>
<pinref part="IC5" gate="P" pin="GND"/>
<wire x1="127" y1="163.83" x2="127" y2="162.56" width="0.1524" layer="91"/>
<junction x="127" y="162.56"/>
<pinref part="IC6" gate="P" pin="GND"/>
<wire x1="139.7" y1="163.83" x2="139.7" y2="162.56" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="2"/>
<wire x1="11.43" y1="139.7" x2="16.51" y2="139.7" width="0.1524" layer="91"/>
<wire x1="16.51" y1="139.7" x2="16.51" y2="96.52" width="0.1524" layer="91"/>
<pinref part="U$30" gate="GND" pin="GND"/>
<pinref part="XC1" gate="A" pin="40"/>
<wire x1="16.51" y1="96.52" x2="16.51" y2="88.9" width="0.1524" layer="91"/>
<wire x1="16.51" y1="88.9" x2="16.51" y2="83.82" width="0.1524" layer="91"/>
<wire x1="16.51" y1="83.82" x2="16.51" y2="78.74" width="0.1524" layer="91"/>
<wire x1="16.51" y1="78.74" x2="16.51" y2="73.66" width="0.1524" layer="91"/>
<wire x1="16.51" y1="73.66" x2="16.51" y2="68.58" width="0.1524" layer="91"/>
<wire x1="16.51" y1="68.58" x2="16.51" y2="43.18" width="0.1524" layer="91"/>
<wire x1="16.51" y1="43.18" x2="16.51" y2="41.91" width="0.1524" layer="91"/>
<wire x1="11.43" y1="43.18" x2="16.51" y2="43.18" width="0.1524" layer="91"/>
<junction x="16.51" y="43.18"/>
<pinref part="XC1" gate="A" pin="19"/>
<wire x1="11.43" y1="96.52" x2="16.51" y2="96.52" width="0.1524" layer="91"/>
<junction x="16.51" y="96.52"/>
<pinref part="XC1" gate="A" pin="22"/>
<wire x1="11.43" y1="88.9" x2="16.51" y2="88.9" width="0.1524" layer="91"/>
<junction x="16.51" y="88.9"/>
<pinref part="XC1" gate="A" pin="24"/>
<wire x1="11.43" y1="83.82" x2="16.51" y2="83.82" width="0.1524" layer="91"/>
<junction x="16.51" y="83.82"/>
<pinref part="XC1" gate="A" pin="26"/>
<wire x1="11.43" y1="78.74" x2="16.51" y2="78.74" width="0.1524" layer="91"/>
<junction x="16.51" y="78.74"/>
<pinref part="XC1" gate="A" pin="30"/>
<wire x1="11.43" y1="68.58" x2="16.51" y2="68.58" width="0.1524" layer="91"/>
<junction x="16.51" y="68.58"/>
<pinref part="XC1" gate="A" pin="28"/>
<wire x1="11.43" y1="73.66" x2="16.51" y2="73.66" width="0.1524" layer="91"/>
<junction x="16.51" y="73.66"/>
</segment>
<segment>
<pinref part="IC7" gate="A" pin="OE"/>
<pinref part="U$18" gate="GND" pin="GND"/>
<wire x1="50.8" y1="29.21" x2="50.8" y2="30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="B" pin="OE"/>
<pinref part="U$34" gate="GND" pin="GND"/>
<wire x1="50.8" y1="5.08" x2="50.8" y2="6.35" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="A" pin="OE"/>
<pinref part="U$35" gate="GND" pin="GND"/>
<wire x1="97.79" y1="29.21" x2="97.79" y2="30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="C" pin="OE"/>
<pinref part="U$37" gate="GND" pin="GND"/>
<wire x1="97.79" y1="5.08" x2="97.79" y2="6.35" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="D" pin="OE"/>
<pinref part="U$38" gate="GND" pin="GND"/>
<wire x1="149.86" y1="5.08" x2="149.86" y2="6.35" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="C" pin="OE"/>
<pinref part="U$39" gate="GND" pin="GND"/>
<wire x1="149.86" y1="-16.51" x2="149.86" y2="-15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="B" pin="OE"/>
<pinref part="U$40" gate="GND" pin="GND"/>
<wire x1="97.79" y1="-16.51" x2="97.79" y2="-15.24" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="D" pin="OE"/>
<pinref part="U$41" gate="GND" pin="GND"/>
<wire x1="97.79" y1="-40.64" x2="97.79" y2="-39.37" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="A" pin="OE"/>
<pinref part="U$42" gate="GND" pin="GND"/>
<wire x1="149.86" y1="-40.64" x2="149.86" y2="-39.37" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="B" pin="OE"/>
<pinref part="U$36" gate="GND" pin="GND"/>
<wire x1="149.86" y1="29.21" x2="149.86" y2="30.48" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R4" gate="A" pin="1"/>
<pinref part="U$44" gate="GND" pin="GND"/>
<wire x1="40.64" y1="-2.54" x2="40.64" y2="-1.27" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$53" gate="GND" pin="GND"/>
<wire x1="190.5" y1="-39.37" x2="190.5" y2="-38.1" width="0.1524" layer="91"/>
<wire x1="190.5" y1="-38.1" x2="195.58" y2="-38.1" width="0.1524" layer="91"/>
<pinref part="D4" gate="A" pin="K"/>
</segment>
<segment>
<pinref part="U$54" gate="GND" pin="GND"/>
<wire x1="210.82" y1="-25.4" x2="210.82" y2="-24.13" width="0.1524" layer="91"/>
<wire x1="210.82" y1="-24.13" x2="205.74" y2="-24.13" width="0.1524" layer="91"/>
<pinref part="D2" gate="A" pin="K"/>
</segment>
<segment>
<pinref part="JP1" gate="A" pin="2"/>
<pinref part="U$55" gate="GND" pin="GND"/>
<wire x1="201.93" y1="-3.81" x2="210.82" y2="-3.81" width="0.1524" layer="91"/>
<wire x1="210.82" y1="-3.81" x2="210.82" y2="-11.43" width="0.1524" layer="91"/>
<pinref part="JP2" gate="A" pin="2"/>
<wire x1="210.82" y1="-11.43" x2="210.82" y2="-12.7" width="0.1524" layer="91"/>
<wire x1="201.93" y1="-11.43" x2="210.82" y2="-11.43" width="0.1524" layer="91"/>
<junction x="210.82" y="-11.43"/>
</segment>
<segment>
<pinref part="C7" gate="A" pin="1"/>
<wire x1="165.1" y1="168.91" x2="165.1" y2="162.56" width="0.1524" layer="91"/>
<wire x1="165.1" y1="162.56" x2="172.72" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C15" gate="A" pin="1"/>
<wire x1="172.72" y1="162.56" x2="180.34" y2="162.56" width="0.1524" layer="91"/>
<wire x1="180.34" y1="162.56" x2="187.96" y2="162.56" width="0.1524" layer="91"/>
<wire x1="187.96" y1="162.56" x2="195.58" y2="162.56" width="0.1524" layer="91"/>
<wire x1="195.58" y1="162.56" x2="203.2" y2="162.56" width="0.1524" layer="91"/>
<wire x1="203.2" y1="162.56" x2="210.82" y2="162.56" width="0.1524" layer="91"/>
<wire x1="210.82" y1="162.56" x2="218.44" y2="162.56" width="0.1524" layer="91"/>
<wire x1="218.44" y1="162.56" x2="226.06" y2="162.56" width="0.1524" layer="91"/>
<wire x1="226.06" y1="162.56" x2="226.06" y2="168.91" width="0.1524" layer="91"/>
<pinref part="C14" gate="A" pin="1"/>
<wire x1="218.44" y1="168.91" x2="218.44" y2="162.56" width="0.1524" layer="91"/>
<junction x="218.44" y="162.56"/>
<pinref part="C13" gate="A" pin="1"/>
<wire x1="210.82" y1="168.91" x2="210.82" y2="162.56" width="0.1524" layer="91"/>
<junction x="210.82" y="162.56"/>
<pinref part="C12" gate="A" pin="1"/>
<wire x1="203.2" y1="168.91" x2="203.2" y2="162.56" width="0.1524" layer="91"/>
<junction x="203.2" y="162.56"/>
<pinref part="C11" gate="A" pin="1"/>
<wire x1="195.58" y1="168.91" x2="195.58" y2="162.56" width="0.1524" layer="91"/>
<junction x="195.58" y="162.56"/>
<pinref part="C10" gate="A" pin="1"/>
<wire x1="187.96" y1="168.91" x2="187.96" y2="162.56" width="0.1524" layer="91"/>
<junction x="187.96" y="162.56"/>
<pinref part="C9" gate="A" pin="1"/>
<wire x1="180.34" y1="168.91" x2="180.34" y2="162.56" width="0.1524" layer="91"/>
<junction x="180.34" y="162.56"/>
<pinref part="C8" gate="A" pin="1"/>
<wire x1="172.72" y1="168.91" x2="172.72" y2="162.56" width="0.1524" layer="91"/>
<junction x="172.72" y="162.56"/>
<pinref part="U$56" gate="GND" pin="GND"/>
<wire x1="165.1" y1="162.56" x2="161.29" y2="162.56" width="0.1524" layer="91"/>
<wire x1="161.29" y1="162.56" x2="161.29" y2="161.29" width="0.1524" layer="91"/>
<junction x="165.1" y="162.56"/>
</segment>
<segment>
<pinref part="C16" gate="A" pin="1"/>
<wire x1="264.16" y1="168.91" x2="264.16" y2="162.56" width="0.1524" layer="91"/>
<wire x1="264.16" y1="162.56" x2="271.78" y2="162.56" width="0.1524" layer="91"/>
<pinref part="C18" gate="A" pin="1"/>
<wire x1="271.78" y1="162.56" x2="279.4" y2="162.56" width="0.1524" layer="91"/>
<wire x1="279.4" y1="162.56" x2="279.4" y2="168.91" width="0.1524" layer="91"/>
<pinref part="C17" gate="A" pin="1"/>
<wire x1="271.78" y1="168.91" x2="271.78" y2="162.56" width="0.1524" layer="91"/>
<junction x="271.78" y="162.56"/>
<pinref part="U$12" gate="GND" pin="GND"/>
<wire x1="283.21" y1="161.29" x2="283.21" y2="162.56" width="0.1524" layer="91"/>
<wire x1="283.21" y1="162.56" x2="279.4" y2="162.56" width="0.1524" layer="91"/>
<junction x="279.4" y="162.56"/>
</segment>
<segment>
<pinref part="PWR" gate="A" pin="2"/>
<wire x1="321.31" y1="-34.29" x2="318.77" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="318.77" y1="-34.29" x2="318.77" y2="-35.56" width="0.1524" layer="91"/>
<pinref part="PWR" gate="A" pin="3"/>
<wire x1="318.77" y1="-35.56" x2="318.77" y2="-36.83" width="0.1524" layer="91"/>
<wire x1="318.77" y1="-36.83" x2="321.31" y2="-36.83" width="0.1524" layer="91"/>
<pinref part="U$50" gate="GND" pin="GND"/>
<wire x1="313.69" y1="-35.56" x2="318.77" y2="-35.56" width="0.1524" layer="91"/>
<junction x="318.77" y="-35.56"/>
</segment>
<segment>
<pinref part="GND1" gate="A" pin="1"/>
<wire x1="257.81" y1="-38.1" x2="256.54" y2="-38.1" width="0.1524" layer="91"/>
<pinref part="GND2" gate="A" pin="1"/>
<wire x1="257.81" y1="-33.02" x2="256.54" y2="-33.02" width="0.1524" layer="91"/>
<wire x1="257.81" y1="-38.1" x2="257.81" y2="-35.56" width="0.1524" layer="91"/>
<pinref part="U$58" gate="GND" pin="GND"/>
<wire x1="257.81" y1="-35.56" x2="257.81" y2="-33.02" width="0.1524" layer="91"/>
<wire x1="273.05" y1="-35.56" x2="266.7" y2="-35.56" width="0.1524" layer="91"/>
<junction x="257.81" y="-35.56"/>
<pinref part="D6" gate="A" pin="A"/>
<wire x1="266.7" y1="-35.56" x2="257.81" y2="-35.56" width="0.1524" layer="91"/>
<wire x1="266.7" y1="-34.29" x2="266.7" y2="-35.56" width="0.1524" layer="91"/>
<junction x="266.7" y="-35.56"/>
<pinref part="D5" gate="A" pin="A"/>
<wire x1="266.7" y1="-36.83" x2="266.7" y2="-35.56" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="D3" gate="A" pin="K"/>
<pinref part="U$65" gate="GND" pin="GND"/>
<wire x1="195.58" y1="-49.53" x2="190.5" y2="-49.53" width="0.1524" layer="91"/>
<wire x1="190.5" y1="-49.53" x2="190.5" y2="-50.8" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="PB2" gate="A" pin="2"/>
<pinref part="U$66" gate="GND" pin="GND"/>
<wire x1="322.58" y1="62.23" x2="323.85" y2="62.23" width="0.1524" layer="91"/>
<wire x1="323.85" y1="62.23" x2="323.85" y2="60.96" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$1" class="0">
<segment>
<pinref part="IC1" gate="A" pin="USB_DP"/>
<pinref part="R6" gate="A" pin="2"/>
<wire x1="186.69" y1="146.05" x2="187.96" y2="146.05" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$2" class="0">
<segment>
<pinref part="IC1" gate="A" pin="USB_DM"/>
<pinref part="R7" gate="A" pin="2"/>
<wire x1="186.69" y1="143.51" x2="187.96" y2="143.51" width="0.1524" layer="91"/>
</segment>
</net>
<net name="USB_DP" class="0">
<segment>
<pinref part="R6" gate="A" pin="1"/>
<wire x1="176.53" y1="146.05" x2="173.99" y2="146.05" width="0.1524" layer="91"/>
<label x="173.99" y="146.05" size="1.27" layer="95" rot="MR0" xref="yes"/>
</segment>
<segment>
<pinref part="IC9" gate="A" pin="O2"/>
<wire x1="285.75" y1="39.37" x2="275.59" y2="39.37" width="0.1524" layer="91"/>
<label x="275.59" y="39.37" size="1.27" layer="95" rot="MR0" xref="yes"/>
</segment>
</net>
<net name="USB_DM" class="0">
<segment>
<pinref part="R7" gate="A" pin="1"/>
<wire x1="176.53" y1="143.51" x2="173.99" y2="143.51" width="0.1524" layer="91"/>
<label x="173.99" y="143.51" size="1.27" layer="95" rot="MR0" xref="yes"/>
</segment>
<segment>
<pinref part="IC9" gate="A" pin="O1"/>
<wire x1="285.75" y1="41.91" x2="275.59" y2="41.91" width="0.1524" layer="91"/>
<label x="275.59" y="41.91" size="1.27" layer="95" rot="MR0" xref="yes"/>
</segment>
</net>
<net name="N$3" class="0">
<segment>
<pinref part="IC2" gate="A" pin="DI(IO0)"/>
<pinref part="IC1" gate="A" pin="QSPI_SD0"/>
<wire x1="280.67" y1="105.41" x2="259.08" y2="105.41" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$4" class="0">
<segment>
<pinref part="IC2" gate="A" pin="DO(IO1)"/>
<pinref part="IC1" gate="A" pin="QSPI_SD1"/>
<wire x1="280.67" y1="102.87" x2="259.08" y2="102.87" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$5" class="0">
<segment>
<pinref part="IC2" gate="A" pin="!WP!(IO2)"/>
<pinref part="IC1" gate="A" pin="QSPI_SD2"/>
<wire x1="280.67" y1="100.33" x2="259.08" y2="100.33" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$6" class="0">
<segment>
<pinref part="IC2" gate="A" pin="!HOLD!(IO3)"/>
<pinref part="IC1" gate="A" pin="QSPI_SD3"/>
<wire x1="280.67" y1="97.79" x2="259.08" y2="97.79" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$7" class="0">
<segment>
<pinref part="IC2" gate="A" pin="CLK"/>
<wire x1="308.61" y1="100.33" x2="309.88" y2="100.33" width="0.1524" layer="91"/>
<wire x1="309.88" y1="100.33" x2="309.88" y2="90.17" width="0.1524" layer="91"/>
<wire x1="309.88" y1="90.17" x2="275.59" y2="90.17" width="0.1524" layer="91"/>
<pinref part="IC1" gate="A" pin="QSPI_SCLK"/>
<wire x1="275.59" y1="90.17" x2="275.59" y2="92.71" width="0.1524" layer="91"/>
<wire x1="275.59" y1="92.71" x2="259.08" y2="92.71" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$8" class="0">
<segment>
<pinref part="R15" gate="A" pin="2"/>
<pinref part="PB1" gate="A" pin="1"/>
<wire x1="326.39" y1="102.87" x2="325.12" y2="102.87" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$9" class="0">
<segment>
<pinref part="IC1" gate="A" pin="QSPI_SS"/>
<wire x1="259.08" y1="110.49" x2="275.59" y2="110.49" width="0.1524" layer="91"/>
<wire x1="275.59" y1="110.49" x2="275.59" y2="113.03" width="0.1524" layer="91"/>
<wire x1="275.59" y1="113.03" x2="309.88" y2="113.03" width="0.1524" layer="91"/>
<pinref part="IC2" gate="A" pin="!CS"/>
<wire x1="308.61" y1="102.87" x2="309.88" y2="102.87" width="0.1524" layer="91"/>
<wire x1="309.88" y1="102.87" x2="309.88" y2="113.03" width="0.1524" layer="91"/>
<pinref part="R15" gate="A" pin="1"/>
<wire x1="309.88" y1="102.87" x2="313.69" y2="102.87" width="0.1524" layer="91"/>
<junction x="309.88" y="102.87"/>
<pinref part="R14" gate="A" pin="1"/>
<wire x1="313.69" y1="102.87" x2="314.96" y2="102.87" width="0.1524" layer="91"/>
<wire x1="314.96" y1="113.03" x2="313.69" y2="113.03" width="0.1524" layer="91"/>
<wire x1="313.69" y1="113.03" x2="313.69" y2="102.87" width="0.1524" layer="91"/>
<junction x="313.69" y="102.87"/>
</segment>
</net>
<net name="+3,3V" class="0">
<segment>
<pinref part="R14" gate="A" pin="2"/>
<pinref part="U$4" gate="G$1" pin="+3,3V"/>
<wire x1="326.39" y1="113.03" x2="325.12" y2="113.03" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="R12" gate="A" pin="2"/>
<pinref part="U$14" gate="G$1" pin="+3,3V"/>
<wire x1="281.94" y1="152.4" x2="280.67" y2="152.4" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC1" gate="A" pin="VREG_VIN"/>
<wire x1="259.08" y1="125.73" x2="264.16" y2="125.73" width="0.1524" layer="91"/>
<wire x1="264.16" y1="125.73" x2="264.16" y2="135.89" width="0.1524" layer="91"/>
<wire x1="264.16" y1="135.89" x2="267.97" y2="135.89" width="0.1524" layer="91"/>
<pinref part="U$15" gate="G$1" pin="+3,3V"/>
<pinref part="C20" gate="A" pin="2"/>
<wire x1="267.97" y1="135.89" x2="281.94" y2="135.89" width="0.1524" layer="91"/>
<wire x1="270.51" y1="129.54" x2="267.97" y2="129.54" width="0.1524" layer="91"/>
<wire x1="267.97" y1="129.54" x2="267.97" y2="135.89" width="0.1524" layer="91"/>
<junction x="267.97" y="135.89"/>
</segment>
<segment>
<pinref part="IC8" gate="A" pin="OUT"/>
<wire x1="279.4" y1="15.24" x2="276.86" y2="15.24" width="0.1524" layer="91"/>
<wire x1="276.86" y1="15.24" x2="276.86" y2="13.97" width="0.1524" layer="91"/>
<pinref part="C24" gate="A" pin="2"/>
<pinref part="U$24" gate="G$1" pin="+3,3V"/>
<wire x1="275.59" y1="15.24" x2="276.86" y2="15.24" width="0.1524" layer="91"/>
<junction x="276.86" y="15.24"/>
</segment>
<segment>
<pinref part="IC7" gate="P" pin="VCC"/>
<wire x1="55.88" y1="185.42" x2="55.88" y2="184.15" width="0.1524" layer="91"/>
<wire x1="50.8" y1="185.42" x2="55.88" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C1" gate="A" pin="2"/>
<wire x1="50.8" y1="179.07" x2="50.8" y2="185.42" width="0.1524" layer="91"/>
<junction x="50.8" y="185.42"/>
<pinref part="U$26" gate="G$1" pin="+3,3V"/>
<wire x1="46.99" y1="185.42" x2="50.8" y2="185.42" width="0.1524" layer="91"/>
<pinref part="IC2" gate="P" pin="VCC"/>
<wire x1="68.58" y1="184.15" x2="68.58" y2="185.42" width="0.1524" layer="91"/>
<wire x1="68.58" y1="185.42" x2="63.5" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C2" gate="A" pin="2"/>
<wire x1="63.5" y1="179.07" x2="63.5" y2="185.42" width="0.1524" layer="91"/>
<wire x1="55.88" y1="185.42" x2="63.5" y2="185.42" width="0.1524" layer="91"/>
<junction x="55.88" y="185.42"/>
<junction x="63.5" y="185.42"/>
</segment>
<segment>
<pinref part="IC1" gate="A" pin="QSPI_IOVDD"/>
<wire x1="240.03" y1="153.67" x2="240.03" y2="156.21" width="0.1524" layer="91"/>
<wire x1="240.03" y1="156.21" x2="234.95" y2="156.21" width="0.1524" layer="91"/>
<pinref part="IC1" gate="A" pin="ADC_AVDD"/>
<wire x1="234.95" y1="156.21" x2="232.41" y2="156.21" width="0.1524" layer="91"/>
<wire x1="232.41" y1="156.21" x2="229.87" y2="156.21" width="0.1524" layer="91"/>
<wire x1="229.87" y1="156.21" x2="227.33" y2="156.21" width="0.1524" layer="91"/>
<wire x1="227.33" y1="156.21" x2="224.79" y2="156.21" width="0.1524" layer="91"/>
<wire x1="224.79" y1="156.21" x2="222.25" y2="156.21" width="0.1524" layer="91"/>
<wire x1="222.25" y1="156.21" x2="219.71" y2="156.21" width="0.1524" layer="91"/>
<wire x1="219.71" y1="156.21" x2="217.17" y2="156.21" width="0.1524" layer="91"/>
<wire x1="217.17" y1="156.21" x2="212.09" y2="156.21" width="0.1524" layer="91"/>
<wire x1="212.09" y1="156.21" x2="207.01" y2="156.21" width="0.1524" layer="91"/>
<wire x1="207.01" y1="156.21" x2="207.01" y2="153.67" width="0.1524" layer="91"/>
<pinref part="IC1" gate="A" pin="USB_OTP_VDD"/>
<wire x1="212.09" y1="153.67" x2="212.09" y2="156.21" width="0.1524" layer="91"/>
<junction x="212.09" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD5"/>
<wire x1="217.17" y1="153.67" x2="217.17" y2="156.21" width="0.1524" layer="91"/>
<junction x="217.17" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD29"/>
<wire x1="219.71" y1="153.67" x2="219.71" y2="156.21" width="0.1524" layer="91"/>
<junction x="219.71" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD15"/>
<wire x1="222.25" y1="153.67" x2="222.25" y2="156.21" width="0.1524" layer="91"/>
<junction x="222.25" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD24"/>
<wire x1="224.79" y1="153.67" x2="224.79" y2="156.21" width="0.1524" layer="91"/>
<junction x="224.79" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD41"/>
<wire x1="227.33" y1="153.67" x2="227.33" y2="156.21" width="0.1524" layer="91"/>
<junction x="227.33" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD50"/>
<wire x1="229.87" y1="153.67" x2="229.87" y2="156.21" width="0.1524" layer="91"/>
<junction x="229.87" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD60"/>
<wire x1="232.41" y1="153.67" x2="232.41" y2="156.21" width="0.1524" layer="91"/>
<junction x="232.41" y="156.21"/>
<pinref part="IC1" gate="A" pin="IOVDD76"/>
<wire x1="234.95" y1="153.67" x2="234.95" y2="156.21" width="0.1524" layer="91"/>
<junction x="234.95" y="156.21"/>
<pinref part="C7" gate="A" pin="2"/>
<wire x1="165.1" y1="179.07" x2="165.1" y2="185.42" width="0.1524" layer="91"/>
<wire x1="165.1" y1="185.42" x2="172.72" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C15" gate="A" pin="2"/>
<wire x1="172.72" y1="185.42" x2="180.34" y2="185.42" width="0.1524" layer="91"/>
<wire x1="180.34" y1="185.42" x2="187.96" y2="185.42" width="0.1524" layer="91"/>
<wire x1="187.96" y1="185.42" x2="195.58" y2="185.42" width="0.1524" layer="91"/>
<wire x1="195.58" y1="185.42" x2="203.2" y2="185.42" width="0.1524" layer="91"/>
<wire x1="203.2" y1="185.42" x2="210.82" y2="185.42" width="0.1524" layer="91"/>
<wire x1="210.82" y1="185.42" x2="218.44" y2="185.42" width="0.1524" layer="91"/>
<wire x1="218.44" y1="185.42" x2="226.06" y2="185.42" width="0.1524" layer="91"/>
<wire x1="226.06" y1="185.42" x2="226.06" y2="179.07" width="0.1524" layer="91"/>
<pinref part="C14" gate="A" pin="2"/>
<wire x1="218.44" y1="179.07" x2="218.44" y2="185.42" width="0.1524" layer="91"/>
<junction x="218.44" y="185.42"/>
<pinref part="C13" gate="A" pin="2"/>
<wire x1="210.82" y1="179.07" x2="210.82" y2="185.42" width="0.1524" layer="91"/>
<junction x="210.82" y="185.42"/>
<pinref part="C12" gate="A" pin="2"/>
<wire x1="203.2" y1="179.07" x2="203.2" y2="185.42" width="0.1524" layer="91"/>
<junction x="203.2" y="185.42"/>
<pinref part="C11" gate="A" pin="2"/>
<wire x1="195.58" y1="179.07" x2="195.58" y2="185.42" width="0.1524" layer="91"/>
<junction x="195.58" y="185.42"/>
<pinref part="C10" gate="A" pin="2"/>
<wire x1="187.96" y1="179.07" x2="187.96" y2="185.42" width="0.1524" layer="91"/>
<junction x="187.96" y="185.42"/>
<pinref part="C9" gate="A" pin="2"/>
<wire x1="180.34" y1="179.07" x2="180.34" y2="185.42" width="0.1524" layer="91"/>
<junction x="180.34" y="185.42"/>
<pinref part="C8" gate="A" pin="2"/>
<wire x1="172.72" y1="179.07" x2="172.72" y2="185.42" width="0.1524" layer="91"/>
<junction x="172.72" y="185.42"/>
<wire x1="240.03" y1="156.21" x2="240.03" y2="185.42" width="0.1524" layer="91"/>
<wire x1="240.03" y1="185.42" x2="226.06" y2="185.42" width="0.1524" layer="91"/>
<junction x="240.03" y="156.21"/>
<junction x="226.06" y="185.42"/>
<pinref part="U$57" gate="G$1" pin="+3,3V"/>
<wire x1="161.29" y1="185.42" x2="165.1" y2="185.42" width="0.1524" layer="91"/>
<junction x="165.1" y="185.42"/>
</segment>
<segment>
<pinref part="R5" gate="A" pin="2"/>
<pinref part="U$47" gate="G$1" pin="+3,3V"/>
</segment>
<segment>
<pinref part="U$48" gate="G$1" pin="+3,3V"/>
<pinref part="R2" gate="A" pin="2"/>
</segment>
<segment>
<pinref part="R1" gate="A" pin="2"/>
<pinref part="U$49" gate="G$1" pin="+3,3V"/>
</segment>
<segment>
<pinref part="IC9" gate="A" pin="VBUS"/>
<wire x1="283.21" y1="36.83" x2="285.75" y2="36.83" width="0.1524" layer="91"/>
<pinref part="U$29" gate="G$1" pin="+3,3V"/>
</segment>
<segment>
<pinref part="U$67" gate="G$1" pin="+3,3V"/>
<pinref part="R16" gate="A" pin="2"/>
<wire x1="320.04" y1="73.66" x2="321.31" y2="73.66" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$45" gate="G$1" pin="+3,3V"/>
<pinref part="RN5" gate="A" pin="2"/>
</segment>
<segment>
<pinref part="U$10" gate="G$1" pin="+3,3V"/>
<pinref part="RN5" gate="B" pin="2"/>
</segment>
<segment>
<pinref part="U$46" gate="G$1" pin="+3,3V"/>
<pinref part="RN5" gate="C" pin="2"/>
</segment>
<segment>
<pinref part="U$11" gate="G$1" pin="+3,3V"/>
<pinref part="RN5" gate="D" pin="2"/>
</segment>
</net>
<net name="N$10" class="0">
<segment>
<pinref part="IC1" gate="A" pin="XOUT"/>
<pinref part="R13" gate="A" pin="1"/>
<wire x1="261.62" y1="80.01" x2="259.08" y2="80.01" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$11" class="0">
<segment>
<pinref part="R13" gate="A" pin="2"/>
<pinref part="X1" gate="A" pin="1"/>
<wire x1="278.13" y1="80.01" x2="275.59" y2="80.01" width="0.1524" layer="91"/>
<pinref part="C22" gate="A" pin="2"/>
<wire x1="275.59" y1="80.01" x2="271.78" y2="80.01" width="0.1524" layer="91"/>
<wire x1="275.59" y1="78.74" x2="275.59" y2="80.01" width="0.1524" layer="91"/>
<junction x="275.59" y="80.01"/>
</segment>
</net>
<net name="N$12" class="0">
<segment>
<pinref part="IC1" gate="A" pin="XIN"/>
<wire x1="259.08" y1="85.09" x2="275.59" y2="85.09" width="0.1524" layer="91"/>
<wire x1="275.59" y1="85.09" x2="275.59" y2="87.63" width="0.1524" layer="91"/>
<pinref part="C23" gate="A" pin="2"/>
<wire x1="275.59" y1="87.63" x2="292.1" y2="87.63" width="0.1524" layer="91"/>
<wire x1="292.1" y1="87.63" x2="292.1" y2="80.01" width="0.1524" layer="91"/>
<pinref part="X1" gate="A" pin="2"/>
<wire x1="292.1" y1="80.01" x2="292.1" y2="78.74" width="0.1524" layer="91"/>
<wire x1="288.29" y1="80.01" x2="292.1" y2="80.01" width="0.1524" layer="91"/>
<junction x="292.1" y="80.01"/>
</segment>
</net>
<net name="N$13" class="0">
<segment>
<pinref part="IC1" gate="A" pin="VREG_LX"/>
<pinref part="L1" gate="A" pin="Z"/>
<wire x1="276.86" y1="116.84" x2="275.59" y2="116.84" width="0.1524" layer="91"/>
<wire x1="275.59" y1="116.84" x2="275.59" y2="120.65" width="0.1524" layer="91"/>
<wire x1="275.59" y1="120.65" x2="259.08" y2="120.65" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$15" class="0">
<segment>
<pinref part="IC1" gate="A" pin="VREG_AVDD"/>
<wire x1="259.08" y1="128.27" x2="261.62" y2="128.27" width="0.1524" layer="91"/>
<wire x1="261.62" y1="128.27" x2="261.62" y2="152.4" width="0.1524" layer="91"/>
<wire x1="261.62" y1="152.4" x2="267.97" y2="152.4" width="0.1524" layer="91"/>
<pinref part="C19" gate="A" pin="2"/>
<wire x1="267.97" y1="152.4" x2="270.51" y2="152.4" width="0.1524" layer="91"/>
<wire x1="270.51" y1="144.78" x2="267.97" y2="144.78" width="0.1524" layer="91"/>
<wire x1="267.97" y1="144.78" x2="267.97" y2="152.4" width="0.1524" layer="91"/>
<junction x="267.97" y="152.4"/>
<pinref part="R12" gate="A" pin="1"/>
</segment>
</net>
<net name="N$14" class="0">
<segment>
<pinref part="USB" gate="A" pin="D-"/>
<pinref part="IC9" gate="A" pin="I1"/>
<wire x1="318.77" y1="41.91" x2="313.69" y2="41.91" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$16" class="0">
<segment>
<pinref part="USB" gate="A" pin="D+"/>
<pinref part="IC9" gate="A" pin="I2"/>
<wire x1="318.77" y1="39.37" x2="313.69" y2="39.37" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD0" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B1"/>
<wire x1="88.9" y1="128.27" x2="68.58" y2="128.27" width="0.1524" layer="91"/>
<label x="59.69" y="128.778" size="1.524" layer="95"/>
<wire x1="68.58" y1="128.27" x2="58.42" y2="128.27" width="0.1524" layer="91"/>
<wire x1="58.42" y1="128.27" x2="57.15" y2="129.54" width="0.1524" layer="91"/>
<wire x1="68.58" y1="133.35" x2="68.58" y2="128.27" width="0.1524" layer="91"/>
<junction x="68.58" y="128.27"/>
<pinref part="RN1" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="17"/>
<wire x1="30.48" y1="102.87" x2="29.21" y2="101.6" width="0.1524" layer="91"/>
<wire x1="29.21" y1="101.6" x2="11.43" y2="101.6" width="0.1524" layer="91"/>
<label x="27.94" y="102.108" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD1" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B2"/>
<wire x1="88.9" y1="125.73" x2="71.12" y2="125.73" width="0.1524" layer="91"/>
<label x="59.69" y="126.238" size="1.524" layer="95"/>
<wire x1="71.12" y1="125.73" x2="58.42" y2="125.73" width="0.1524" layer="91"/>
<wire x1="58.42" y1="125.73" x2="57.15" y2="127" width="0.1524" layer="91"/>
<wire x1="71.12" y1="133.35" x2="71.12" y2="125.73" width="0.1524" layer="91"/>
<junction x="71.12" y="125.73"/>
<pinref part="RN1" gate="B" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="15"/>
<wire x1="30.48" y1="107.95" x2="29.21" y2="106.68" width="0.1524" layer="91"/>
<wire x1="29.21" y1="106.68" x2="11.43" y2="106.68" width="0.1524" layer="91"/>
<label x="27.94" y="107.188" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD2" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B3"/>
<wire x1="88.9" y1="123.19" x2="73.66" y2="123.19" width="0.1524" layer="91"/>
<label x="59.69" y="123.698" size="1.524" layer="95"/>
<wire x1="73.66" y1="123.19" x2="58.42" y2="123.19" width="0.1524" layer="91"/>
<wire x1="58.42" y1="123.19" x2="57.15" y2="124.46" width="0.1524" layer="91"/>
<wire x1="73.66" y1="133.35" x2="73.66" y2="123.19" width="0.1524" layer="91"/>
<junction x="73.66" y="123.19"/>
<pinref part="RN1" gate="C" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="13"/>
<wire x1="30.48" y1="113.03" x2="29.21" y2="111.76" width="0.1524" layer="91"/>
<wire x1="29.21" y1="111.76" x2="11.43" y2="111.76" width="0.1524" layer="91"/>
<label x="27.94" y="112.268" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD3" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B4"/>
<wire x1="88.9" y1="120.65" x2="76.2" y2="120.65" width="0.1524" layer="91"/>
<label x="59.69" y="121.158" size="1.524" layer="95"/>
<wire x1="76.2" y1="120.65" x2="58.42" y2="120.65" width="0.1524" layer="91"/>
<wire x1="58.42" y1="120.65" x2="57.15" y2="121.92" width="0.1524" layer="91"/>
<wire x1="76.2" y1="133.35" x2="76.2" y2="120.65" width="0.1524" layer="91"/>
<junction x="76.2" y="120.65"/>
<pinref part="RN1" gate="D" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="11"/>
<wire x1="30.48" y1="118.11" x2="29.21" y2="116.84" width="0.1524" layer="91"/>
<wire x1="29.21" y1="116.84" x2="11.43" y2="116.84" width="0.1524" layer="91"/>
<label x="27.94" y="117.348" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD4" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B5"/>
<wire x1="88.9" y1="118.11" x2="78.74" y2="118.11" width="0.1524" layer="91"/>
<label x="59.69" y="118.618" size="1.524" layer="95"/>
<wire x1="78.74" y1="118.11" x2="58.42" y2="118.11" width="0.1524" layer="91"/>
<wire x1="58.42" y1="118.11" x2="57.15" y2="119.38" width="0.1524" layer="91"/>
<wire x1="78.74" y1="133.35" x2="78.74" y2="118.11" width="0.1524" layer="91"/>
<junction x="78.74" y="118.11"/>
<pinref part="RN2" gate="A" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="9"/>
<wire x1="30.48" y1="123.19" x2="29.21" y2="121.92" width="0.1524" layer="91"/>
<wire x1="29.21" y1="121.92" x2="11.43" y2="121.92" width="0.1524" layer="91"/>
<label x="27.94" y="122.428" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD5" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B6"/>
<wire x1="88.9" y1="115.57" x2="81.28" y2="115.57" width="0.1524" layer="91"/>
<label x="59.69" y="116.078" size="1.524" layer="95"/>
<wire x1="81.28" y1="115.57" x2="58.42" y2="115.57" width="0.1524" layer="91"/>
<wire x1="58.42" y1="115.57" x2="57.15" y2="116.84" width="0.1524" layer="91"/>
<wire x1="81.28" y1="133.35" x2="81.28" y2="115.57" width="0.1524" layer="91"/>
<junction x="81.28" y="115.57"/>
<pinref part="RN2" gate="B" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="7"/>
<wire x1="30.48" y1="128.27" x2="29.21" y2="127" width="0.1524" layer="91"/>
<wire x1="29.21" y1="127" x2="11.43" y2="127" width="0.1524" layer="91"/>
<label x="27.94" y="127.508" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD6" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B7"/>
<wire x1="88.9" y1="113.03" x2="83.82" y2="113.03" width="0.1524" layer="91"/>
<label x="59.69" y="113.538" size="1.524" layer="95"/>
<wire x1="83.82" y1="113.03" x2="58.42" y2="113.03" width="0.1524" layer="91"/>
<wire x1="58.42" y1="113.03" x2="57.15" y2="114.3" width="0.1524" layer="91"/>
<wire x1="83.82" y1="133.35" x2="83.82" y2="113.03" width="0.1524" layer="91"/>
<junction x="83.82" y="113.03"/>
<pinref part="RN2" gate="C" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="5"/>
<wire x1="30.48" y1="133.35" x2="29.21" y2="132.08" width="0.1524" layer="91"/>
<wire x1="29.21" y1="132.08" x2="11.43" y2="132.08" width="0.1524" layer="91"/>
<label x="27.94" y="132.588" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="DD7" class="0">
<segment>
<pinref part="IC3" gate="A" pin="B8"/>
<wire x1="88.9" y1="110.49" x2="86.36" y2="110.49" width="0.1524" layer="91"/>
<label x="59.69" y="110.998" size="1.524" layer="95"/>
<wire x1="86.36" y1="110.49" x2="58.42" y2="110.49" width="0.1524" layer="91"/>
<wire x1="58.42" y1="110.49" x2="57.15" y2="111.76" width="0.1524" layer="91"/>
<wire x1="86.36" y1="133.35" x2="86.36" y2="110.49" width="0.1524" layer="91"/>
<junction x="86.36" y="110.49"/>
<pinref part="RN2" gate="D" pin="1"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="3"/>
<wire x1="30.48" y1="138.43" x2="29.21" y2="137.16" width="0.1524" layer="91"/>
<wire x1="29.21" y1="137.16" x2="11.43" y2="137.16" width="0.1524" layer="91"/>
<label x="27.94" y="137.668" size="1.524" layer="95" rot="MR0"/>
</segment>
</net>
<net name="+5V" class="0">
<segment>
<pinref part="IC3" gate="P" pin="VCC"/>
<wire x1="100.33" y1="184.15" x2="100.33" y2="185.42" width="0.1524" layer="91"/>
<wire x1="100.33" y1="185.42" x2="95.25" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C3" gate="A" pin="2"/>
<wire x1="95.25" y1="179.07" x2="95.25" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C4" gate="A" pin="2"/>
<wire x1="107.95" y1="179.07" x2="107.95" y2="185.42" width="0.1524" layer="91"/>
<wire x1="107.95" y1="185.42" x2="100.33" y2="185.42" width="0.1524" layer="91"/>
<junction x="100.33" y="185.42"/>
<junction x="107.95" y="185.42"/>
<wire x1="139.7" y1="185.42" x2="134.62" y2="185.42" width="0.1524" layer="91"/>
<wire x1="134.62" y1="185.42" x2="127" y2="185.42" width="0.1524" layer="91"/>
<wire x1="127" y1="185.42" x2="121.92" y2="185.42" width="0.1524" layer="91"/>
<wire x1="121.92" y1="185.42" x2="114.3" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C5" gate="A" pin="2"/>
<wire x1="114.3" y1="185.42" x2="107.95" y2="185.42" width="0.1524" layer="91"/>
<wire x1="121.92" y1="179.07" x2="121.92" y2="185.42" width="0.1524" layer="91"/>
<junction x="121.92" y="185.42"/>
<pinref part="C6" gate="A" pin="2"/>
<wire x1="134.62" y1="179.07" x2="134.62" y2="185.42" width="0.1524" layer="91"/>
<junction x="134.62" y="185.42"/>
<pinref part="U$28" gate="A" pin="+5V"/>
<wire x1="91.44" y1="185.42" x2="95.25" y2="185.42" width="0.1524" layer="91"/>
<junction x="95.25" y="185.42"/>
<pinref part="IC4" gate="P" pin="VCC"/>
<wire x1="114.3" y1="184.15" x2="114.3" y2="185.42" width="0.1524" layer="91"/>
<junction x="114.3" y="185.42"/>
<pinref part="IC5" gate="P" pin="VCC"/>
<wire x1="127" y1="184.15" x2="127" y2="185.42" width="0.1524" layer="91"/>
<junction x="127" y="185.42"/>
<pinref part="IC6" gate="P" pin="VCC"/>
<wire x1="139.7" y1="184.15" x2="139.7" y2="185.42" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="XC1" gate="A" pin="29"/>
<pinref part="U$31" gate="A" pin="+5V"/>
<wire x1="19.05" y1="71.12" x2="11.43" y2="71.12" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="U$32" gate="A" pin="+5V"/>
<wire x1="67.31" y1="147.32" x2="68.58" y2="147.32" width="0.1524" layer="91"/>
<wire x1="68.58" y1="147.32" x2="68.58" y2="143.51" width="0.1524" layer="91"/>
<wire x1="68.58" y1="147.32" x2="71.12" y2="147.32" width="0.1524" layer="91"/>
<wire x1="71.12" y1="147.32" x2="71.12" y2="143.51" width="0.1524" layer="91"/>
<junction x="68.58" y="147.32"/>
<wire x1="71.12" y1="147.32" x2="73.66" y2="147.32" width="0.1524" layer="91"/>
<wire x1="73.66" y1="147.32" x2="76.2" y2="147.32" width="0.1524" layer="91"/>
<wire x1="76.2" y1="147.32" x2="78.74" y2="147.32" width="0.1524" layer="91"/>
<wire x1="78.74" y1="147.32" x2="81.28" y2="147.32" width="0.1524" layer="91"/>
<wire x1="81.28" y1="147.32" x2="83.82" y2="147.32" width="0.1524" layer="91"/>
<wire x1="83.82" y1="147.32" x2="86.36" y2="147.32" width="0.1524" layer="91"/>
<wire x1="86.36" y1="147.32" x2="86.36" y2="143.51" width="0.1524" layer="91"/>
<junction x="71.12" y="147.32"/>
<wire x1="73.66" y1="143.51" x2="73.66" y2="147.32" width="0.1524" layer="91"/>
<junction x="73.66" y="147.32"/>
<wire x1="76.2" y1="143.51" x2="76.2" y2="147.32" width="0.1524" layer="91"/>
<junction x="76.2" y="147.32"/>
<wire x1="78.74" y1="143.51" x2="78.74" y2="147.32" width="0.1524" layer="91"/>
<junction x="78.74" y="147.32"/>
<wire x1="81.28" y1="143.51" x2="81.28" y2="147.32" width="0.1524" layer="91"/>
<junction x="81.28" y="147.32"/>
<wire x1="83.82" y1="143.51" x2="83.82" y2="147.32" width="0.1524" layer="91"/>
<junction x="83.82" y="147.32"/>
<pinref part="RN1" gate="A" pin="2"/>
<pinref part="RN1" gate="B" pin="2"/>
<pinref part="RN1" gate="C" pin="2"/>
<pinref part="RN1" gate="D" pin="2"/>
<pinref part="RN2" gate="A" pin="2"/>
<pinref part="RN2" gate="B" pin="2"/>
<pinref part="RN2" gate="C" pin="2"/>
<pinref part="RN2" gate="D" pin="2"/>
</segment>
<segment>
<pinref part="U$33" gate="A" pin="+5V"/>
<wire x1="67.31" y1="106.68" x2="68.58" y2="106.68" width="0.1524" layer="91"/>
<wire x1="68.58" y1="106.68" x2="71.12" y2="106.68" width="0.1524" layer="91"/>
<wire x1="71.12" y1="106.68" x2="73.66" y2="106.68" width="0.1524" layer="91"/>
<wire x1="73.66" y1="106.68" x2="76.2" y2="106.68" width="0.1524" layer="91"/>
<wire x1="76.2" y1="106.68" x2="78.74" y2="106.68" width="0.1524" layer="91"/>
<wire x1="78.74" y1="106.68" x2="81.28" y2="106.68" width="0.1524" layer="91"/>
<wire x1="81.28" y1="106.68" x2="83.82" y2="106.68" width="0.1524" layer="91"/>
<wire x1="83.82" y1="106.68" x2="86.36" y2="106.68" width="0.1524" layer="91"/>
<wire x1="86.36" y1="106.68" x2="86.36" y2="102.87" width="0.1524" layer="91"/>
<wire x1="68.58" y1="102.87" x2="68.58" y2="106.68" width="0.1524" layer="91"/>
<junction x="68.58" y="106.68"/>
<wire x1="71.12" y1="102.87" x2="71.12" y2="106.68" width="0.1524" layer="91"/>
<junction x="71.12" y="106.68"/>
<wire x1="73.66" y1="102.87" x2="73.66" y2="106.68" width="0.1524" layer="91"/>
<junction x="73.66" y="106.68"/>
<wire x1="76.2" y1="102.87" x2="76.2" y2="106.68" width="0.1524" layer="91"/>
<junction x="76.2" y="106.68"/>
<wire x1="78.74" y1="102.87" x2="78.74" y2="106.68" width="0.1524" layer="91"/>
<junction x="78.74" y="106.68"/>
<wire x1="81.28" y1="102.87" x2="81.28" y2="106.68" width="0.1524" layer="91"/>
<junction x="81.28" y="106.68"/>
<wire x1="83.82" y1="102.87" x2="83.82" y2="106.68" width="0.1524" layer="91"/>
<junction x="83.82" y="106.68"/>
<pinref part="RN3" gate="A" pin="2"/>
<pinref part="RN3" gate="B" pin="2"/>
<pinref part="RN3" gate="C" pin="2"/>
<pinref part="RN3" gate="D" pin="2"/>
<pinref part="RN4" gate="A" pin="2"/>
<pinref part="RN4" gate="B" pin="2"/>
<pinref part="RN4" gate="C" pin="2"/>
<pinref part="RN4" gate="D" pin="2"/>
</segment>
<segment>
<pinref part="R3" gate="A" pin="2"/>
<pinref part="U$43" gate="A" pin="+5V"/>
</segment>
<segment>
<pinref part="R8" gate="A" pin="2"/>
<pinref part="U$51" gate="A" pin="+5V"/>
<wire x1="162.56" y1="-52.07" x2="163.83" y2="-52.07" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC8" gate="A" pin="IN"/>
<wire x1="294.64" y1="15.24" x2="297.18" y2="15.24" width="0.1524" layer="91"/>
<wire x1="297.18" y1="15.24" x2="297.18" y2="13.97" width="0.1524" layer="91"/>
<pinref part="C25" gate="A" pin="2"/>
<pinref part="U$60" gate="A" pin="+5V"/>
<wire x1="297.18" y1="15.24" x2="299.72" y2="15.24" width="0.1524" layer="91"/>
<junction x="297.18" y="15.24"/>
</segment>
<segment>
<pinref part="R10" gate="A" pin="2"/>
<pinref part="U$64" gate="A" pin="+5V"/>
<wire x1="218.44" y1="-49.53" x2="217.17" y2="-49.53" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="+5V" gate="A" pin="1"/>
<wire x1="256.54" y1="-48.26" x2="266.7" y2="-48.26" width="0.1524" layer="91"/>
<wire x1="266.7" y1="-48.26" x2="285.75" y2="-48.26" width="0.1524" layer="91"/>
<wire x1="285.75" y1="-48.26" x2="285.75" y2="-40.64" width="0.1524" layer="91"/>
<pinref part="SW1" gate="A" pin="5"/>
<wire x1="285.75" y1="-40.64" x2="294.64" y2="-40.64" width="0.1524" layer="91"/>
<pinref part="U$59" gate="A" pin="+5V"/>
<wire x1="284.48" y1="-40.64" x2="285.75" y2="-40.64" width="0.1524" layer="91"/>
<junction x="285.75" y="-40.64"/>
<pinref part="D5" gate="A" pin="K"/>
<wire x1="266.7" y1="-46.99" x2="266.7" y2="-48.26" width="0.1524" layer="91"/>
<junction x="266.7" y="-48.26"/>
</segment>
</net>
<net name="DD8" class="0">
<segment>
<pinref part="XC1" gate="A" pin="4"/>
<wire x1="30.48" y1="135.89" x2="29.21" y2="134.62" width="0.1524" layer="91"/>
<wire x1="29.21" y1="134.62" x2="11.43" y2="134.62" width="0.1524" layer="91"/>
<label x="27.94" y="135.128" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B8"/>
<wire x1="88.9" y1="69.85" x2="86.36" y2="69.85" width="0.1524" layer="91"/>
<label x="59.69" y="70.358" size="1.524" layer="95"/>
<wire x1="86.36" y1="69.85" x2="58.42" y2="69.85" width="0.1524" layer="91"/>
<wire x1="86.36" y1="92.71" x2="86.36" y2="69.85" width="0.1524" layer="91"/>
<junction x="86.36" y="69.85"/>
<pinref part="RN4" gate="D" pin="1"/>
<wire x1="57.15" y1="71.12" x2="58.42" y2="69.85" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD9" class="0">
<segment>
<pinref part="XC1" gate="A" pin="6"/>
<wire x1="30.48" y1="130.81" x2="29.21" y2="129.54" width="0.1524" layer="91"/>
<wire x1="29.21" y1="129.54" x2="11.43" y2="129.54" width="0.1524" layer="91"/>
<label x="27.94" y="130.048" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B7"/>
<wire x1="88.9" y1="72.39" x2="83.82" y2="72.39" width="0.1524" layer="91"/>
<label x="59.69" y="72.898" size="1.524" layer="95"/>
<wire x1="83.82" y1="72.39" x2="58.42" y2="72.39" width="0.1524" layer="91"/>
<wire x1="83.82" y1="92.71" x2="83.82" y2="72.39" width="0.1524" layer="91"/>
<junction x="83.82" y="72.39"/>
<pinref part="RN4" gate="C" pin="1"/>
<wire x1="57.15" y1="73.66" x2="58.42" y2="72.39" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD10" class="0">
<segment>
<pinref part="XC1" gate="A" pin="8"/>
<wire x1="30.48" y1="125.73" x2="29.21" y2="124.46" width="0.1524" layer="91"/>
<wire x1="29.21" y1="124.46" x2="11.43" y2="124.46" width="0.1524" layer="91"/>
<label x="27.94" y="124.968" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B6"/>
<wire x1="88.9" y1="74.93" x2="81.28" y2="74.93" width="0.1524" layer="91"/>
<label x="59.69" y="75.438" size="1.524" layer="95"/>
<wire x1="81.28" y1="74.93" x2="58.42" y2="74.93" width="0.1524" layer="91"/>
<wire x1="81.28" y1="92.71" x2="81.28" y2="74.93" width="0.1524" layer="91"/>
<junction x="81.28" y="74.93"/>
<pinref part="RN4" gate="B" pin="1"/>
<wire x1="57.15" y1="76.2" x2="58.42" y2="74.93" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD11" class="0">
<segment>
<pinref part="XC1" gate="A" pin="10"/>
<wire x1="30.48" y1="120.65" x2="29.21" y2="119.38" width="0.1524" layer="91"/>
<wire x1="29.21" y1="119.38" x2="11.43" y2="119.38" width="0.1524" layer="91"/>
<label x="27.94" y="119.888" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B5"/>
<wire x1="88.9" y1="77.47" x2="78.74" y2="77.47" width="0.1524" layer="91"/>
<label x="59.69" y="77.978" size="1.524" layer="95"/>
<wire x1="78.74" y1="77.47" x2="58.42" y2="77.47" width="0.1524" layer="91"/>
<wire x1="78.74" y1="92.71" x2="78.74" y2="77.47" width="0.1524" layer="91"/>
<junction x="78.74" y="77.47"/>
<pinref part="RN4" gate="A" pin="1"/>
<wire x1="57.15" y1="78.74" x2="58.42" y2="77.47" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD12" class="0">
<segment>
<pinref part="XC1" gate="A" pin="12"/>
<wire x1="30.48" y1="115.57" x2="29.21" y2="114.3" width="0.1524" layer="91"/>
<wire x1="29.21" y1="114.3" x2="11.43" y2="114.3" width="0.1524" layer="91"/>
<label x="27.94" y="114.808" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B4"/>
<wire x1="88.9" y1="80.01" x2="76.2" y2="80.01" width="0.1524" layer="91"/>
<label x="59.69" y="80.518" size="1.524" layer="95"/>
<wire x1="76.2" y1="80.01" x2="58.42" y2="80.01" width="0.1524" layer="91"/>
<wire x1="76.2" y1="92.71" x2="76.2" y2="80.01" width="0.1524" layer="91"/>
<junction x="76.2" y="80.01"/>
<pinref part="RN3" gate="D" pin="1"/>
<wire x1="57.15" y1="81.28" x2="58.42" y2="80.01" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD13" class="0">
<segment>
<pinref part="XC1" gate="A" pin="14"/>
<wire x1="30.48" y1="110.49" x2="29.21" y2="109.22" width="0.1524" layer="91"/>
<wire x1="29.21" y1="109.22" x2="11.43" y2="109.22" width="0.1524" layer="91"/>
<label x="27.94" y="109.728" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B3"/>
<wire x1="88.9" y1="82.55" x2="73.66" y2="82.55" width="0.1524" layer="91"/>
<label x="59.69" y="83.058" size="1.524" layer="95"/>
<wire x1="73.66" y1="82.55" x2="58.42" y2="82.55" width="0.1524" layer="91"/>
<wire x1="73.66" y1="92.71" x2="73.66" y2="82.55" width="0.1524" layer="91"/>
<junction x="73.66" y="82.55"/>
<pinref part="RN3" gate="C" pin="1"/>
<wire x1="57.15" y1="83.82" x2="58.42" y2="82.55" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD14" class="0">
<segment>
<pinref part="XC1" gate="A" pin="16"/>
<wire x1="30.48" y1="105.41" x2="29.21" y2="104.14" width="0.1524" layer="91"/>
<wire x1="29.21" y1="104.14" x2="11.43" y2="104.14" width="0.1524" layer="91"/>
<label x="27.94" y="104.648" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B2"/>
<wire x1="88.9" y1="85.09" x2="71.12" y2="85.09" width="0.1524" layer="91"/>
<label x="59.69" y="85.598" size="1.524" layer="95"/>
<wire x1="71.12" y1="85.09" x2="58.42" y2="85.09" width="0.1524" layer="91"/>
<wire x1="71.12" y1="92.71" x2="71.12" y2="85.09" width="0.1524" layer="91"/>
<junction x="71.12" y="85.09"/>
<pinref part="RN3" gate="B" pin="1"/>
<wire x1="57.15" y1="86.36" x2="58.42" y2="85.09" width="0.1524" layer="91"/>
</segment>
</net>
<net name="DD15" class="0">
<segment>
<pinref part="XC1" gate="A" pin="18"/>
<wire x1="30.48" y1="100.33" x2="29.21" y2="99.06" width="0.1524" layer="91"/>
<wire x1="29.21" y1="99.06" x2="11.43" y2="99.06" width="0.1524" layer="91"/>
<label x="27.94" y="99.568" size="1.524" layer="95" rot="MR0"/>
</segment>
<segment>
<pinref part="IC4" gate="A" pin="B1"/>
<wire x1="88.9" y1="87.63" x2="68.58" y2="87.63" width="0.1524" layer="91"/>
<label x="59.69" y="88.138" size="1.524" layer="95"/>
<wire x1="68.58" y1="87.63" x2="58.42" y2="87.63" width="0.1524" layer="91"/>
<wire x1="68.58" y1="92.71" x2="68.58" y2="87.63" width="0.1524" layer="91"/>
<junction x="68.58" y="87.63"/>
<pinref part="RN3" gate="A" pin="1"/>
<wire x1="57.15" y1="88.9" x2="58.42" y2="87.63" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!RESET" class="0">
<segment>
<pinref part="XC1" gate="A" pin="1"/>
<wire x1="11.43" y1="142.24" x2="21.59" y2="142.24" width="0.1524" layer="91"/>
<label x="21.59" y="142.24" size="1.27" layer="95" xref="yes"/>
</segment>
<segment>
<pinref part="IC6" gate="D" pin="O"/>
<label x="87.63" y="-34.29" size="1.27" layer="95" rot="R180" xref="yes"/>
<wire x1="90.17" y1="-34.29" x2="87.63" y2="-34.29" width="0.1524" layer="91"/>
</segment>
</net>
<net name="!DIOW" class="0">
<segment>
<pinref part="XC1" gate="A" pin="23"/>
<wire x1="11.43" y1="86.36" x2="29.21" y2="86.36" width="0.1524" layer="91"/>
<label x="27.94" y="86.868" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="86.36" x2="30.48" y2="87.63" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="C" pin="O"/>
<wire x1="77.47" y1="12.7" x2="78.74" y2="11.43" width="0.1524" layer="91"/>
<wire x1="78.74" y1="11.43" x2="90.17" y2="11.43" width="0.1524" layer="91"/>
<label x="80.01" y="11.938" size="1.524" layer="95"/>
</segment>
</net>
<net name="!DIOR" class="0">
<segment>
<pinref part="XC1" gate="A" pin="25"/>
<wire x1="11.43" y1="81.28" x2="29.21" y2="81.28" width="0.1524" layer="91"/>
<label x="27.94" y="81.788" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="81.28" x2="30.48" y2="82.55" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="D" pin="O"/>
<wire x1="129.54" y1="12.7" x2="130.81" y2="11.43" width="0.1524" layer="91"/>
<wire x1="130.81" y1="11.43" x2="142.24" y2="11.43" width="0.1524" layer="91"/>
<label x="132.08" y="11.938" size="1.524" layer="95"/>
</segment>
</net>
<net name="!IORDY" class="0">
<segment>
<pinref part="XC1" gate="A" pin="27"/>
<wire x1="11.43" y1="76.2" x2="29.21" y2="76.2" width="0.1524" layer="91"/>
<label x="27.94" y="76.708" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="76.2" x2="30.48" y2="77.47" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="A" pin="I"/>
<wire x1="30.48" y1="36.83" x2="31.75" y2="35.56" width="0.1524" layer="91"/>
<wire x1="31.75" y1="35.56" x2="40.64" y2="35.56" width="0.1524" layer="91"/>
<label x="33.02" y="36.068" size="1.524" layer="95"/>
<pinref part="R3" gate="A" pin="1"/>
<wire x1="40.64" y1="35.56" x2="43.18" y2="35.56" width="0.1524" layer="91"/>
<wire x1="40.64" y1="38.1" x2="40.64" y2="35.56" width="0.1524" layer="91"/>
<junction x="40.64" y="35.56"/>
</segment>
</net>
<net name="INTRQ" class="0">
<segment>
<pinref part="XC1" gate="A" pin="31"/>
<wire x1="11.43" y1="66.04" x2="29.21" y2="66.04" width="0.1524" layer="91"/>
<label x="27.94" y="66.548" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="66.04" x2="30.48" y2="67.31" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC7" gate="B" pin="I"/>
<wire x1="30.48" y1="12.7" x2="31.75" y2="11.43" width="0.1524" layer="91"/>
<wire x1="31.75" y1="11.43" x2="40.64" y2="11.43" width="0.1524" layer="91"/>
<label x="33.02" y="11.938" size="1.524" layer="95"/>
<pinref part="R4" gate="A" pin="2"/>
<wire x1="40.64" y1="11.43" x2="43.18" y2="11.43" width="0.1524" layer="91"/>
<wire x1="40.64" y1="8.89" x2="40.64" y2="11.43" width="0.1524" layer="91"/>
<junction x="40.64" y="11.43"/>
</segment>
</net>
<net name="DA1" class="0">
<segment>
<pinref part="XC1" gate="A" pin="33"/>
<wire x1="11.43" y1="60.96" x2="29.21" y2="60.96" width="0.1524" layer="91"/>
<label x="27.94" y="61.468" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="60.96" x2="30.48" y2="62.23" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="B" pin="O"/>
<wire x1="77.47" y1="-8.89" x2="78.74" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="78.74" y1="-10.16" x2="90.17" y2="-10.16" width="0.1524" layer="91"/>
<label x="80.01" y="-9.652" size="1.524" layer="95"/>
</segment>
</net>
<net name="DA0" class="0">
<segment>
<pinref part="XC1" gate="A" pin="35"/>
<wire x1="11.43" y1="55.88" x2="29.21" y2="55.88" width="0.1524" layer="91"/>
<label x="27.94" y="56.388" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="55.88" x2="30.48" y2="57.15" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="C" pin="O"/>
<wire x1="129.54" y1="-8.89" x2="130.81" y2="-10.16" width="0.1524" layer="91"/>
<wire x1="130.81" y1="-10.16" x2="142.24" y2="-10.16" width="0.1524" layer="91"/>
<label x="132.08" y="-9.652" size="1.524" layer="95"/>
</segment>
</net>
<net name="!IDE_CS0" class="0">
<segment>
<pinref part="XC1" gate="A" pin="37"/>
<wire x1="11.43" y1="50.8" x2="29.21" y2="50.8" width="0.1524" layer="91"/>
<label x="27.94" y="51.308" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="50.8" x2="30.48" y2="52.07" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="B" pin="O"/>
<wire x1="129.54" y1="36.83" x2="130.81" y2="35.56" width="0.1524" layer="91"/>
<wire x1="130.81" y1="35.56" x2="142.24" y2="35.56" width="0.1524" layer="91"/>
<label x="132.08" y="36.068" size="1.524" layer="95"/>
</segment>
</net>
<net name="!IDE_CS1" class="0">
<segment>
<pinref part="XC1" gate="A" pin="38"/>
<wire x1="11.43" y1="48.26" x2="29.21" y2="48.26" width="0.1524" layer="91"/>
<label x="27.94" y="48.768" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="48.26" x2="30.48" y2="49.53" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC5" gate="A" pin="O"/>
<wire x1="77.47" y1="36.83" x2="78.74" y2="35.56" width="0.1524" layer="91"/>
<wire x1="78.74" y1="35.56" x2="90.17" y2="35.56" width="0.1524" layer="91"/>
<label x="80.01" y="36.068" size="1.524" layer="95"/>
</segment>
</net>
<net name="!ACTIVE" class="0">
<segment>
<pinref part="XC1" gate="A" pin="39"/>
<wire x1="11.43" y1="45.72" x2="29.21" y2="45.72" width="0.1524" layer="91"/>
<label x="27.94" y="46.228" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="45.72" x2="30.48" y2="46.99" width="0.1524" layer="91"/>
</segment>
<segment>
<wire x1="129.54" y1="-50.8" x2="130.81" y2="-52.07" width="0.1524" layer="91"/>
<wire x1="130.81" y1="-52.07" x2="140.97" y2="-52.07" width="0.1524" layer="91"/>
<label x="132.08" y="-51.562" size="1.524" layer="95"/>
<pinref part="D1" gate="A" pin="K"/>
</segment>
</net>
<net name="DA2" class="0">
<segment>
<pinref part="XC1" gate="A" pin="36"/>
<wire x1="11.43" y1="53.34" x2="29.21" y2="53.34" width="0.1524" layer="91"/>
<label x="27.94" y="53.848" size="1.524" layer="95" rot="MR0"/>
<wire x1="29.21" y1="53.34" x2="30.48" y2="54.61" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="IC6" gate="A" pin="O"/>
<wire x1="129.54" y1="-33.02" x2="130.81" y2="-34.29" width="0.1524" layer="91"/>
<wire x1="130.81" y1="-34.29" x2="142.24" y2="-34.29" width="0.1524" layer="91"/>
<label x="132.08" y="-33.782" size="1.524" layer="95"/>
</segment>
</net>
<net name="N$19" class="0">
<segment>
<pinref part="R9" gate="A" pin="2"/>
<pinref part="D2" gate="A" pin="A"/>
<wire x1="195.58" y1="-24.13" x2="194.31" y2="-24.13" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$20" class="0">
<segment>
<pinref part="D4" gate="A" pin="A"/>
<pinref part="R11" gate="A" pin="1"/>
<wire x1="207.01" y1="-38.1" x2="205.74" y2="-38.1" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$21" class="0">
<segment>
<pinref part="D1" gate="A" pin="A"/>
<pinref part="R8" gate="A" pin="1"/>
<wire x1="152.4" y1="-52.07" x2="151.13" y2="-52.07" width="0.1524" layer="91"/>
</segment>
</net>
<net name="+1,1V" class="0">
<segment>
<pinref part="IC1" gate="A" pin="VREG_FB"/>
<wire x1="259.08" y1="123.19" x2="293.37" y2="123.19" width="0.1524" layer="91"/>
<wire x1="293.37" y1="123.19" x2="304.8" y2="123.19" width="0.1524" layer="91"/>
<wire x1="304.8" y1="123.19" x2="304.8" y2="135.89" width="0.1524" layer="91"/>
<wire x1="304.8" y1="135.89" x2="314.96" y2="135.89" width="0.1524" layer="91"/>
<pinref part="C21" gate="A" pin="1"/>
<wire x1="314.96" y1="135.89" x2="314.96" y2="133.35" width="0.1524" layer="91"/>
<junction x="314.96" y="135.89"/>
<wire x1="317.5" y1="135.89" x2="314.96" y2="135.89" width="0.1524" layer="91"/>
<pinref part="L1" gate="A" pin="K"/>
<wire x1="292.1" y1="116.84" x2="293.37" y2="116.84" width="0.1524" layer="91"/>
<wire x1="293.37" y1="116.84" x2="293.37" y2="123.19" width="0.1524" layer="91"/>
<junction x="293.37" y="123.19"/>
<pinref part="U$8" gate="G$1" pin="+1,1V"/>
</segment>
<segment>
<pinref part="C18" gate="A" pin="2"/>
<wire x1="264.16" y1="185.42" x2="271.78" y2="185.42" width="0.1524" layer="91"/>
<wire x1="271.78" y1="185.42" x2="279.4" y2="185.42" width="0.1524" layer="91"/>
<wire x1="279.4" y1="185.42" x2="279.4" y2="179.07" width="0.1524" layer="91"/>
<pinref part="C16" gate="A" pin="2"/>
<wire x1="264.16" y1="179.07" x2="264.16" y2="185.42" width="0.1524" layer="91"/>
<pinref part="C17" gate="A" pin="2"/>
<wire x1="271.78" y1="179.07" x2="271.78" y2="185.42" width="0.1524" layer="91"/>
<junction x="271.78" y="185.42"/>
<wire x1="283.21" y1="185.42" x2="279.4" y2="185.42" width="0.1524" layer="91"/>
<junction x="279.4" y="185.42"/>
<pinref part="IC1" gate="A" pin="DVDD51"/>
<wire x1="250.19" y1="156.21" x2="250.19" y2="153.67" width="0.1524" layer="91"/>
<wire x1="247.65" y1="156.21" x2="250.19" y2="156.21" width="0.1524" layer="91"/>
<pinref part="IC1" gate="A" pin="DVDD32"/>
<wire x1="247.65" y1="153.67" x2="247.65" y2="156.21" width="0.1524" layer="91"/>
<junction x="247.65" y="156.21"/>
<wire x1="245.11" y1="156.21" x2="247.65" y2="156.21" width="0.1524" layer="91"/>
<pinref part="IC1" gate="A" pin="DVDD10"/>
<wire x1="245.11" y1="153.67" x2="245.11" y2="156.21" width="0.1524" layer="91"/>
<wire x1="264.16" y1="185.42" x2="250.19" y2="185.42" width="0.1524" layer="91"/>
<wire x1="250.19" y1="185.42" x2="250.19" y2="156.21" width="0.1524" layer="91"/>
<junction x="264.16" y="185.42"/>
<junction x="250.19" y="156.21"/>
<pinref part="U$9" gate="G$1" pin="+1,1V"/>
</segment>
</net>
<net name="+12V" class="0">
<segment>
<pinref part="R11" gate="A" pin="2"/>
<pinref part="U$52" gate="A" pin="+12V"/>
<wire x1="218.44" y1="-38.1" x2="217.17" y2="-38.1" width="0.1524" layer="91"/>
</segment>
<segment>
<pinref part="+12V" gate="A" pin="1"/>
<wire x1="256.54" y1="-22.86" x2="266.7" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="266.7" y1="-22.86" x2="285.75" y2="-22.86" width="0.1524" layer="91"/>
<wire x1="285.75" y1="-22.86" x2="285.75" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="SW1" gate="A" pin="2"/>
<wire x1="285.75" y1="-30.48" x2="294.64" y2="-30.48" width="0.1524" layer="91"/>
<pinref part="U$61" gate="A" pin="+12V"/>
<wire x1="284.48" y1="-30.48" x2="285.75" y2="-30.48" width="0.1524" layer="91"/>
<junction x="285.75" y="-30.48"/>
<pinref part="D6" gate="A" pin="K"/>
<wire x1="266.7" y1="-24.13" x2="266.7" y2="-22.86" width="0.1524" layer="91"/>
<junction x="266.7" y="-22.86"/>
</segment>
</net>
<net name="PE" class="0">
<segment>
<wire x1="326.39" y1="29.21" x2="326.39" y2="30.48" width="0.1524" layer="91"/>
<pinref part="R17" gate="A" pin="2"/>
<wire x1="326.39" y1="30.48" x2="334.01" y2="30.48" width="0.1524" layer="91"/>
<wire x1="334.01" y1="30.48" x2="334.01" y2="29.21" width="0.1524" layer="91"/>
<pinref part="USB" gate="A" pin="S"/>
<wire x1="326.39" y1="31.75" x2="326.39" y2="30.48" width="0.1524" layer="91"/>
<junction x="326.39" y="30.48"/>
<pinref part="C26" gate="A" pin="2"/>
<pinref part="U$62" gate="A" pin="PE"/>
<wire x1="334.01" y1="30.48" x2="342.9" y2="30.48" width="0.1524" layer="91"/>
<wire x1="342.9" y1="30.48" x2="342.9" y2="17.78" width="0.1524" layer="91"/>
<junction x="334.01" y="30.48"/>
</segment>
<segment>
<pinref part="SW1" gate="A" pin="SHLD"/>
<pinref part="U$63" gate="A" pin="PE"/>
<wire x1="294.64" y1="-44.45" x2="292.1" y2="-44.45" width="0.1524" layer="91"/>
<wire x1="292.1" y1="-44.45" x2="292.1" y2="-45.72" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$18" class="0">
<segment>
<pinref part="D3" gate="A" pin="A"/>
<pinref part="R10" gate="A" pin="1"/>
<wire x1="207.01" y1="-49.53" x2="205.74" y2="-49.53" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$17" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A4"/>
<pinref part="RN6" gate="A" pin="1"/>
<wire x1="121.92" y1="120.65" x2="116.84" y2="120.65" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$24" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A3"/>
<pinref part="RN6" gate="B" pin="1"/>
<wire x1="121.92" y1="123.19" x2="116.84" y2="123.19" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$25" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A2"/>
<pinref part="RN6" gate="C" pin="1"/>
<wire x1="121.92" y1="125.73" x2="116.84" y2="125.73" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$26" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A1"/>
<pinref part="RN6" gate="D" pin="1"/>
<wire x1="121.92" y1="128.27" x2="116.84" y2="128.27" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$27" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A8"/>
<pinref part="RN7" gate="A" pin="1"/>
<wire x1="121.92" y1="110.49" x2="116.84" y2="110.49" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$28" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A7"/>
<pinref part="RN7" gate="B" pin="1"/>
<wire x1="121.92" y1="113.03" x2="116.84" y2="113.03" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$29" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A6"/>
<pinref part="RN7" gate="C" pin="1"/>
<wire x1="121.92" y1="115.57" x2="116.84" y2="115.57" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$30" class="0">
<segment>
<pinref part="IC3" gate="A" pin="A5"/>
<pinref part="RN7" gate="D" pin="1"/>
<wire x1="121.92" y1="118.11" x2="116.84" y2="118.11" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$31" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A4"/>
<pinref part="RN8" gate="A" pin="1"/>
<wire x1="121.92" y1="80.01" x2="116.84" y2="80.01" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$32" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A3"/>
<pinref part="RN8" gate="B" pin="1"/>
<wire x1="121.92" y1="82.55" x2="116.84" y2="82.55" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$33" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A2"/>
<pinref part="RN8" gate="C" pin="1"/>
<wire x1="121.92" y1="85.09" x2="116.84" y2="85.09" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$34" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A1"/>
<pinref part="RN8" gate="D" pin="1"/>
<wire x1="121.92" y1="87.63" x2="116.84" y2="87.63" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$35" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A8"/>
<pinref part="RN9" gate="A" pin="1"/>
<wire x1="121.92" y1="69.85" x2="116.84" y2="69.85" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$36" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A7"/>
<pinref part="RN9" gate="B" pin="1"/>
<wire x1="121.92" y1="72.39" x2="116.84" y2="72.39" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$37" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A6"/>
<pinref part="RN9" gate="C" pin="1"/>
<wire x1="121.92" y1="74.93" x2="116.84" y2="74.93" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$38" class="0">
<segment>
<pinref part="IC4" gate="A" pin="A5"/>
<pinref part="RN9" gate="D" pin="1"/>
<wire x1="121.92" y1="77.47" x2="116.84" y2="77.47" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$39" class="0">
<segment>
<pinref part="IC1" gate="A" pin="!RESET"/>
<wire x1="308.61" y1="62.23" x2="308.61" y2="58.42" width="0.1524" layer="91"/>
<wire x1="308.61" y1="58.42" x2="266.7" y2="58.42" width="0.1524" layer="91"/>
<wire x1="266.7" y1="58.42" x2="266.7" y2="67.31" width="0.1524" layer="91"/>
<wire x1="266.7" y1="67.31" x2="259.08" y2="67.31" width="0.1524" layer="91"/>
<pinref part="PB2" gate="A" pin="1"/>
<wire x1="309.88" y1="62.23" x2="308.61" y2="62.23" width="0.1524" layer="91"/>
<pinref part="R16" gate="A" pin="1"/>
<wire x1="309.88" y1="73.66" x2="308.61" y2="73.66" width="0.1524" layer="91"/>
<wire x1="308.61" y1="73.66" x2="308.61" y2="62.23" width="0.1524" layer="91"/>
<junction x="308.61" y="62.23"/>
</segment>
</net>
<net name="N$40" class="0">
<segment>
<pinref part="PWR" gate="A" pin="1"/>
<wire x1="321.31" y1="-31.75" x2="318.77" y2="-31.75" width="0.1524" layer="91"/>
<pinref part="SW1" gate="A" pin="1"/>
<wire x1="318.77" y1="-31.75" x2="318.77" y2="-27.94" width="0.1524" layer="91"/>
<wire x1="318.77" y1="-27.94" x2="304.8" y2="-27.94" width="0.1524" layer="91"/>
</segment>
</net>
<net name="N$41" class="0">
<segment>
<wire x1="318.77" y1="-43.18" x2="318.77" y2="-39.37" width="0.1524" layer="91"/>
<pinref part="PWR" gate="A" pin="4"/>
<wire x1="318.77" y1="-39.37" x2="321.31" y2="-39.37" width="0.1524" layer="91"/>
<wire x1="318.77" y1="-43.18" x2="307.34" y2="-43.18" width="0.1524" layer="91"/>
<wire x1="307.34" y1="-43.18" x2="307.34" y2="-38.1" width="0.1524" layer="91"/>
<pinref part="SW1" gate="A" pin="4"/>
<wire x1="307.34" y1="-38.1" x2="304.8" y2="-38.1" width="0.1524" layer="91"/>
</segment>
</net>
</nets>
</sheet>
</sheets>
<errors>
<approved hash="104,1,100.33,184.15,IC3P,VCC,+5V,,,"/>
<approved hash="104,1,114.3,184.15,IC4P,VCC,+5V,,,"/>
<approved hash="104,1,55.88,184.15,IC7P,VCC,+3\,3V,,,"/>
<approved hash="104,1,139.7,184.15,IC6P,VCC,+5V,,,"/>
<approved hash="104,1,127,184.15,IC5P,VCC,+5V,,,"/>
<approved hash="104,1,68.58,184.15,IC2P,VCC,+3\,3V,,,"/>
<approved hash="113,1,196.85,-2.7813,JP1,,,,,"/>
<approved hash="113,1,196.85,-10.4013,JP2,,,,,"/>
</errors>
</schematic>
</drawing>
<compatibility>
<note version="6.3" minversion="6.2.2" severity="warning">
Since Version 6.2.2 text objects can contain more than one line,
which will not be processed correctly with this version.
</note>
</compatibility>
</eagle>
